# Deploy — Step by Step

Your code is ready in **`hostel-render-fix.zip`** (22 files, 536 KB).
Follow these steps in order. Total time: about 10 minutes.

---

## STEP 1 — Download the zip

In this chat, click **`hostel-render-fix.zip`** and save it to your PC.
(It's also at the workspace root: `/home/user/hostel-render-fix.zip`)

---

## STEP 2 — Unzip it on your PC

Right-click the zip → **Extract All** → Extract.

You now have a folder containing:

```
server.js                    ← main server
persistence.js               ← keeps data alive on Render
reset-demo.js                ← demo data helper
package.json
.gitignore
RENDER-DATA-LOSS-FIX.md
NEW-FEATURES.md
public/
    index.html
    js/app.js
    css/styles.css
    vendor/                  ← scanner, icons, socket.io (local copies)
```

> **Do NOT upload the zip file itself.** GitHub stores it as a blob — it will not
> unzip it, and Render will never see your files.

---

## STEP 3 — Open your GitHub repo

Go to: **github.com/kxrlilik/hostel-manager-system**

Make sure the branch shows **`main`** (top-left dropdown).

---

## STEP 4 — Upload the files

1. Click **Add file** → **Upload files**
2. Open your extracted folder, select **everything inside it** — `server.js`,
   `persistence.js`, `reset-demo.js`, `package.json`, `.gitignore`, the two
   `.md` files, **and the whole `public` folder** — and drag it all onto the page.
3. Scroll down. Message: `remove code entry, QR scanning only`
4. Click **Commit changes**

**Important:** GitHub matches files by name and overwrites them. So this replaces
`server.js`, `app.js`, `index.html`, `styles.css` with the new versions and adds
anything new. You do **not** need to delete anything first.

> The `hostel.db` database file is **not** in the zip, so this upload cannot touch
> your live data. Student accounts are safe.

---

## STEP 5 — Wait for Render to deploy

Render watches `main` and redeploys automatically on every commit.

1. Open your Render dashboard → click your service
2. Click the **Events** tab — you'll see `Deploy started`
3. Click the **Logs** tab and watch. When you see:

```
🏠 Hostel Management System running at http://0.0.0.0:3000
```

…the new code is live.

**If nothing happens after ~2 minutes:** click **Manual Deploy** → **Deploy latest
commit** in the top-right of the service page.

---

## STEP 6 — Check the environment variables

Render → your service → **Environment** tab. These four must all be present:

| Key | Value |
|---|---|
| `GITHUB_TOKEN` | your GitHub personal access token |
| `GITHUB_REPO` | `kxrlilik/hostel-manager-system` |
| `GITHUB_BRANCH` | `main` |
| `JWT_SECRET` | any long random string |

These are what stop the data loss — without them, every restart wipes the database.
If you changed any, Render redeploys by itself when you click Save.

---

## STEP 7 — Test the live site

Open **https://hostel-manager-48g8.onrender.com**
(the first load after idle takes ~30 seconds — the free plan sleeps).

Check these five things:

1. **Landing page** — no "Show Demo Credentials" button
2. **Login as warden** (`warden` / `warden123`) → **Leaves** tab → approve the
   pending request from 22CS101
3. **Login as student** (`22cs101` / `student123`) → dashboard shows the **ON LEAVE**
   badge and the QR code — **no 6-digit number under it**
4. **Login as gate pass** (`gatepass` / `gatepass123`) → the gate panel has
   **Start Scanner** and **no code input box** anywhere
5. Open the **On Leave Today** tab → the student's name is listed → click
   **Mark Out**, then **Mark In**

---

## STEP 8 — Test the scanner properly

**Use your phone**, or a laptop with a webcam, on the live URL:

1. On the **student's** device, open their dashboard — the QR code is on screen
2. On the **gate device**, press **Start Scanner** and allow the camera
3. Point the camera at the student's QR → they're checked out automatically
4. Press Start Scanner again and scan again → they're checked in, and the dashboard
   now shows how long they were outside

⚠️ The scanner **cannot** work inside the chat preview window — browsers block
camera access there. It works on the real Render URL and on a phone.

---

## STEP 9 — Confirm your data now survives restarts

This is the fix for your friend's deleted account, so verify it once:

1. Register a **new student account** on the live site
2. Leave the site alone for ~20 minutes (so Render sleeps and restarts)
3. Open the site again and log in as that student

**Still there?** The fix is working — the database is syncing to GitHub on every
change and being pulled back on every boot.

You can also check GitHub itself: your repo should show a **`hostel.db`** file, and
its commit history should update as you use the site.

---

## If something goes wrong

| Symptom | Fix |
|---|---|
| Site loads but looks unstyled | The `public/` folder didn't upload with its structure. Re-do Step 4 and drag the **folder**, not just the files inside it. |
| `Cannot find module './persistence'` in logs | `persistence.js` wasn't uploaded. Upload it, commit, wait for redeploy. |
| Scanner says "Scanner could not load" | `public/vendor/` is missing or flattened. Upload the `public` folder again. |
| New accounts vanish after a while | `GITHUB_TOKEN` is missing or expired → Step 6. |
| Old code still running | Step 5, click **Manual Deploy → Deploy latest commit**. |

---

## Don't do this

- **Don't run `reset-demo.js` on Render.** It wipes leaves and resets students to
  IN_CAMPUS. It's only for resetting the demo locally.
- **Don't upload files one by one without the folders.** The CSS, JS, and scanner
  libraries live under `public/` and lose their path if flattened.
