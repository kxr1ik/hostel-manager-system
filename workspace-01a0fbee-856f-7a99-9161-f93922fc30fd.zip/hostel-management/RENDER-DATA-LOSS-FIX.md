# ✅ Your friend's account: what happened and what to do

## The short answer

Your search was fine. The account was **not** hidden or marked inactive — it was
**deleted from the server**.

Render's free plan does not keep files. Every time the service restarts (it restarts
automatically after 15 minutes of no visitors), the whole disk is wiped. Your student
database — the file `hostel.db` — was on that disk. So it was replaced with a fresh
one containing only the 5 demo students.

**Your friend's old account cannot be recovered.** That data is gone from Render.
He has to register again — but **only after you finish the steps below**, otherwise
it will happen again.

---

## What to do (2 steps, about 15 minutes)

### STEP 1 — Put the new files on GitHub

Download **`hostel-render-fix.zip`** from this chat, then unzip it on your PC.
You get these files:

```
server.js
persistence.js                          ← NEW FILE, must be added
package.json
.gitignore
RENDER-DATA-LOSS-FIX.md
public/index.html
public/js/app.js
public/css/styles.css
public/vendor/                          ← NEW FOLDER, must be added
    socket.io.min.js
    html5-qrcode.min.js
    qrcode.min.js
    fontawesome/css/all.min.css
    fontawesome/webfonts/*.woff2
```

The `public/vendor/` folder holds the QR scanner, socket.io, and icon libraries.
They used to load from the internet, which fails inside preview windows and
offline — now they are served by your own server, so nothing external is needed.

Now open your repo **github.com/kxrlilik/hostel-manager-system** and choose one way:

**Easy way (recommended) — drag and drop**

1. Click **Add file** → **Upload files**
2. Drag the extracted `server.js`, `persistence.js`, `package.json` and the
   `.gitignore` into the page
3. Drag the **`public` folder** in too (it keeps the `js/` and `css/` paths)
4. Write a message like `fix: stop data loss on Render` → click **Commit changes**

**Or copy-paste way**

Open each file on GitHub → pencil ✏️ icon → select all → delete → paste the new
contents → Commit. Do this for all 7 files one by one.

Render will redeploy by itself. Wait 2–3 minutes.

### STEP 2 — Turn on cloud sync (this is what saves the data)

**2a. Make a GitHub token**

1. Open **https://github.com/settings/tokens?type=beta**
2. **Generate new token** → name it `hostel-sync`
3. **Repository access** → *Only select repositories* → `kxrlilik/hostel-manager-system`
4. **Permissions** → *Repository permissions* → **Contents** → change to
   **Read and write**
5. Click **Generate token** and copy it (starts with `github_pat_…`). It is shown
   only once.

**2b. Add it on Render**

Render dashboard → your service → **Environment** → **Add Environment Variable**.
Add these three:

| Key | Value |
|-----|-------|
| `GITHUB_TOKEN` | the `github_pat_…` token you copied |
| `GITHUB_REPO` | `kxrlilik/hostel-manager-system` |
| `JWT_SECRET` | any long random word, e.g. `hostelSecret2026indore` |

Click **Save**. Render redeploys again. Wait for it to finish.

**2c. Check it worked**

Log in as Warden and scroll to the bottom — the **Data Safety & Backup** box.
The badge must say **Cloud sync ON**.

Now register one test student, wait about a minute, and open your GitHub repo.
You will see a new commit: `chore: sync hostel.db`. That commit is your data,
saved outside Render. 🎉

**Then tell your friend to register again.** This time the account will survive
restarts.

> ⚠️ **Make the repo private first:** GitHub → Settings → General → scroll to
> Danger Zone → Change visibility → Make private.
> The saved database holds students' names and phone numbers, so a public repo
> would let anyone download it.

---

## What the new code does

| Protection | Needs setup? |
|---|---|
| Saves the database to your GitHub repo on every change, and reloads it on start | Yes — step 2 |
| Keeps `hostel.db.backup` on disk and uses it if the main file is missing | No |
| **Data Safety & Backup** card in the warden dashboard: Download Backup, Restore Backup, Sync Now, Export JSON | No |
| Student photos are stored inside the database, so they come back too | No |
| Reactivate a student who was deactivated instead of deleted | No |

Also fixed in this update:

- `app.set('trust proxy', 1)` — Render puts a proxy in front of your app, and
  without that line the rate limiter refuses to run and **every login fails** with
  a 500 error. Login limit is now 30 tries / 15 min; general API limit 600
  requests / minute so the live dashboards never trip it.
- Frame blocking removed (`X-Frame-Options`, helmet `frameguard`) — the page could
  not be shown inside any preview window before.
- CORS now accepts these hosts and `Origin: null` (used by sandboxed previews).

### Extra: checking students in without a camera

A camera does not work inside preview windows, and the QR token itself is a
48-character code that nobody can type. So the student dashboard now also shows a
**6-digit code** under the QR:

- The student reads it out, or shows the screen.
- The gate pass types it into **"No camera? Type the code shown on the student's
  screen"** and presses Verify.
- It behaves exactly like a scan: same check-in / check-out logic, single use,
  server verified. The code stays the same for 60 seconds so there is time to
  read it, while the QR beside it still refreshes every 6 seconds.

---

## I tested it for you

On the local copy I registered a student, deleted the database file completely
(same as a Render restart), then started the app again:

```
[boot] hostel.db missing — restoring from local .backup
Loaded database from local backup
✅ RECOVERED: Recovery Test (22CS555)
```

Deleting a student and restoring from a downloaded backup also worked — the
student came back.

---

## When you get tired of the free plan

Cloud sync makes free hosting usable, but the free tier still sleeps after 15
minutes of no visitors (the next visit takes ~50 seconds to wake up). If you want
it solid later:

- **Render persistent disk** — paid instance (~$7/mo). Mount a disk at `/var/data`
  and set `DB_PATH=/var/data/hostel.db`. No code change needed, the variable is
  already supported.
- **Cheap VPS** (Hetzner ~€4.5/mo) — real disk, SQLite is happy there.
- **Turso or Neon** (free hosted database) — needs a code change; ask me and I
  will wire it up.
