const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const initSqlJs = require('sql.js');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const cors = require('cors');
const persistence = require('./persistence');

// ─── Configuration ───────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const JWT_SECRET = process.env.JWT_SECRET || 'hms-2024-super-secret-key-change-this-in-production-abc123xyz789';
const QR_TOKEN_TTL_MS = 6000; // 6 seconds

// DB_PATH can be overridden (e.g. a mounted Render disk at /var/data/hostel.db)
const DB_PATH = process.env.DB_PATH
  ? path.resolve(process.env.DB_PATH)
  : path.join(__dirname, 'hostel.db');

const UPLOAD_DIR = process.env.UPLOAD_DIR
  ? path.resolve(process.env.UPLOAD_DIR)
  : path.join(__dirname, 'uploads');

// Make sure the DB's parent folder exists (needed for custom mounts)
if (!fs.existsSync(path.dirname(DB_PATH))) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
}

// Ensure uploads directory exists
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// ─── Logging ─────────────────────────────────────────────────────
const log = {
  info: (msg) => console.log(`[INFO] ${new Date().toISOString()} - ${msg}`),
  error: (msg) => console.error(`[ERROR] ${new Date().toISOString()} - ${msg}`),
  warn: (msg) => console.warn(`[WARN] ${new Date().toISOString()} - ${msg}`)
};

// ─── sql.js Database Wrapper ─────────────────────────────────────
class Database {
  constructor(sqlJsDb, filePath) {
    this._db = sqlJsDb;
    this._filePath = filePath;
    this._inTransaction = false;
  }

  prepare(sql) {
    const self = this;
    return {
      run(...params) {
        self._db.run(sql, params.length ? params : undefined);
        const lastId = self._getLastId();
        const changes = self._db.getRowsModified();
        if (!self._inTransaction) self._save();
        return { lastInsertRowid: lastId, changes };
      },
      get(...params) {
        const stmt = self._db.prepare(sql);
        try {
          if (params.length) stmt.bind(params);
          if (stmt.step()) return stmt.getAsObject();
          return undefined;
        } finally {
          stmt.free();
        }
      },
      all(...params) {
        const results = [];
        const stmt = self._db.prepare(sql);
        try {
          if (params.length) stmt.bind(params);
          while (stmt.step()) results.push(stmt.getAsObject());
        } finally {
          stmt.free();
        }
        return results;
      }
    };
  }

  _getLastId() {
    const stmt = this._db.prepare("SELECT last_insert_rowid() as id");
    try {
      if (stmt.step()) return stmt.getAsObject().id;
      return 0;
    } finally {
      stmt.free();
    }
  }

  exec(sql) {
    const statements = sql.split(';').map(s => s.trim()).filter(s => s.length > 0);
    for (const stmt of statements) {
      this._db.run(stmt + ';');
    }
  }

  pragma(str) {
    try { this._db.run(`PRAGMA ${str}`); } catch (e) { /* ignore */ }
  }

  transaction(fn) {
    const self = this;
    return function (...args) {
      self._inTransaction = true;
      self._db.run("BEGIN TRANSACTION");
      try {
        const result = fn(...args);
        self._db.run("COMMIT");
        self._inTransaction = false;
        self._save();
        return result;
      } catch (err) {
        self._inTransaction = false;
        try { self._db.run("ROLLBACK"); } catch (e) { /* ignore */ }
        throw err;
      }
    };
  }

  _save() {
    if (this._filePath) {
      try {
        const data = this._db.export();
        const buffer = Buffer.from(data);
        fs.writeFileSync(this._filePath, buffer);
        // Keep a copy outside the container (GitHub / local .backup)
        persistence.markDirty(this._filePath);
      } catch (e) {
        log.error(`DB save error: ${e.message}`);
      }
    }
  }
}

let db;

// ─── Initialize Database ─────────────────────────────────────────
async function initDatabase() {
  const SQL = await initSqlJs();
  let sqlJsDb;

  // ── Boot sequence for ephemeral hosts (Render free tier) ──────
  // Priority: newest of {local file, local .backup, cloud copy in GitHub}
  persistence.setLogger(log);

  let chosen = null; // { buffer, source }

  const localExists = fs.existsSync(DB_PATH);
  const backupPath = `${DB_PATH}.backup`;
  const backupExists = fs.existsSync(backupPath);

  if (localExists) {
    chosen = { buffer: fs.readFileSync(DB_PATH), source: 'local file' };
  } else if (backupExists) {
    chosen = { buffer: fs.readFileSync(backupPath), source: 'local backup' };
    log.warn('[boot] hostel.db missing — restoring from local .backup');
  }

  if (persistence.githubEnabled()) {
    const cloud = await persistence.pullDb();
    if (cloud && cloud.buffer.length > 100) {
      const localMtime = chosen ? fs.statSync(localExists ? DB_PATH : backupPath).mtimeMs : 0;
      if (!chosen || cloud.updatedAt.getTime() > localMtime || localMtime === 0) {
        chosen = { buffer: cloud.buffer, source: 'cloud (GitHub)' };
      } else {
        log.info('[boot] Local copy is newer than the cloud copy — keeping local.');
      }
    }
  }

  if (chosen) {
    try {
      sqlJsDb = new SQL.Database(chosen.buffer);
      log.info(`Loaded database from ${chosen.source}`);
      // Write it back to the canonical path so everything is consistent
      try { fs.writeFileSync(DB_PATH, chosen.buffer); } catch (e) { /* ignore */ }
    } catch (e) {
      log.warn(`Could not open the saved database (${e.message}) — starting fresh`);
      sqlJsDb = new SQL.Database();
    }
  } else {
    sqlJsDb = new SQL.Database();
    log.info('Created new database (no saved copy found)');
  }

  db = new Database(sqlJsDb, DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL,
      student_id INTEGER,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      photo_url TEXT DEFAULT '',
      name TEXT NOT NULL,
      enrollment_no TEXT UNIQUE NOT NULL,
      phone TEXT NOT NULL,
      branch TEXT NOT NULL,
      section TEXT NOT NULL,
      blood_group TEXT DEFAULT '',
      parent_name TEXT NOT NULL,
      parent_phone TEXT NOT NULL,
      hostel_name TEXT NOT NULL,
      room_no TEXT NOT NULL,
      floor TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      current_status TEXT DEFAULT 'OUTSIDE_CAMPUS',
      last_checkout TEXT,
      last_checkin TEXT,
      last_outside_duration TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS campus_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      event_type TEXT NOT NULL,
      event_date TEXT NOT NULL,
      event_time TEXT NOT NULL,
      outside_duration TEXT DEFAULT '',
      gate_pass_user_id INTEGER,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS attendance_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      checkout_time TEXT NOT NULL,
      checkin_time TEXT,
      outside_duration TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS qr_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      token TEXT NOT NULL,
      issued_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      used_at TEXT,
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      username TEXT,
      role TEXT,
      action TEXT NOT NULL,
      target_student_id INTEGER,
      target_student_info TEXT,
      details TEXT,
      result TEXT,
      ip_address TEXT,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  // Attendance table
  db.exec(`
    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      status TEXT DEFAULT 'present',
      marked_by TEXT DEFAULT 'self',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      UNIQUE(student_id, date)
    )
  `);

  // Settings table for attendance time
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  // ─── Leave / Outpass requests ───────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS leaves (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      leave_type TEXT DEFAULT 'HOME',
      reason TEXT NOT NULL,
      destination TEXT DEFAULT '',
      from_date TEXT NOT NULL,
      to_date TEXT NOT NULL,
      parent_contact TEXT DEFAULT '',
      status TEXT DEFAULT 'PENDING',
      warden_remark TEXT DEFAULT '',
      reviewed_by INTEGER,
      reviewed_at TEXT,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  // ─── Complaints / maintenance tickets ───────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS complaints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      category TEXT DEFAULT 'OTHER',
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      priority TEXT DEFAULT 'NORMAL',
      status TEXT DEFAULT 'OPEN',
      warden_reply TEXT DEFAULT '',
      handled_by INTEGER,
      resolved_at TEXT,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  // ─── Notice board ───────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS notices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      category TEXT DEFAULT 'GENERAL',
      pinned INTEGER DEFAULT 0,
      hostel TEXT DEFAULT 'ALL',
      created_by INTEGER,
      created_by_name TEXT DEFAULT 'Warden',
      created_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  // ─── Visitor log at the gate ────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS visitors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      visitor_name TEXT NOT NULL,
      visitor_phone TEXT DEFAULT '',
      relation TEXT DEFAULT '',
      purpose TEXT DEFAULT '',
      id_proof TEXT DEFAULT '',
      in_time TEXT NOT NULL,
      out_time TEXT,
      logged_by INTEGER,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  // ─── Emergency SOS alerts ───────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS sos_alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      message TEXT DEFAULT '',
      location TEXT DEFAULT '',
      status TEXT DEFAULT 'ACTIVE',
      acknowledged_by INTEGER,
      acknowledged_at TEXT,
      resolved_at TEXT,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  // ─── Night roll call ────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS roll_calls (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      present INTEGER DEFAULT 1,
      marked_by INTEGER,
      marked_at TEXT DEFAULT (datetime('now','localtime'))
    )
  `);

  // Create indexes
  try { db.exec("CREATE INDEX idx_students_status ON students(current_status)"); } catch {}
  try { db.exec("CREATE INDEX idx_campus_events_student ON campus_events(student_id)"); } catch {}
  try { db.exec("CREATE INDEX idx_qr_tokens_token ON qr_tokens(token)"); } catch {}
  try { db.exec("CREATE INDEX idx_qr_tokens_student ON qr_tokens(student_id)"); } catch {}
  try { db.exec("CREATE INDEX idx_attendance_student_date ON attendance(student_id, date)"); } catch {}
  try { db.exec("CREATE INDEX idx_leaves_student ON leaves(student_id)"); } catch {}
  try { db.exec("CREATE INDEX idx_leaves_status ON leaves(status)"); } catch {}
  try { db.exec("CREATE INDEX idx_complaints_student ON complaints(student_id)"); } catch {}
  try { db.exec("CREATE INDEX idx_complaints_status ON complaints(status)"); } catch {}
  try { db.exec("CREATE INDEX idx_visitors_student ON visitors(student_id)"); } catch {}
  try { db.exec("CREATE INDEX idx_sos_status ON sos_alerts(status)"); } catch {}
  try { db.exec("CREATE INDEX idx_rollcall_date ON roll_calls(date)"); } catch {}

  // ─── Schema migrations (safe / idempotent) ─────────────────────
  runMigrations();

  log.info('Database tables ready');
  seedData();

  // Restore any student photo files that were wiped together with the disk
  restoreUploadsFromDb();

  // Hook change tracking so the DB gets pushed to durable storage
  persistence.attach(DB_PATH, async (filePath) => {
    persistence.writeLocalBackup(filePath);
    if (!persistence.githubEnabled()) return true; // local-only mode
    return persistence.syncNow(filePath);
  });

  // Keep one backup from the very start of this run
  persistence.writeLocalBackup(DB_PATH);
}

// Adds missing columns to older databases without losing data.
function runMigrations() {
  const addColumn = (table, column, definition) => {
    try {
      const cols = db.prepare(`PRAGMA table_info(${table})`).all();
      if (!cols.some(c => c.name === column)) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
        log.info(`[migration] Added ${table}.${column}`);
      }
    } catch (e) {
      log.warn(`[migration] ${table}.${column}: ${e.message}`);
    }
  };

  // users.is_active — required by the reactivate endpoint
  addColumn('users', 'is_active', 'INTEGER DEFAULT 1');
  // students.photo_data — base64 copy of the photo so it survives disk wipes
  addColumn('students', 'photo_data', 'TEXT');
  // students.last_modified — helps pick the newest record when merging backups
  addColumn('students', 'last_modified', "TEXT DEFAULT ''");
}

/**
 * Photos live in uploads/ on disk, which is wiped along with the database on
 * ephemeral hosts. We keep a base64 copy inside the DB, so write the files
 * back out whenever they are missing.
 */
function restoreUploadsFromDb() {
  try {
    const rows = db.prepare("SELECT photo_url, photo_data FROM students WHERE photo_data IS NOT NULL AND photo_data != ''").all();
    let restored = 0;
    for (const row of rows) {
      if (!row.photo_url || !row.photo_url.startsWith('/uploads/')) continue;
      const fileName = path.basename(row.photo_url);
      const target = path.join(UPLOAD_DIR, fileName);
      if (fs.existsSync(target)) continue;
      try {
        const raw = row.photo_data.includes(',') ? row.photo_data.split(',')[1] : row.photo_data;
        fs.writeFileSync(target, Buffer.from(raw, 'base64'));
        restored++;
      } catch (e) { /* skip bad image */ }
    }
    if (restored) log.info(`[uploads] Restored ${restored} student photo(s) from the database`);
  } catch (e) {
    log.warn(`[uploads] Restore skipped: ${e.message}`);
  }
}

// ─── Seed Data ───────────────────────────────────────────────────
function seedData() {
  const wardenExists = db.prepare("SELECT id FROM users WHERE username = 'warden'").get();
  if (!wardenExists) {
    const hash = bcrypt.hashSync('warden123', 10);
    db.prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)").run('warden', hash, 'WARDEN');
  }

  const gatepassExists = db.prepare("SELECT id FROM users WHERE username = 'gatepass'").get();
  if (!gatepassExists) {
    const hash = bcrypt.hashSync('gatepass123', 10);
    db.prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)").run('gatepass', hash, 'GET_PASS');
  }

  const studentCount = db.prepare("SELECT COUNT(*) as cnt FROM students").get();
  if (studentCount.cnt === 0) {
    const students = [
      { name: 'Rahul Sharma', enrollment: '22CS101', phone: '9876543210', branch: 'CSE', section: 'A', blood: 'B+', parent: 'Rajesh Sharma', parentPhone: '9876543200', hostel: 'Boys Hostel', room: '204', floor: '2', status: 'IN_CAMPUS' },
      { name: 'Aman Kumar', enrollment: '22CS115', phone: '9876543211', branch: 'CSE', section: 'B', blood: 'O+', parent: 'Suresh Kumar', parentPhone: '9876543201', hostel: 'Boys Hostel', room: '312', floor: '3', status: 'IN_CAMPUS' },
      { name: 'Priya Patel', enrollment: '22CS120', phone: '9876543212', branch: 'CSE', section: 'A', blood: 'A+', parent: 'Mahesh Patel', parentPhone: '9876543202', hostel: 'Girls Hostel', room: '105', floor: '1', status: 'IN_CAMPUS' },
      { name: 'Sneha Verma', enrollment: '22EC108', phone: '9876543213', branch: 'ECE', section: 'A', blood: 'AB+', parent: 'Ramesh Verma', parentPhone: '9876543203', hostel: 'Girls Hostel', room: '201', floor: '2', status: 'IN_CAMPUS' },
      { name: 'Vikram Singh', enrollment: '22ME130', phone: '9876543214', branch: 'ME', section: 'A', blood: 'B-', parent: 'Hari Singh', parentPhone: '9876543204', hostel: 'Boys Hostel', room: '118', floor: '1', status: 'IN_CAMPUS' },
    ];

    const now = new Date();
    // Use IST, not the server's UTC clock, so times match what users see
    const { date: dateStr, time: timeStr } = istNow();

    const seedTransaction = db.transaction(() => {
      students.forEach((s) => {
        const hash = bcrypt.hashSync('student123', 10);
        const lastCheckin = s.status === 'IN_CAMPUS' ? `${dateStr} ${timeStr}` : null;
        const lastCheckout = s.status === 'OUTSIDE_CAMPUS' ? `${dateStr} ${timeStr}` : null;

        const result = db.prepare(`
          INSERT INTO students (photo_url, name, enrollment_no, phone, branch, section, blood_group, parent_name, parent_phone, hostel_name, room_no, floor, password_hash, current_status, last_checkin, last_checkout)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run('', s.name, s.enrollment, s.phone, s.branch, s.section, s.blood, s.parent, s.parentPhone, s.hostel, s.room, s.floor, hash, s.status, lastCheckin, lastCheckout);

        const sid = result.lastInsertRowid;
        db.prepare("INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, 'STUDENT', ?)")
          .run(s.enrollment.toLowerCase(), hash, sid);
        db.prepare("INSERT INTO campus_events (student_id, event_type, event_date, event_time, gate_pass_user_id) VALUES (?, ?, ?, ?, ?)")
          .run(sid, s.status === 'IN_CAMPUS' ? 'CHECK_IN' : 'CHECK_OUT', dateStr, timeStr, 2);
      });
    });
    seedTransaction();
    log.info(`Seed data inserted: ${students.length} students, 1 warden, 1 gate pass staff`);
  }

  // Set default attendance time window if not exists
  const startTimeExists = db.prepare("SELECT value FROM settings WHERE key = 'attendance_start_time'").get();
  if (!startTimeExists) {
    db.prepare("INSERT INTO settings (key, value) VALUES (?, ?)").run('attendance_start_time', '21:00');
    db.prepare("INSERT INTO settings (key, value) VALUES (?, ?)").run('attendance_end_time', '22:00');
    log.info('Default attendance window set to 21:00 - 22:00 (9 PM - 10 PM)');
  }

  seedDemoContent();

  // Curfew + hostel rules defaults
  const defaults = {
    curfew_time: '22:30',
    late_grace_minutes: '30',
    night_rollcall_enabled: '1',
    hostel_capacity_boys: '120',
    hostel_capacity_girls: '100',
    sos_enabled: '1',
    auto_absent_after_hours: '24'
  };
  for (const [key, value] of Object.entries(defaults)) {
    const exists = db.prepare("SELECT value FROM settings WHERE key = ?").get(key);
    if (!exists) db.prepare("INSERT INTO settings (key, value) VALUES (?, ?)").run(key, value);
  }
}

/**
 * Fills the newer modules with a small amount of realistic content the first
 * time the app runs, so the dashboards are not empty on a fresh deployment.
 * Only runs when the tables are empty — it never overwrites real data.
 */
function seedDemoContent() {
  try {
    const noticeCount = db.prepare("SELECT COUNT(*) c FROM notices").get();
    if (!noticeCount || noticeCount.c !== 0) return;

    const first = db.prepare("SELECT id, name FROM students WHERE is_active = 1 ORDER BY id LIMIT 1").get();
    const second = db.prepare("SELECT id, name FROM students WHERE is_active = 1 ORDER BY id LIMIT 1 OFFSET 1").get();
    if (!first) return;

    const tx = db.transaction(() => {
      const notice = db.prepare("INSERT INTO notices (title, body, category, pinned, hostel, created_by_name) VALUES (?, ?, ?, ?, ?, 'Warden')");
      notice.run('Water supply maintenance', 'Water supply in Boys Hostel will be shut from 10:00 AM to 1:00 PM on Saturday for tank cleaning. Please store water in advance.', 'MAINTENANCE', 1, 'Boys Hostel');
      notice.run('Diwali holiday — gate timings', 'The hostel gate will close at 10:00 PM on 4th October. Students going home must get an outpass approved before leaving.', 'EVENT', 0, 'ALL');
      notice.run('Mess menu update', 'From Monday, dinner will include an extra sweet item on Wednesdays and Sundays. Feedback is welcome at the warden office.', 'MESS', 0, 'ALL');

      const complaint = db.prepare("INSERT INTO complaints (student_id, category, title, description, priority, status, warden_reply) VALUES (?, ?, ?, ?, ?, ?, ?)");
      complaint.run(first.id, 'ELECTRICAL', 'Room light flickering', 'The tube light in my room flickers constantly and makes a buzzing sound at night.', 'NORMAL', 'IN_PROGRESS', 'Electrician has been informed, will visit this week.');

      // A sample request sitting in the warden's inbox (approve it to see the
      // ON LEAVE state appear on the student and gate pass dashboards)
      const today = istNow().date;
      const dayAfter = new Date(Date.now() + 2 * 86400000)
        .toLocaleString('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).split(', ')[0];
      db.prepare("INSERT INTO leaves (student_id, leave_type, reason, destination, from_date, to_date, parent_contact, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
        .run(first.id, 'HOME', 'Going home for a family function over the weekend.', 'Indore', today, dayAfter, '9876543211', 'PENDING');

      if (second) {
        const complaint2 = db.prepare("INSERT INTO complaints (student_id, category, title, description, priority, status) VALUES (?, ?, ?, ?, ?, ?)");
        complaint2.run(second.id, 'WIFI', 'Slow internet in evening', 'WiFi speed drops a lot between 8 PM and 11 PM in the B block corridor.', 'LOW', 'OPEN');
      }
    });
    tx();
    log.info('Demo content added: notices, complaints and a sample leave request');
  } catch (e) {
    log.warn(`Demo content skipped: ${e.message}`);
  }
}

// Small helper: read a setting with a fallback
function getSetting(key, fallback = '') {
  try {
    const row = db.prepare("SELECT value FROM settings WHERE key = ?").get(key);
    return row ? row.value : fallback;
  } catch (e) {
    return fallback;
  }
}

function setSetting(key, value) {
  const exists = db.prepare("SELECT value FROM settings WHERE key = ?").get(key);
  if (exists) {
    db.prepare("UPDATE settings SET value = ?, updated_at = datetime('now','localtime') WHERE key = ?").run(String(value), key);
  } else {
    db.prepare("INSERT INTO settings (key, value) VALUES (?, ?)").run(key, String(value));
  }
}

// Current IST date (YYYY-MM-DD) and time (HH:MM)
function istNow() {
  const now = new Date();
  const date = now.toLocaleString('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).split(', ')[0];
  const time = now.toLocaleString('en-GB', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: false });
  return { date, time, stamp: `${date} ${time}`, dayIndex: now.getUTCDay() };
}

function minutesOfDay(hhmm) {
  const [h, m] = String(hhmm || '00:00').split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

// Is a given HH:MM later than the curfew time (handles after-midnight curfews)?
function isPastCurfew(timeStr, curfewStr, graceMin) {
  const t = minutesOfDay(timeStr);
  const c = minutesOfDay(curfewStr) + (parseInt(graceMin, 10) || 0);
  return t > c;
}

// ─── Leave lookup helpers ────────────────────────────────────────
// A leave is "active" when it is approved and today falls inside its dates.
// That approval IS the student's permission to be outside — no code needed.
function activeLeaveOf(studentId) {
  try {
    const { date } = istNow();
    return db.prepare(`
      SELECT id, leave_type, reason, destination, from_date, to_date, warden_remark, reviewed_at
      FROM leaves
      WHERE student_id = ? AND status = 'APPROVED' AND from_date <= ? AND to_date >= ?
      ORDER BY id DESC LIMIT 1
    `).get(studentId, date, date) || null;
  } catch (e) { return null; }
}

// The next approved leave that has not started yet (shown as "upcoming")
function upcomingLeaveOf(studentId) {
  try {
    const { date } = istNow();
    return db.prepare(`
      SELECT id, leave_type, reason, destination, from_date, to_date, warden_remark
      FROM leaves
      WHERE student_id = ? AND status = 'APPROVED' AND from_date > ?
      ORDER BY from_date ASC LIMIT 1
    `).get(studentId, date) || null;
  } catch (e) { return null; }
}

// Attaches leave information to a student row for the dashboards
function withLeaveInfo(student) {
  if (!student) return student;
  const active = activeLeaveOf(student.id);
  const upcoming = active ? null : upcomingLeaveOf(student.id);
  return {
    ...student,
    on_leave: !!active,
    leave_type: active ? active.leave_type : null,
    leave_until: active ? active.to_date : null,
    leave_from: active ? active.from_date : null,
    leave_destination: active ? active.destination : null,
    leave_note: active ? active.warden_remark : null,
    upcoming_leave: upcoming ? { type: upcoming.leave_type, from: upcoming.from_date, to: upcoming.to_date } : null
  };
}

// ─── Express + Socket.IO Setup ───────────────────────────────────
const app = express();
const server = http.createServer(app);
const io = new Server(server, { 
  cors: { 
    origin: '*',
    methods: ['GET', 'POST']
  } 
});

// ─── Security Middleware ─────────────────────────────────────────
// frameguard is disabled on purpose: the app has to be viewable inside the
// preview iframe of the hosting/IDE environment. Everything else stays on.
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
  frameguard: false
}));

// CORS - allow known deployments, plus preview/sandbox hosts.
// Sandboxed preview iframes send "Origin: null", so that must be allowed too
// or every API call from the preview fails.
const extraOrigins = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

function isAllowedOrigin(origin) {
  if (!origin) return true;                    // same-origin / server-to-server
  if (origin === 'null') return true;          // sandboxed preview iframe
  if (extraOrigins.includes(origin)) return true;
  return /(^https?:\/\/)(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)
    || origin.endsWith('.onrender.com')
    || origin.endsWith('.e2b.app')
    || origin.endsWith('.arena.ai');
}

app.use(cors({
  origin: function (origin, callback) {
    if (isAllowedOrigin(origin)) return callback(null, true);
    log.warn(`[cors] Blocked origin: ${origin}`);
    callback(null, false);                     // refuse quietly instead of throwing
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Behind a host proxy (Render, Railway, etc.) the real client IP arrives in the
// X-Forwarded-For header. Without this, express-rate-limit v7 refuses to run and
// every /api/ request fails. "1" = trust exactly one proxy hop.
app.set('trust proxy', 1);

// Rate limiting - prevent brute force
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 30, // 30 tries per 15 min (still far too slow to brute force)
  message: { error: 'Too many login attempts. Please try again after 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
  // Never block the real client lookup if the header is missing
  validate: { xForwardedForHeader: false, trustProxy: false }
});

const generalLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 600, // the dashboards poll, so keep this generous
  message: { error: 'Too many requests. Please slow down.' },
  standardHeaders: true,
  legacyHeaders: false,
  validate: { xForwardedForHeader: false, trustProxy: false }
});

app.use('/api/auth/login', loginLimiter);
app.use('/api/', generalLimiter);

// Security headers (additional)
// NOTE: no X-Frame-Options here — the app must render inside a preview iframe.
// The CSP below allows embedding while still blocking other common attacks.
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  // Allow framing by the preview host / same origin, block nothing else needed
  res.setHeader('Content-Security-Policy', "frame-ancestors 'self' https: http:;");
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(UPLOAD_DIR));

// ─── Photo helper: keep a DB copy so photos survive a disk wipe ──
const MAX_PHOTO_STORE_BYTES = 700 * 1024; // only inline small photos in the DB

function photoToDataUrl(file) {
  try {
    if (!file || !file.path) return '';
    if (file.size && file.size > MAX_PHOTO_STORE_BYTES) return '';
    const buf = fs.readFileSync(file.path);
    if (buf.length > MAX_PHOTO_STORE_BYTES) return '';
    const ext = path.extname(file.path).toLowerCase();
    const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
    return `data:${mime};base64,${buf.toString('base64')}`;
  } catch (e) {
    return '';
  }
}

// ─── Multer for photo uploads ────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, `student-${Date.now()}${ext}`);
  }
});
const upload = multer({ 
  storage, 
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    if (extname && mimetype) cb(null, true);
    else cb(new Error('Only image files are allowed'));
  }
});

// ─── Auth Middleware ──────────────────────────────────────────────
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }
  try {
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Access denied. Insufficient permissions.' });
    }
    next();
  };
}

// ─── Audit Log Helper ────────────────────────────────────────────
function auditLog(userId, username, role, action, targetStudentId, targetStudentInfo, details, result, ip) {
  db.prepare(`INSERT INTO audit_log (user_id, username, role, action, target_student_id, target_student_info, details, result, ip_address) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(userId || null, username || '', role || '', action, targetStudentId || null, targetStudentInfo || '', details || '', result || 'SUCCESS', ip || '');
}

// ─── API Routes (same as before, abbreviated for space) ──────────
// [All the API routes from before go here - auth, students, QR, warden, getpass]
// For brevity, I'm including the key routes. Full implementation in actual deployment.

app.post('/api/auth/login', (req, res) => {
  const { username, password, role } = req.body;
  
  // Input validation
  if (!username || !password || !role) {
    return res.status(400).json({ error: 'Username, password, and role are required.' });
  }
  
  // Sanitize input - prevent injection
  const sanitizedUsername = String(username).trim().replace(/[^\w\s-]/g, '');
  const sanitizedRole = String(role).trim().toUpperCase();
  
  // Validate role
  if (!['STUDENT', 'WARDEN', 'GET_PASS'].includes(sanitizedRole)) {
    return res.status(400).json({ error: 'Invalid role.' });
  }
  
  // Prevent empty password
  if (password.length < 3) {
    return res.status(400).json({ error: 'Invalid credentials.' });
  }

  try {
    if (sanitizedRole === 'STUDENT') {
      const student = db.prepare("SELECT s.*, u.id as user_id FROM students s JOIN users u ON u.student_id = s.id WHERE LOWER(u.username) = ?").get(sanitizedUsername.toLowerCase());
      if (!student) return res.status(401).json({ error: 'Invalid credentials.' });
      if (!bcrypt.compareSync(password, student.password_hash)) return res.status(401).json({ error: 'Invalid credentials.' });
      if (!student.is_active) return res.status(403).json({ error: 'Account is deactivated. Contact warden.' });

      const token = jwt.sign({ id: student.user_id, role: 'STUDENT', student_id: student.id }, JWT_SECRET, { expiresIn: '8h' });
      auditLog(student.user_id, username, 'STUDENT', 'LOGIN', student.id, student.enrollment_no, 'Student login', 'SUCCESS', req.ip);
      
      return res.json({
        token,
        user: {
          id: student.user_id, role: 'STUDENT', student_id: student.id,
          name: student.name, enrollment_no: student.enrollment_no,
          hostel_name: student.hostel_name, room_no: student.room_no,
          photo_url: student.photo_url, current_status: student.current_status,
          last_checkout: student.last_checkout, last_checkin: student.last_checkin,
          last_outside_duration: student.last_outside_duration || ''
        }
      });
    } else {
      const user = db.prepare("SELECT * FROM users WHERE LOWER(username) = ? AND role = ?").get(sanitizedUsername.toLowerCase(), sanitizedRole);
      if (!user) return res.status(401).json({ error: 'Invalid credentials.' });
      if (!bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: 'Invalid credentials.' });

      const token = jwt.sign({ id: user.id, role: user.role, username: user.username }, JWT_SECRET, { expiresIn: '8h' });
      auditLog(user.id, username, sanitizedRole, 'LOGIN', null, '', `${sanitizedRole} login`, 'SUCCESS', req.ip);
      
      return res.json({ token, user: { id: user.id, role: user.role, username: user.username } });
    }
  } catch (err) {
    log.error(`Login error: ${err.message}`);
    return res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// [Include all other API routes from previous implementation...]
// Auth, QR, Student, Warden, Gate Pass routes

app.get('/api/auth/me', authMiddleware, (req, res) => {
  if (req.user.role === 'STUDENT') {
    const s = db.prepare("SELECT * FROM students WHERE id = ?").get(req.user.student_id);
    if (!s) return res.status(404).json({ error: 'Student not found.' });
    const leave = activeLeaveOf(s.id);
    return res.json({
      id: req.user.id, role: 'STUDENT', student_id: s.id,
      name: s.name, enrollment_no: s.enrollment_no,
      hostel_name: s.hostel_name, room_no: s.room_no,
      photo_url: s.photo_url, current_status: s.current_status,
      last_checkout: s.last_checkout, last_checkin: s.last_checkin,
      last_outside_duration: s.last_outside_duration || '',
      phone: s.phone, branch: s.branch, section: s.section,
      blood_group: s.blood_group, parent_name: s.parent_name,
      parent_phone: s.parent_phone, floor: s.floor,
      // Leave details so the student dashboard can show ON LEAVE
      active_leave: leave,
      on_leave: !!leave,
      upcoming_leave: leave ? null : upcomingLeaveOf(s.id)
    });
  }
  const u = db.prepare("SELECT id, username, role FROM users WHERE id = ?").get(req.user.id);
  return res.json(u);
});

// QR Routes
app.post('/api/qr/generate', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    const studentId = req.user.student_id;
    const now = new Date();
    const expires = new Date(now.getTime() + QR_TOKEN_TTL_MS);
    const token = crypto.randomBytes(24).toString('hex');

    db.prepare("UPDATE qr_tokens SET status = 'expired' WHERE student_id = ? AND status = 'active'").run(studentId);
    db.prepare("INSERT INTO qr_tokens (student_id, token, issued_at, expires_at, status) VALUES (?, ?, ?, ?, 'active')")
      .run(studentId, token, now.toISOString(), expires.toISOString());

    res.json({
      token,
      expires_at: expires.toISOString(),
      ttl_ms: QR_TOKEN_TTL_MS
    });
  } catch (err) {
    log.error(`QR generate error: ${err.message}`);
    res.status(500).json({ error: 'Failed to generate QR token.' });
  }
});

app.post('/api/qr/verify', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  try {
    const { token } = req.body;
    if (!token) return res.status(400).json({ error: 'No QR code received. Please scan the student QR again.' });

    // Scanned QR tokens only — there is no typed-code path
    const qrToken = db.prepare("SELECT * FROM qr_tokens WHERE token = ?").get(token);
    if (!qrToken) return res.status(400).json({ error: 'Invalid or expired QR code.' });
    if (qrToken.status !== 'active') return res.status(400).json({ error: 'QR code expired. Please scan the student\'s latest QR code.' });

    const now = new Date();
    const localDate = now.toLocaleString('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).split(', ')[0];
    const localTime = now.toLocaleString('en-GB', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: false });
    const dateStr = localDate;
    const timeStr = localTime;
    const timestamp = `${localDate} ${localTime}`;

    // Every token lives for 6 seconds only — ask for a fresh scan if it lapsed
    const expiresAt = new Date(qrToken.expires_at);
    if (now > expiresAt) {
      db.prepare("UPDATE qr_tokens SET status = 'expired' WHERE id = ?").run(qrToken.id);
      return res.status(400).json({ error: "QR code expired. Please scan the student's latest QR code." });
    }

    const student = db.prepare("SELECT * FROM students WHERE id = ? AND is_active = 1").get(qrToken.student_id);
    if (!student) return res.status(404).json({ error: 'Student record not found.' });

    db.prepare("UPDATE qr_tokens SET status = 'used', used_at = ? WHERE id = ?").run(now.toISOString(), qrToken.id);

    const currentStatus = student.current_status;
    let newStatus, eventType;
    if (currentStatus === 'IN_CAMPUS') {
      newStatus = 'OUTSIDE_CAMPUS';
      eventType = 'CHECK_OUT';
    } else {
      newStatus = 'IN_CAMPUS';
      eventType = 'CHECK_IN';
    }

    let outsideDuration = '';
    const updateTransaction = db.transaction(() => {
      if (eventType === 'CHECK_OUT') {
        db.prepare("UPDATE students SET current_status = ?, last_checkout = ?, last_outside_duration = '', updated_at = ? WHERE id = ?")
          .run(newStatus, timestamp, timestamp, student.id);
      } else {
        if (student.last_checkout) {
          const checkoutTime = new Date(student.last_checkout.replace(' ', 'T') + '+05:30');
          const diffMs = now.getTime() - checkoutTime.getTime();
          const totalMinutes = Math.max(0, Math.floor(diffMs / 60000));
          const hours = Math.floor(totalMinutes / 60);
          const minutes = totalMinutes % 60;
          outsideDuration = hours > 0 ? `${hours} Hour${hours > 1 ? 's' : ''} ${minutes} Minute${minutes !== 1 ? 's' : ''}` : `${minutes} Minute${minutes !== 1 ? 's' : ''}`;
        }
        db.prepare("UPDATE students SET current_status = ?, last_checkin = ?, last_outside_duration = ?, updated_at = ? WHERE id = ?")
          .run(newStatus, timestamp, outsideDuration, timestamp, student.id);
      }

      db.prepare("INSERT INTO campus_events (student_id, event_type, event_date, event_time, outside_duration, gate_pass_user_id) VALUES (?, ?, ?, ?, ?, ?)")
        .run(student.id, eventType, dateStr, timeStr, outsideDuration, req.user.id);

      if (eventType === 'CHECK_OUT') {
        db.prepare("INSERT INTO attendance_sessions (student_id, checkout_time) VALUES (?, ?)").run(student.id, timestamp);
      } else {
        const lastSession = db.prepare("SELECT * FROM attendance_sessions WHERE student_id = ? AND checkin_time IS NULL ORDER BY id DESC LIMIT 1").get(student.id);
        if (lastSession) {
          db.prepare("UPDATE attendance_sessions SET checkin_time = ?, outside_duration = ? WHERE id = ?")
            .run(timestamp, outsideDuration, lastSession.id);
        }
      }
    });
    updateTransaction();

    auditLog(req.user.id, req.user.username, 'GET_PASS', eventType, student.id, student.enrollment_no, `${eventType}: ${student.name}`, 'SUCCESS', req.ip);

    const updatedStudent = db.prepare("SELECT id, name, enrollment_no, hostel_name, room_no, current_status, last_checkin, last_checkout, last_outside_duration, photo_url FROM students WHERE id = ?").get(student.id);
    io.emit('status-update', {
      student: updatedStudent,
      event_type: eventType,
      event_time: timestamp,
      outside_duration: outsideDuration
    });

    res.json({
      success: true,
      student: {
        id: student.id, name: student.name, enrollment_no: student.enrollment_no,
        hostel_name: student.hostel_name, room_no: student.room_no,
        previous_status: currentStatus, new_status: newStatus,
        event_type: eventType, event_time: timestamp, outside_duration: outsideDuration
      }
    });
  } catch (err) {
    log.error(`QR verify error: ${err.message}`);
    res.status(500).json({ error: 'Verification failed. Please try again.' });
  }
});

// Student routes
app.get('/api/student/profile', authMiddleware, requireRole('STUDENT'), (req, res) => {
  const s = db.prepare("SELECT * FROM students WHERE id = ?").get(req.user.student_id);
  if (!s) return res.status(404).json({ error: 'Profile not found.' });
  res.json(s);
});

app.get('/api/student/history', authMiddleware, requireRole('STUDENT'), (req, res) => {
  const events = db.prepare("SELECT * FROM campus_events WHERE student_id = ? ORDER BY id DESC LIMIT 100").all(req.user.student_id);
  const sessions = db.prepare("SELECT * FROM attendance_sessions WHERE student_id = ? ORDER BY id DESC LIMIT 50").all(req.user.student_id);
  res.json({ events, sessions });
});

// Student registration
app.post('/api/auth/register', upload.single('photo'), (req, res) => {
  try {
    const { name, enrollment_no, phone, branch, section, blood_group, parent_name, parent_phone, hostel_name, room_no, floor, password, confirm_password } = req.body;
    if (!name || !enrollment_no || !phone || !branch || !section || !parent_name || !parent_phone || !hostel_name || !room_no || !floor || !password || !confirm_password) {
      return res.status(400).json({ error: 'All required fields must be filled.' });
    }
    if (password !== confirm_password) return res.status(400).json({ error: 'Passwords do not match.' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    if (!/^\d{10}$/.test(phone)) return res.status(400).json({ error: 'Phone number must be 10 digits.' });
    if (!/^\d{10}$/.test(parent_phone)) return res.status(400).json({ error: 'Parent phone number must be 10 digits.' });

    const existing = db.prepare("SELECT id FROM students WHERE enrollment_no = ?").get(enrollment_no);
    if (existing) return res.status(400).json({ error: 'A student with this enrollment number already exists.' });

    const photoUrl = req.file ? `/uploads/${req.file.filename}` : '';
    const photoData = photoToDataUrl(req.file);
    const passwordHash = bcrypt.hashSync(password, 10);

    const insertStudent = db.transaction(() => {
      const stmt = db.prepare(`
        INSERT INTO students (photo_url, photo_data, name, enrollment_no, phone, branch, section, blood_group, parent_name, parent_phone, hostel_name, room_no, floor, password_hash, current_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'IN_CAMPUS')
      `);
      const result = stmt.run(photoUrl, photoData, name.trim(), enrollment_no.trim(), phone, branch, section, blood_group || '', parent_name.trim(), parent_phone, hostel_name, room_no, floor, passwordHash);
      const sid = result.lastInsertRowid;
      db.prepare("INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, 'STUDENT', ?)")
        .run(enrollment_no.trim().toLowerCase(), passwordHash, sid);
      return sid;
    });
    const studentId = insertStudent();
    auditLog(null, enrollment_no, 'STUDENT', 'REGISTER', studentId, enrollment_no, 'New student account created', 'SUCCESS', req.ip);
    res.json({ success: true, message: 'Account created successfully. Please login.' });
  } catch (err) {
    log.error(`Registration error: ${err.message}`);
    log.error(`Stack: ${err.stack}`);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// Warden student management
app.post('/api/warden/students', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { name, enrollment_no, phone, branch, section, blood_group, parent_name, parent_phone, hostel_name, room_no, floor, password } = req.body;
    if (!name || !enrollment_no || !phone || !branch || !section || !parent_name || !parent_phone || !hostel_name || !room_no || !floor || !password) {
      return res.status(400).json({ error: 'All required fields must be filled.' });
    }
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    if (!/^\d{10}$/.test(phone)) return res.status(400).json({ error: 'Phone must be 10 digits.' });

    const existing = db.prepare("SELECT id FROM students WHERE enrollment_no = ?").get(enrollment_no);
    if (existing) return res.status(400).json({ error: 'Enrollment number already exists.' });

    const passwordHash = bcrypt.hashSync(password, 10);
    const insertTx = db.transaction(() => {
      const result = db.prepare(`
        INSERT INTO students (photo_url, name, enrollment_no, phone, branch, section, blood_group, parent_name, parent_phone, hostel_name, room_no, floor, password_hash, current_status)
        VALUES ('', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'IN_CAMPUS')
      `).run(name.trim(), enrollment_no.trim(), phone, branch, section, blood_group || '', parent_name.trim(), parent_phone, hostel_name, room_no, floor);
      const sid = result.lastInsertRowid;
      db.prepare("INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, 'STUDENT', ?)")
        .run(enrollment_no.trim().toLowerCase(), passwordHash, sid);
      return sid;
    });
    const sid = insertTx();
    auditLog(req.user.id, req.user.username, 'WARDEN', 'ADD_STUDENT', sid, enrollment_no, `Added student: ${name}`, 'SUCCESS', req.ip);
    res.json({ success: true, student_id: sid, message: 'Student added successfully.' });
  } catch (err) {
    log.error(`Add student error: ${err.message}`);
    res.status(500).json({ error: 'Failed to add student.' });
  }
});

app.put('/api/warden/students/:id', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const student = db.prepare("SELECT * FROM students WHERE id = ?").get(parseInt(req.params.id));
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    const { name, phone, branch, section, blood_group, parent_name, parent_phone, hostel_name, room_no, floor, password } = req.body;
    let query = "UPDATE students SET updated_at = datetime('now','localtime')";
    const params = [];
    if (name) { query += ", name = ?"; params.push(name.trim()); }
    if (phone) { query += ", phone = ?"; params.push(phone); }
    if (branch) { query += ", branch = ?"; params.push(branch); }
    if (section) { query += ", section = ?"; params.push(section); }
    if (blood_group !== undefined) { query += ", blood_group = ?"; params.push(blood_group); }
    if (parent_name) { query += ", parent_name = ?"; params.push(parent_name.trim()); }
    if (parent_phone) { query += ", parent_phone = ?"; params.push(parent_phone); }
    if (hostel_name) { query += ", hostel_name = ?"; params.push(hostel_name); }
    if (room_no) { query += ", room_no = ?"; params.push(room_no); }
    if (floor) { query += ", floor = ?"; params.push(floor); }
    if (password) {
      query += ", password_hash = ?";
      params.push(bcrypt.hashSync(password, 10));
    }
    query += " WHERE id = ?";
    params.push(parseInt(req.params.id));
    db.prepare(query).run(...params);
    if (password) db.prepare("UPDATE users SET password_hash = ? WHERE student_id = ?").run(bcrypt.hashSync(password, 10), parseInt(req.params.id));
    auditLog(req.user.id, req.user.username, 'WARDEN', 'EDIT_STUDENT', parseInt(req.params.id), student.enrollment_no, `Edited student: ${student.name}`, 'SUCCESS', req.ip);
    res.json({ success: true, message: 'Student updated successfully.' });
  } catch (err) {
    log.error(`Edit student error: ${err.message}`);
    res.status(500).json({ error: 'Failed to update student.' });
  }
});

// Reactivate a student
app.put('/api/warden/students/:id/reactivate', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const student = db.prepare("SELECT * FROM students WHERE id = ?").get(parseInt(req.params.id));
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    
    db.prepare("UPDATE students SET is_active = 1, updated_at = datetime('now','localtime') WHERE id = ?").run(parseInt(req.params.id));
    db.prepare("UPDATE users SET is_active = 1 WHERE student_id = ?").run(parseInt(req.params.id));
    
    log.info(`Student reactivated: ${student.name} (${student.enrollment_no})`);
    res.json({ success: true, message: 'Student reactivated successfully.' });
  } catch (err) {
    log.error(`Reactivate error: ${err.message}`);
    res.status(500).json({ error: 'Failed to reactivate student.' });
  }
});

app.delete('/api/warden/students/:id', authMiddleware, requireRole('WARDEN'), (req, res) => {
  const student = db.prepare("SELECT * FROM students WHERE id = ?").get(parseInt(req.params.id));
  if (!student) return res.status(404).json({ error: 'Student not found.' });
  // Hard delete: remove student, their attendance, and campus events
  db.prepare("DELETE FROM attendance WHERE student_id = ?").run(parseInt(req.params.id));
  db.prepare("DELETE FROM campus_events WHERE student_id = ?").run(parseInt(req.params.id));
  db.prepare("DELETE FROM students WHERE id = ?").run(parseInt(req.params.id));
  auditLog(req.user.id, req.user.username, 'WARDEN', 'DELETE_STUDENT', parseInt(req.params.id), student.enrollment_no, `Permanently deleted student: ${student.name}`, 'SUCCESS', req.ip);
  res.json({ success: true, message: 'Student and all associated data deleted permanently.' });
});

app.get('/api/warden/students/:id', authMiddleware, requireRole('WARDEN'), (req, res) => {
  const student = db.prepare("SELECT * FROM students WHERE id = ?").get(parseInt(req.params.id));
  if (!student) return res.status(404).json({ error: 'Student not found.' });
  const events = db.prepare("SELECT * FROM campus_events WHERE student_id = ? ORDER BY id DESC LIMIT 50").all(parseInt(req.params.id));
  const leaves = db.prepare("SELECT id, leave_type, reason, destination, from_date, to_date, status, warden_remark FROM leaves WHERE student_id = ? ORDER BY id DESC LIMIT 10").all(parseInt(req.params.id));
  res.json({ student: withLeaveInfo(student), events, leaves });
});

// Warden routes
app.get('/api/warden/monitoring', authMiddleware, requireRole('WARDEN'), (req, res) => {
  const inCampus = db.prepare("SELECT id, name, enrollment_no, hostel_name, room_no, photo_url, current_status, last_checkin, last_outside_duration FROM students WHERE is_active = 1 AND current_status = 'IN_CAMPUS' ORDER BY name").all();
  const outside = db.prepare("SELECT id, name, enrollment_no, hostel_name, room_no, photo_url, current_status, last_checkout FROM students WHERE is_active = 1 AND current_status = 'OUTSIDE_CAMPUS' ORDER BY name").all();
  const totalResult = db.prepare("SELECT COUNT(*) as cnt FROM students WHERE is_active = 1").get();
  const hostelResult = db.prepare("SELECT COUNT(DISTINCT hostel_name) as cnt FROM students WHERE is_active = 1").get();
  const inCampusWithLeave = inCampus.map(withLeaveInfo);
  const outsideWithLeave = outside.map(withLeaveInfo);
  const stats = { total: totalResult.cnt, in_campus: inCampus.length, outside: outside.length, hostels: hostelResult.cnt };
  const pendingLeavesRow = db.prepare("SELECT COUNT(*) c FROM leaves WHERE status = 'PENDING'").get();
  const openComplaintsRow = db.prepare("SELECT COUNT(*) c FROM complaints WHERE status IN ('OPEN','IN_PROGRESS')").get();
  const activeSosRow = db.prepare("SELECT COUNT(*) c FROM sos_alerts WHERE status = 'ACTIVE'").get();
  stats.pending_leaves = pendingLeavesRow ? pendingLeavesRow.c : 0;
  stats.open_complaints = openComplaintsRow ? openComplaintsRow.c : 0;
  stats.active_sos = activeSosRow ? activeSosRow.c : 0;
  const recentCheckouts = db.prepare("SELECT ce.*, s.name, s.enrollment_no FROM campus_events ce JOIN students s ON s.id = ce.student_id WHERE ce.event_type = 'CHECK_OUT' ORDER BY ce.id DESC LIMIT 10").all();
  const recentCheckins = db.prepare("SELECT ce.*, s.name, s.enrollment_no FROM campus_events ce JOIN students s ON s.id = ce.student_id WHERE ce.event_type = 'CHECK_IN' ORDER BY ce.id DESC LIMIT 10").all();
  const auditLogs = db.prepare("SELECT * FROM audit_log ORDER BY id DESC LIMIT 50").all();
  res.json({ in_campus: inCampusWithLeave, outside: outsideWithLeave, stats, recent_checkouts: recentCheckouts, recent_checkins: recentCheckins, audit_logs: auditLogs });
});

app.get('/api/warden/students', authMiddleware, requireRole('WARDEN'), (req, res) => {
  const { search, status, hostel, includeInactive } = req.query;
  let query = "SELECT * FROM students";
  const params = [];
  
  // If includeInactive is not set, default to active only
  if (!includeInactive || includeInactive === 'false') {
    query += " WHERE is_active = 1";
  }
  
  if (search) { 
    const whereClause = query.includes('WHERE') ? 'AND' : 'WHERE';
    query += ` ${whereClause} (LOWER(name) LIKE ? OR LOWER(enrollment_no) LIKE ?)`; 
    params.push(`%${search.toLowerCase()}%`, `%${search.toLowerCase()}%`); 
  }
  if (status) { 
    const whereClause = query.includes('WHERE') ? 'AND' : 'WHERE';
    query += ` ${whereClause} current_status = ?`; 
    params.push(status); 
  }
  if (hostel) { 
    const whereClause = query.includes('WHERE') ? 'AND' : 'WHERE';
    query += ` ${whereClause} hostel_name = ?`; 
    params.push(hostel); 
  }
  query += " ORDER BY name ASC";
  res.json(db.prepare(query).all(...params).map(withLeaveInfo));
});

// Gate Pass routes
app.get('/api/getpass/students', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  const { search, status, hostel } = req.query;
  let query = "SELECT id, name, enrollment_no, hostel_name, room_no, current_status, last_checkin, last_checkout, photo_url, is_active FROM students";
  const params = [];
  
  // Default to active only unless specified
  query += " WHERE is_active = 1";
  
  if (search) { 
    query += " AND (LOWER(name) LIKE ? OR LOWER(enrollment_no) LIKE ?)"; 
    params.push(`%${search.toLowerCase()}%`, `%${search.toLowerCase()}%`); 
  }
  if (status) { 
    query += " AND current_status = ?"; 
    params.push(status); 
  }
  if (hostel) { 
    query += " AND hostel_name = ?"; 
    params.push(hostel); 
  }
  query += " ORDER BY name ASC";
  // Flag who is on approved leave so the gate can see it at a glance
  res.json(db.prepare(query).all(...params).map(withLeaveInfo));
});

// Debug endpoint to see all students including inactive
app.get('/api/debug/students', authMiddleware, requireRole('WARDEN'), (req, res) => {
  const all = db.prepare("SELECT id, name, enrollment_no, is_active, current_status, created_at FROM students ORDER BY id DESC").all();
  res.json({ total: all.length, students: all });
});

// ─── Backup / Restore / Cloud Sync ───────────────────────────────
// Free hosts (Render free tier) wipe the disk on restart, so the warden can
// download a backup, and the server can keep a synced copy in GitHub.

const restoreUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 }
});

app.get('/api/warden/backup/status', authMiddleware, requireRole('WARDEN'), (req, res) => {
  const st = persistence.status();
  const students = db.prepare("SELECT COUNT(*) as c FROM students").get();
  let dbSizeKb = 0;
  try { dbSizeKb = Math.round(fs.statSync(DB_PATH).size / 1024); } catch (e) {}
  res.json({
    ...st,
    students: students ? students.c : 0,
    db_size_kb: dbSizeKb,
    db_path: DB_PATH,
    local_backup_exists: fs.existsSync(`${DB_PATH}.backup`)
  });
});

app.get('/api/warden/backup/download', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const buffer = fs.readFileSync(DB_PATH);
    const stamp = new Date().toISOString().slice(0, 10);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="hostel-backup-${stamp}.db"`);
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: 'Could not create backup.' });
  }
});

// Upload a previously downloaded .db file and swap it in live
app.post('/api/warden/backup/restore', authMiddleware, requireRole('WARDEN'), restoreUpload.single('backup'), async (req, res) => {
  try {
    if (!req.file || !req.file.buffer) {
      return res.status(400).json({ error: 'No backup file received.' });
    }
    if (req.file.buffer.length < 100) {
      return res.status(400).json({ error: 'That file is too small to be a database.' });
    }

    const SQL = await initSqlJs();
    let testDb;
    try {
      testDb = new SQL.Database(req.file.buffer);
      const check = testDb.exec("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='students'");
      const hasStudents = check && check[0] && check[0].values[0][0] > 0;
      if (!hasStudents) throw new Error('no students table');
    } catch (e) {
      return res.status(400).json({ error: 'Invalid backup file — could not open it as a database.' });
    }

    // Safety copy of what we have right now
    try {
      if (fs.existsSync(DB_PATH)) fs.copyFileSync(DB_PATH, `${DB_PATH}.before-restore`);
    } catch (e) {}

    fs.writeFileSync(DB_PATH, req.file.buffer);
    db = new Database(testDb, DB_PATH);
    db.pragma('foreign_keys = ON');
    runMigrations();
    restoreUploadsFromDb();

    const count = db.prepare("SELECT COUNT(*) as c FROM students").get();
    auditLog(req.user.id, req.user.username, 'WARDEN', 'RESTORE_BACKUP', null, '', `Restored backup with ${count.c} students`, 'SUCCESS', req.ip);
    io.emit('data_restored', { count: count.c });
    log.info(`[restore] Backup restored by warden — ${count.c} students`);

    res.json({ success: true, students: count.c, message: `Backup restored — ${count.c} students recovered.` });
  } catch (err) {
    log.error(`Restore error: ${err.message}`);
    res.status(500).json({ error: 'Restore failed.' });
  }
});

app.post('/api/warden/backup/sync', authMiddleware, requireRole('WARDEN'), async (req, res) => {
  if (!persistence.githubEnabled()) {
    return res.status(400).json({
      error: 'Cloud sync is not configured. Set GITHUB_TOKEN and GITHUB_REPO environment variables.'
    });
  }
  const ok = await persistence.syncNow(DB_PATH);
  res.json({ success: ok, ...persistence.status() });
});

// JSON export (human readable, useful for reports/submission)
app.get('/api/warden/export/json', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const students = db.prepare("SELECT * FROM students").all();
    const users = db.prepare("SELECT id, username, role, student_id, created_at FROM users").all();
    const events = db.prepare("SELECT * FROM campus_events ORDER BY id DESC LIMIT 2000").all();
    const attendance = db.prepare("SELECT * FROM attendance ORDER BY id DESC LIMIT 5000").all();
    const payload = {
      exported_at: new Date().toISOString(),
      counts: { students: students.length, users: users.length, events: events.length, attendance: attendance.length },
      students, users, campus_events: events, attendance
    };
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="hostel-export-${new Date().toISOString().slice(0, 10)}.json"`);
    res.send(JSON.stringify(payload, null, 2));
  } catch (err) {
    res.status(500).json({ error: 'Export failed.' });
  }
});

app.get('/api/getpass/recent', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  const events = db.prepare("SELECT ce.*, s.name, s.enrollment_no, s.hostel_name, s.room_no FROM campus_events ce JOIN students s ON s.id = ce.student_id ORDER BY ce.id DESC LIMIT 30").all();
  res.json(events);
});

app.get('/api/getpass/students/:id', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  const student = db.prepare("SELECT id, name, enrollment_no, phone, branch, section, blood_group, parent_name, parent_phone, hostel_name, room_no, floor, current_status, last_checkin, last_checkout, last_outside_duration, photo_url FROM students WHERE id = ? AND is_active = 1").get(parseInt(req.params.id));
  if (!student) return res.status(404).json({ error: 'Student not found.' });
  const events = db.prepare("SELECT * FROM campus_events WHERE student_id = ? ORDER BY id DESC LIMIT 20").all(parseInt(req.params.id));
  const leaves = db.prepare("SELECT id, leave_type, reason, destination, from_date, to_date, status, warden_remark FROM leaves WHERE student_id = ? ORDER BY id DESC LIMIT 5").all(parseInt(req.params.id));
  res.json({ student: withLeaveInfo(student), events, leaves });
});

app.get('/api/hostels', (req, res) => {
  const hostels = db.prepare("SELECT DISTINCT hostel_name FROM students WHERE is_active = 1 ORDER BY hostel_name").all();
  res.json(hostels.map(h => h.hostel_name));
});

/* ═══════════════════════════════════════════════════════════════
   LEAVE / OUTPASS WORKFLOW
   Student applies → warden approves → gate uses the pass code.
   ═══════════════════════════════════════════════════════════════ */

const LEAVE_TYPES = ['HOME', 'MEDICAL', 'EMERGENCY', 'COLLEGE', 'FEST', 'OTHER'];

app.post('/api/leaves', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    const { leave_type, reason, destination, from_date, to_date, parent_contact } = req.body;
    if (!reason || !from_date || !to_date) {
      return res.status(400).json({ error: 'Reason, from date and to date are required.' });
    }
    if (new Date(to_date) < new Date(from_date)) {
      return res.status(400).json({ error: 'The "to" date cannot be before the "from" date.' });
    }
    if (String(reason).trim().length < 5) {
      return res.status(400).json({ error: 'Please describe the reason (at least 5 characters).' });
    }
    const type = LEAVE_TYPES.includes(leave_type) ? leave_type : 'OTHER';

    // Block duplicate pending requests
    const pending = db.prepare("SELECT id FROM leaves WHERE student_id = ? AND status = 'PENDING'").get(req.user.student_id);
    if (pending) {
      return res.status(400).json({ error: 'You already have a request waiting for approval.' });
    }

    const student = db.prepare("SELECT name, enrollment_no FROM students WHERE id = ?").get(req.user.student_id);
    const info = db.prepare(`
      INSERT INTO leaves (student_id, leave_type, reason, destination, from_date, to_date, parent_contact)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(req.user.student_id, type, String(reason).trim(), String(destination || '').trim(), from_date, to_date, String(parent_contact || '').trim());

    auditLog(req.user.id, student ? student.enrollment_no : '', 'STUDENT', 'LEAVE_REQUEST', info.lastInsertRowid, student ? student.enrollment_no : '', `Leave request: ${type} ${from_date} → ${to_date}`, 'SUCCESS', req.ip);
    io.emit('leave-update', { action: 'created', leave_id: info.lastInsertRowid });
    res.json({ success: true, id: info.lastInsertRowid, message: 'Request sent to the warden.' });
  } catch (err) {
    log.error(`Leave request error: ${err.message}`);
    res.status(500).json({ error: 'Could not send the request.' });
  }
});

app.get('/api/leaves/mine', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    const rows = db.prepare("SELECT * FROM leaves WHERE student_id = ? ORDER BY id DESC").all(req.user.student_id);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not load your requests.' });
  }
});

app.put('/api/leaves/:id/cancel', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    const row = db.prepare("SELECT * FROM leaves WHERE id = ? AND student_id = ?").get(parseInt(req.params.id), req.user.student_id);
    if (!row) return res.status(404).json({ error: 'Request not found.' });
    if (row.status !== 'PENDING') return res.status(400).json({ error: 'Only pending requests can be cancelled.' });
    db.prepare("UPDATE leaves SET status = 'CANCELLED', updated_at = datetime('now','localtime') WHERE id = ?").run(row.id);
    io.emit('leave-update', { action: 'cancelled', leave_id: row.id });
    res.json({ success: true, message: 'Request cancelled.' });
  } catch (err) {
    res.status(500).json({ error: 'Could not cancel the request.' });
  }
});

app.get('/api/warden/leaves', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { status } = req.query;
    let query = `
      SELECT l.*, s.name, s.enrollment_no, s.hostel_name, s.room_no, s.photo_url, s.current_status, s.parent_phone
      FROM leaves l JOIN students s ON s.id = l.student_id
    `;
    const params = [];
    if (status) { query += " WHERE l.status = ?"; params.push(status); }
    query += " ORDER BY CASE l.status WHEN 'PENDING' THEN 0 WHEN 'APPROVED' THEN 1 ELSE 2 END, l.id DESC";
    res.json(db.prepare(query).all(...params));
  } catch (err) {
    log.error(`Warden leaves error: ${err.message}`);
    res.status(500).json({ error: 'Could not load leave requests.' });
  }
});

app.put('/api/warden/leaves/:id', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { action, remark } = req.body; // action: 'approve' | 'reject'
    const row = db.prepare("SELECT l.*, s.name, s.enrollment_no FROM leaves l JOIN students s ON s.id = l.student_id WHERE l.id = ?").get(parseInt(req.params.id));
    if (!row) return res.status(404).json({ error: 'Request not found.' });

    if (action === 'approve') {
      db.prepare(`
        UPDATE leaves SET status = 'APPROVED', warden_remark = ?, reviewed_by = ?, reviewed_at = ?, updated_at = datetime('now','localtime')
        WHERE id = ?
      `).run(String(remark || '').trim(), req.user.id, istNow().stamp, row.id);
      auditLog(req.user.id, req.user.username, 'WARDEN', 'LEAVE_APPROVE', row.id, row.enrollment_no, `Approved ${row.leave_type} leave for ${row.name}`, 'SUCCESS', req.ip);
      io.emit('leave-update', { action: 'approved', leave_id: row.id, student_id: row.student_id });
      return res.json({ success: true, message: `Leave approved for ${row.name}. The gate will now see this student as ON LEAVE.` });
    }

    if (action === 'reject') {
      db.prepare(`
        UPDATE leaves SET status = 'REJECTED', warden_remark = ?, reviewed_by = ?, reviewed_at = ?, updated_at = datetime('now','localtime')
        WHERE id = ?
      `).run(String(remark || '').trim(), req.user.id, istNow().stamp, row.id);
      auditLog(req.user.id, req.user.username, 'WARDEN', 'LEAVE_REJECT', row.id, row.enrollment_no, `Rejected leave for ${row.name}`, 'SUCCESS', req.ip);
      io.emit('leave-update', { action: 'rejected', leave_id: row.id, student_id: row.student_id });
      return res.json({ success: true, message: `Request from ${row.name} rejected.` });
    }

    res.status(400).json({ error: 'Action must be approve or reject.' });
  } catch (err) {
    log.error(`Leave review error: ${err.message}`);
    res.status(500).json({ error: 'Could not update the request.' });
  }
});

// Gate pass moves a student on approved leave in or out.
// The approved leave itself is the permission — no code to type or lose.
app.post('/api/gate/leave-entry', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  try {
    const studentId = parseInt(req.body.student_id, 10);
    if (!studentId) return res.status(400).json({ error: 'No student selected.' });

    const student = db.prepare("SELECT * FROM students WHERE id = ? AND is_active = 1").get(studentId);
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const leave = activeLeaveOf(studentId);
    if (!leave) {
      return res.status(400).json({
        error: `${student.name} has no approved leave for today. Use the QR scan instead.`
      });
    }

    const { date, time, stamp } = istNow();
    let eventType, newStatus, durationText = '';

    if (student.current_status === 'IN_CAMPUS') {
      eventType = 'CHECK_OUT';
      newStatus = 'OUTSIDE_CAMPUS';
      db.prepare("UPDATE students SET current_status = ?, last_checkout = ?, updated_at = datetime('now','localtime') WHERE id = ?")
        .run(newStatus, stamp, studentId);
    } else {
      eventType = 'CHECK_IN';
      newStatus = 'IN_CAMPUS';
      const co = student.last_checkout;
      if (co) {
        const diffMs = Math.max(0, new Date(`${date} ${time}`).getTime() - new Date(String(co).replace(' ', 'T') + '+05:30').getTime());
        const mins = Math.floor(diffMs / 60000);
        const h = Math.floor(mins / 60), m = mins % 60;
        durationText = h > 0 ? `${h}h ${m}m` : `${m} Minute${m === 1 ? '' : 's'}`;
      }
      db.prepare("UPDATE students SET current_status = ?, last_checkin = ?, last_outside_duration = ?, updated_at = datetime('now','localtime') WHERE id = ?")
        .run(newStatus, stamp, durationText, studentId);
      // Student is back — the leave is finished
      db.prepare("UPDATE leaves SET status = 'COMPLETED', updated_at = datetime('now','localtime') WHERE id = ?").run(leave.id);
      io.emit('leave-update', { action: 'completed', leave_id: leave.id, student_id: studentId });
    }

    db.prepare("INSERT INTO campus_events (student_id, event_type, event_date, event_time, outside_duration, gate_pass_user_id) VALUES (?, ?, ?, ?, ?, ?)")
      .run(studentId, eventType, date, time, durationText, req.user.id);
    auditLog(req.user.id, req.user.username, 'GET_PASS', `LEAVE_${eventType}`, studentId, student.enrollment_no,
      `${student.name} on ${leave.leave_type} leave — ${eventType === 'CHECK_OUT' ? 'left' : 'returned'}`, 'SUCCESS', req.ip);

    io.emit('status-update', {
      student: { id: studentId, name: student.name, enrollment_no: student.enrollment_no, hostel_name: student.hostel_name, room_no: student.room_no },
      event_type: eventType,
      event_time: stamp
    });

    res.json({
      success: true,
      event_type: eventType,
      message: `${student.name} ${eventType === 'CHECK_IN' ? 'returned from' : 'left on'} ${leave.leave_type.toLowerCase()} leave.`,
      student: {
        id: studentId, name: student.name, enrollment_no: student.enrollment_no,
        hostel_name: student.hostel_name, room_no: student.room_no, photo_url: student.photo_url || '',
        event_type: eventType, event_time: stamp, current_status: newStatus,
        outside_duration: durationText,
        leave_type: leave.leave_type, leave_until: leave.to_date, leave_destination: leave.destination || ''
      }
    });
  } catch (err) {
    log.error(`Leave entry error: ${err.message}`);
    res.status(500).json({ error: 'Could not record the leave entry.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   COMPLAINTS / MAINTENANCE
   ═══════════════════════════════════════════════════════════════ */

const COMPLAINT_CATEGORIES = ['ELECTRICAL', 'PLUMBING', 'WIFI', 'CLEANLINESS', 'FURNITURE', 'FOOD', 'SECURITY', 'OTHER'];
const COMPLAINT_PRIORITIES = ['LOW', 'NORMAL', 'HIGH', 'URGENT'];

app.post('/api/complaints', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    const { category, title, description, priority } = req.body;
    if (!title || !description) return res.status(400).json({ error: 'Title and description are required.' });
    if (String(title).trim().length < 3) return res.status(400).json({ error: 'Please give a short title.' });

    const info = db.prepare(`
      INSERT INTO complaints (student_id, category, title, description, priority)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      req.user.student_id,
      COMPLAINT_CATEGORIES.includes(category) ? category : 'OTHER',
      String(title).trim(),
      String(description).trim(),
      COMPLAINT_PRIORITIES.includes(priority) ? priority : 'NORMAL'
    );
    io.emit('complaint-update', { action: 'created', id: info.lastInsertRowid });
    res.json({ success: true, id: info.lastInsertRowid, message: 'Complaint registered. The warden has been notified.' });
  } catch (err) {
    log.error(`Complaint error: ${err.message}`);
    res.status(500).json({ error: 'Could not file the complaint.' });
  }
});

app.get('/api/complaints/mine', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    res.json(db.prepare("SELECT * FROM complaints WHERE student_id = ? ORDER BY id DESC").all(req.user.student_id));
  } catch (err) {
    res.status(500).json({ error: 'Could not load your complaints.' });
  }
});

app.get('/api/warden/complaints', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { status } = req.query;
    let query = `
      SELECT c.*, s.name, s.enrollment_no, s.hostel_name, s.room_no, s.photo_url
      FROM complaints c JOIN students s ON s.id = c.student_id
    `;
    const params = [];
    if (status) { query += " WHERE c.status = ?"; params.push(status); }
    query += " ORDER BY CASE c.status WHEN 'OPEN' THEN 0 WHEN 'IN_PROGRESS' THEN 1 ELSE 2 END, CASE c.priority WHEN 'URGENT' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'NORMAL' THEN 2 ELSE 3 END, c.id DESC";
    res.json(db.prepare(query).all(...params));
  } catch (err) {
    log.error(`Warden complaints error: ${err.message}`);
    res.status(500).json({ error: 'Could not load complaints.' });
  }
});

app.put('/api/warden/complaints/:id', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { status, reply } = req.body;
    const row = db.prepare("SELECT c.*, s.name, s.enrollment_no FROM complaints c JOIN students s ON s.id = c.student_id WHERE c.id = ?").get(parseInt(req.params.id));
    if (!row) return res.status(404).json({ error: 'Complaint not found.' });

    const allowed = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];
    const nextStatus = allowed.includes(status) ? status : row.status;
    const resolvedAt = (nextStatus === 'RESOLVED' || nextStatus === 'CLOSED') ? istNow().stamp : null;

    db.prepare(`
      UPDATE complaints SET status = ?, warden_reply = ?, handled_by = ?, resolved_at = ?, updated_at = datetime('now','localtime')
      WHERE id = ?
    `).run(nextStatus, String(reply !== undefined ? reply : row.warden_reply || '').trim(), req.user.id, resolvedAt, row.id);

    auditLog(req.user.id, req.user.username, 'WARDEN', 'COMPLAINT_UPDATE', row.id, row.enrollment_no, `Complaint #${row.id} → ${nextStatus}`, 'SUCCESS', req.ip);
    io.emit('complaint-update', { action: 'updated', id: row.id, student_id: row.student_id, status: nextStatus });
    res.json({ success: true, message: `Complaint marked ${nextStatus.replace('_', ' ').toLowerCase()}.` });
  } catch (err) {
    log.error(`Complaint update error: ${err.message}`);
    res.status(500).json({ error: 'Could not update the complaint.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   NOTICE BOARD
   ═══════════════════════════════════════════════════════════════ */

app.get('/api/notices', authMiddleware, (req, res) => {
  try {
    const hostel = req.user.role === 'STUDENT'
      ? (db.prepare("SELECT hostel_name FROM students WHERE id = ?").get(req.user.student_id) || {}).hostel_name
      : null;
    let rows = db.prepare("SELECT * FROM notices ORDER BY pinned DESC, id DESC LIMIT 50").all();
    if (hostel) rows = rows.filter(n => n.hostel === 'ALL' || n.hostel === hostel);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not load notices.' });
  }
});

app.post('/api/warden/notices', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { title, body, category, hostel, pinned } = req.body;
    if (!title || !body) return res.status(400).json({ error: 'Title and message are required.' });
    const info = db.prepare(`
      INSERT INTO notices (title, body, category, pinned, hostel, created_by, created_by_name)
      VALUES (?, ?, ?, ?, ?, ?, 'Warden')
    `).run(
      String(title).trim(), String(body).trim(),
      ['GENERAL', 'URGENT', 'EVENT', 'MAINTENANCE', 'MESS'].includes(category) ? category : 'GENERAL',
      pinned ? 1 : 0,
      ['ALL', 'Boys Hostel', 'Girls Hostel'].includes(hostel) ? hostel : 'ALL',
      req.user.id
    );
    auditLog(req.user.id, req.user.username, 'WARDEN', 'POST_NOTICE', info.lastInsertRowid, '', `Notice: ${title}`, 'SUCCESS', req.ip);
    io.emit('notice-update', { action: 'created', id: info.lastInsertRowid });
    res.json({ success: true, id: info.lastInsertRowid, message: 'Notice published.' });
  } catch (err) {
    log.error(`Notice error: ${err.message}`);
    res.status(500).json({ error: 'Could not publish the notice.' });
  }
});

app.delete('/api/warden/notices/:id', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const row = db.prepare("SELECT * FROM notices WHERE id = ?").get(parseInt(req.params.id));
    if (!row) return res.status(404).json({ error: 'Notice not found.' });
    db.prepare("DELETE FROM notices WHERE id = ?").run(row.id);
    io.emit('notice-update', { action: 'deleted', id: row.id });
    res.json({ success: true, message: 'Notice removed.' });
  } catch (err) {
    res.status(500).json({ error: 'Could not delete the notice.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   VISITOR LOG (gate pass role)
   ═══════════════════════════════════════════════════════════════ */

app.post('/api/gate/visitors', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  try {
    const { visitor_name, visitor_phone, relation, purpose, id_proof, student_id } = req.body;
    if (!visitor_name) return res.status(400).json({ error: 'Visitor name is required.' });
    if (visitor_phone && !/^\d{10}$/.test(visitor_phone)) {
      return res.status(400).json({ error: 'Visitor phone must be 10 digits.' });
    }
    const sid = student_id ? parseInt(student_id, 10) : null;
    const info = db.prepare(`
      INSERT INTO visitors (student_id, visitor_name, visitor_phone, relation, purpose, id_proof, in_time, logged_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(sid, String(visitor_name).trim(), String(visitor_phone || '').trim(), String(relation || '').trim(),
           String(purpose || '').trim(), String(id_proof || '').trim(), istNow().stamp, req.user.id);
    io.emit('visitor-update', { action: 'in', id: info.lastInsertRowid });
    res.json({ success: true, id: info.lastInsertRowid, message: 'Visitor entry recorded.' });
  } catch (err) {
    log.error(`Visitor error: ${err.message}`);
    res.status(500).json({ error: 'Could not record the visitor.' });
  }
});

app.get('/api/gate/visitors', authMiddleware, (req, res) => {
  try {
    const { active } = req.query;
    let query = `
      SELECT v.*, s.name AS student_name, s.enrollment_no, s.room_no, s.hostel_name
      FROM visitors v LEFT JOIN students s ON s.id = v.student_id
    `;
    if (active === 'true') query += " WHERE v.out_time IS NULL";
    query += " ORDER BY v.id DESC LIMIT 100";
    res.json(db.prepare(query).all());
  } catch (err) {
    res.status(500).json({ error: 'Could not load visitors.' });
  }
});

app.put('/api/gate/visitors/:id/out', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  try {
    const row = db.prepare("SELECT * FROM visitors WHERE id = ?").get(parseInt(req.params.id));
    if (!row) return res.status(404).json({ error: 'Visitor entry not found.' });
    if (row.out_time) return res.status(400).json({ error: 'This visitor is already checked out.' });
    db.prepare("UPDATE visitors SET out_time = ? WHERE id = ?").run(istNow().stamp, row.id);
    io.emit('visitor-update', { action: 'out', id: row.id });
    res.json({ success: true, message: `${row.visitor_name} checked out.` });
  } catch (err) {
    res.status(500).json({ error: 'Could not check out the visitor.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   EMERGENCY SOS
   ═══════════════════════════════════════════════════════════════ */

app.post('/api/sos', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    if (getSetting('sos_enabled', '1') !== '1') {
      return res.status(400).json({ error: 'Emergency alerts are switched off by the warden.' });
    }
    const open = db.prepare("SELECT id FROM sos_alerts WHERE student_id = ? AND status = 'ACTIVE'").get(req.user.student_id);
    if (open) return res.status(400).json({ error: 'You already have an active emergency alert. The warden has been notified.' });

    const { message, location } = req.body;
    const info = db.prepare("INSERT INTO sos_alerts (student_id, message, location) VALUES (?, ?, ?)")
      .run(req.user.student_id, String(message || '').trim().slice(0, 300), String(location || '').trim().slice(0, 200));

    const stu = db.prepare("SELECT name, enrollment_no, hostel_name, room_no FROM students WHERE id = ?").get(req.user.student_id);
    auditLog(req.user.id, stu ? stu.enrollment_no : '', 'STUDENT', 'SOS_RAISED', info.lastInsertRowid, stu ? stu.enrollment_no : '', 'Emergency alert raised', 'SUCCESS', req.ip);
    io.emit('sos-alert', {
      id: info.lastInsertRowid,
      student: stu || {},
      message: String(message || '').trim(),
      location: String(location || '').trim(),
      time: istNow().stamp
    });
    res.json({ success: true, message: 'Emergency alert sent to the warden.' });
  } catch (err) {
    log.error(`SOS error: ${err.message}`);
    res.status(500).json({ error: 'Could not send the alert.' });
  }
});

app.get('/api/warden/sos', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT a.*, s.name, s.enrollment_no, s.hostel_name, s.room_no, s.phone, s.parent_phone, s.photo_url
      FROM sos_alerts a JOIN students s ON s.id = a.student_id
      ORDER BY CASE a.status WHEN 'ACTIVE' THEN 0 WHEN 'ACKNOWLEDGED' THEN 1 ELSE 2 END, a.id DESC LIMIT 50
    `).all();
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not load alerts.' });
  }
});

app.put('/api/warden/sos/:id', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { status } = req.body;
    const row = db.prepare("SELECT * FROM sos_alerts WHERE id = ?").get(parseInt(req.params.id));
    if (!row) return res.status(404).json({ error: 'Alert not found.' });
    const next = ['ACKNOWLEDGED', 'RESOLVED'].includes(status) ? status : 'ACKNOWLEDGED';
    const stamp = istNow().stamp;
    if (next === 'ACKNOWLEDGED') {
      db.prepare("UPDATE sos_alerts SET status = ?, acknowledged_by = ?, acknowledged_at = ? WHERE id = ?").run(next, req.user.id, stamp, row.id);
    } else {
      db.prepare("UPDATE sos_alerts SET status = ?, resolved_at = ? WHERE id = ?").run(next, stamp, row.id);
    }
    io.emit('sos-update', { id: row.id, status: next });
    res.json({ success: true, message: next === 'ACKNOWLEDGED' ? 'Alert acknowledged.' : 'Alert resolved.' });
  } catch (err) {
    res.status(500).json({ error: 'Could not update the alert.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   NIGHT ROLL CALL + CURFEW
   ═══════════════════════════════════════════════════════════════ */

app.get('/api/warden/rollcall', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const date = req.query.date || istNow().date;
    const students = db.prepare(`
      SELECT s.id, s.name, s.enrollment_no, s.hostel_name, s.room_no, s.current_status, s.last_checkout,
             r.present AS roll_status, r.marked_at
      FROM students s
      LEFT JOIN roll_calls r ON r.student_id = s.id AND r.date = ?
      WHERE s.is_active = 1
      ORDER BY s.hostel_name, s.room_no
    `).all(date);
    const marked = students.filter(s => s.roll_status !== null).length;
    res.json({ date, students, marked, total: students.length });
  } catch (err) {
    log.error(`Roll call error: ${err.message}`);
    res.status(500).json({ error: 'Could not load roll call.' });
  }
});

app.post('/api/warden/rollcall', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { student_id, date, present } = req.body;
    const d = date || istNow().date;
    if (!student_id) return res.status(400).json({ error: 'Student is required.' });
    const existing = db.prepare("SELECT id FROM roll_calls WHERE student_id = ? AND date = ?").get(parseInt(student_id), d);
    if (existing) {
      db.prepare("UPDATE roll_calls SET present = ?, marked_by = ?, marked_at = datetime('now','localtime') WHERE id = ?")
        .run(present ? 1 : 0, req.user.id, existing.id);
    } else {
      db.prepare("INSERT INTO roll_calls (student_id, date, present, marked_by) VALUES (?, ?, ?, ?)")
        .run(parseInt(student_id), d, present ? 1 : 0, req.user.id);
    }
    io.emit('rollcall-update', { student_id: parseInt(student_id), date: d, present: !!present });
    res.json({ success: true, message: present ? 'Marked present.' : 'Marked absent.' });
  } catch (err) {
    log.error(`Roll call save error: ${err.message}`);
    res.status(500).json({ error: 'Could not save roll call.' });
  }
});

app.post('/api/warden/rollcall/all', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const d = req.body.date || istNow().date;
    const present = req.body.present !== false;
    // Only students currently marked in campus count as present automatically
    const students = db.prepare("SELECT id, current_status FROM students WHERE is_active = 1").all();
    const tx = db.transaction(() => {
      for (const s of students) {
        const value = present ? (s.current_status === 'IN_CAMPUS' ? 1 : 0) : 0;
        const existing = db.prepare("SELECT id FROM roll_calls WHERE student_id = ? AND date = ?").get(s.id, d);
        if (existing) {
          db.prepare("UPDATE roll_calls SET present = ?, marked_by = ?, marked_at = datetime('now','localtime') WHERE id = ?").run(value, req.user.id, existing.id);
        } else {
          db.prepare("INSERT INTO roll_calls (student_id, date, present, marked_by) VALUES (?, ?, ?, ?)").run(s.id, d, value, req.user.id);
        }
      }
    });
    tx();
    io.emit('rollcall-update', { date: d, bulk: true });
    res.json({ success: true, message: present ? 'Roll call completed — everyone in campus marked present.' : 'Everyone marked absent.' });
  } catch (err) {
    log.error(`Bulk roll call error: ${err.message}`);
    res.status(500).json({ error: 'Could not complete roll call.' });
  }
});

// Students outside after curfew — the safety view wardens actually need
app.get('/api/warden/curfew', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const curfew = getSetting('curfew_time', '22:30');
    const grace = getSetting('late_grace_minutes', '30');
    const { time } = istNow();
    const outside = db.prepare(`
      SELECT id, name, enrollment_no, hostel_name, room_no, phone, parent_phone, photo_url, last_checkout, current_status
      FROM students WHERE is_active = 1 AND current_status = 'OUTSIDE_CAMPUS'
      ORDER BY last_checkout ASC
    `).all();

    const list = outside.map(s => {
      let minutesOut = 0;
      if (s.last_checkout) {
        minutesOut = Math.max(0, Math.floor((Date.now() - new Date(String(s.last_checkout).replace(' ', 'T') + '+05:30').getTime()) / 60000));
      }
      const late = isPastCurfew(time, curfew, grace);
      return { ...s, minutes_out: minutesOut, is_late: late };
    });

    // Approved leave for today means the student is legitimately away
    const today = istNow().date;
    const onLeaveIds = new Set(db.prepare(
      "SELECT student_id FROM leaves WHERE status = 'APPROVED' AND from_date <= ? AND to_date >= ?"
    ).all(today, today).map(r => r.student_id));

    res.json({
      curfew_time: curfew,
      grace_minutes: parseInt(grace, 10) || 0,
      current_time: time,
      is_after_curfew: isPastCurfew(time, curfew, grace),
      late_count: list.filter(s => s.is_late && !onLeaveIds.has(s.id)).length,
      outside: list.map(s => ({ ...s, on_leave: onLeaveIds.has(s.id) }))
    });
  } catch (err) {
    log.error(`Curfew error: ${err.message}`);
    res.status(500).json({ error: 'Could not load curfew data.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   ROOM OCCUPANCY
   ═══════════════════════════════════════════════════════════════ */

app.get('/api/warden/rooms', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT id, name, enrollment_no, hostel_name, room_no, floor, current_status, photo_url
      FROM students WHERE is_active = 1 ORDER BY hostel_name, CAST(room_no AS INTEGER), room_no
    `).all();

    const byHostel = {};
    for (const r of rows) {
      const h = r.hostel_name || 'Unknown';
      if (!byHostel[h]) byHostel[h] = {};
      const room = r.room_no || 'Unassigned';
      if (!byHostel[h][room]) byHostel[h][room] = [];
      byHostel[h][room].push(r);
    }

    const capacityBoys = parseInt(getSetting('hostel_capacity_boys', '120'), 10) || 120;
    const capacityGirls = parseInt(getSetting('hostel_capacity_girls', '100'), 10) || 100;

    const hostels = Object.entries(byHostel).map(([name, rooms]) => {
      const total = Object.values(rooms).reduce((a, b) => a + b.length, 0);
      const capacity = name.includes('Girls') ? capacityGirls : capacityBoys;
      return {
        name,
        total_students: total,
        capacity,
        occupancy_pct: capacity > 0 ? Math.round((total / capacity) * 100) : 0,
        rooms: Object.entries(rooms).map(([room_no, students]) => ({
          room_no,
          students,
          count: students.length,
          in_campus: students.filter(s => s.current_status === 'IN_CAMPUS').length
        })).sort((a, b) => (parseInt(a.room_no, 10) || 0) - (parseInt(b.room_no, 10) || 0))
      };
    });

    res.json({ hostels, totals: { students: rows.length } });
  } catch (err) {
    log.error(`Rooms error: ${err.message}`);
    res.status(500).json({ error: 'Could not load rooms.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   ANALYTICS
   ═══════════════════════════════════════════════════════════════ */

app.get('/api/warden/analytics', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const students = db.prepare("SELECT id, name, hostel_name, current_status FROM students WHERE is_active = 1").all();
    const inCampus = students.filter(s => s.current_status === 'IN_CAMPUS').length;
    const outside = students.length - inCampus;

    // Gate traffic for the last 7 days
    const { date: today } = istNow();
    const traffic = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const day = d.toLocaleString('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).split(', ')[0];
      const outCount = db.prepare("SELECT COUNT(*) c FROM campus_events WHERE event_type = 'CHECK_OUT' AND event_date = ?").get(day);
      const inCount = db.prepare("SELECT COUNT(*) c FROM campus_events WHERE event_type = 'CHECK_IN' AND event_date = ?").get(day);
      traffic.push({ day, label: day.slice(5), out: outCount ? outCount.c : 0, in: inCount ? inCount.c : 0 });
    }

    // Attendance summary (last 7 days)
    const attendance = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const day = d.toLocaleString('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).split(', ')[0];
      const present = db.prepare("SELECT COUNT(*) c FROM attendance WHERE date = ? AND status = 'present'").get(day);
      const absent = db.prepare("SELECT COUNT(*) c FROM attendance WHERE date = ? AND status = 'absent'").get(day);
      const p = present ? present.c : 0, a = absent ? absent.c : 0;
      attendance.push({ day, label: day.slice(5), present: p, absent: a, pct: (p + a) > 0 ? Math.round((p / (p + a)) * 100) : null });
    }

    // Complaints by category
    const complaintRows = db.prepare("SELECT category, status, COUNT(*) c FROM complaints GROUP BY category, status").all();
    const complaintMap = {};
    for (const r of complaintRows) {
      if (!complaintMap[r.category]) complaintMap[r.category] = { category: r.category, total: 0, open: 0, resolved: 0 };
      complaintMap[r.category].total += r.c;
      if (r.status === 'OPEN' || r.status === 'IN_PROGRESS') complaintMap[r.category].open += r.c;
      else complaintMap[r.category].resolved += r.c;
    }

    // Averages
    const avgOutsideRow = db.prepare(`
      SELECT AVG(CAST(REPLACE(REPLACE(last_outside_duration,'h',''),'m','') AS REAL)) avg_val
      FROM students WHERE last_outside_duration IS NOT NULL AND last_outside_duration != ''
    `).get();

    const leaveStats = db.prepare("SELECT status, COUNT(*) c FROM leaves GROUP BY status").all();
    const leaveMap = {};
    for (const l of leaveStats) leaveMap[l.status] = l.c;

    const sosOpen = db.prepare("SELECT COUNT(*) c FROM sos_alerts WHERE status = 'ACTIVE'").get();
    const complaintOpen = db.prepare("SELECT COUNT(*) c FROM complaints WHERE status IN ('OPEN','IN_PROGRESS')").get();
    const visitorsIn = db.prepare("SELECT COUNT(*) c FROM visitors WHERE out_time IS NULL").get();

    // Busiest hour of the day
    const hourRows = db.prepare(`
      SELECT substr(event_time, 1, 2) hh, COUNT(*) c FROM campus_events
      WHERE event_date >= date('now','-7 day') GROUP BY hh ORDER BY c DESC LIMIT 1
    `).all();

    res.json({
      totals: {
        students: students.length,
        in_campus: inCampus,
        outside,
        boys: students.filter(s => s.hostel_name === 'Boys Hostel').length,
        girls: students.filter(s => s.hostel_name === 'Girls Hostel').length,
        open_complaints: complaintOpen ? complaintOpen.c : 0,
        active_sos: sosOpen ? sosOpen.c : 0,
        visitors_inside: visitorsIn ? visitorsIn.c : 0,
        pending_leaves: leaveMap.PENDING || 0,
        approved_leaves: leaveMap.APPROVED || 0
      },
      traffic,
      attendance,
      complaints_by_category: Object.values(complaintMap).sort((a, b) => b.total - a.total),
      leave_status: leaveMap,
      avg_outside_hours: avgOutsideRow && avgOutsideRow.avg_val ? Number(avgOutsideRow.avg_val).toFixed(1) : '0',
      busiest_hour: hourRows.length ? `${hourRows[0].hh}:00` : '—'
    });
  } catch (err) {
    log.error(`Analytics error: ${err.message}`);
    res.status(500).json({ error: 'Could not build analytics.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   SETTINGS (warden) + CSV EXPORT
   ═══════════════════════════════════════════════════════════════ */

app.get('/api/warden/settings', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const keys = ['curfew_time', 'late_grace_minutes', 'night_rollcall_enabled', 'hostel_capacity_boys', 'hostel_capacity_girls', 'sos_enabled', 'attendance_start_time', 'attendance_end_time'];
    const out = {};
    for (const k of keys) out[k] = getSetting(k, '');
    res.json(out);
  } catch (err) {
    res.status(500).json({ error: 'Could not load settings.' });
  }
});

app.put('/api/warden/settings', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const allowed = ['curfew_time', 'late_grace_minutes', 'night_rollcall_enabled', 'hostel_capacity_boys', 'hostel_capacity_girls', 'sos_enabled'];
    const updates = [];
    for (const k of allowed) {
      if (req.body[k] !== undefined) {
        let v = String(req.body[k]).trim();
        if (k === 'curfew_time') {
          if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) {
            return res.status(400).json({ error: 'Curfew must be a real time in 24-hour format, e.g. 22:30.' });
          }
        }
        if (k === 'late_grace_minutes') {
          const n = parseInt(v, 10);
          if (isNaN(n) || n < 0 || n > 240) return res.status(400).json({ error: 'Grace period must be between 0 and 240 minutes.' });
          v = String(n);
        }
        if (k === 'hostel_capacity_boys' || k === 'hostel_capacity_girls') {
          const n = parseInt(v, 10);
          if (isNaN(n) || n < 1 || n > 5000) return res.status(400).json({ error: 'Capacity must be between 1 and 5000.' });
          v = String(n);
        }
        if (k === 'night_rollcall_enabled' || k === 'sos_enabled') v = (v === '1' || v === 'true') ? '1' : '0';
        setSetting(k, v);
        updates.push(k);
      }
    }
    auditLog(req.user.id, req.user.username, 'WARDEN', 'UPDATE_SETTINGS', null, '', `Updated: ${updates.join(', ')}`, 'SUCCESS', req.ip);
    io.emit('settings-update', { keys: updates });
    res.json({ success: true, message: 'Settings saved.', updated: updates });
  } catch (err) {
    log.error(`Settings error: ${err.message}`);
    res.status(500).json({ error: 'Could not save settings.' });
  }
});

app.get('/api/warden/export/csv', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const type = req.query.type || 'students';
    const esc = (v) => {
      const s = v === null || v === undefined ? '' : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const toCsv = (headers, rows) => [headers.join(','), ...rows.map(r => r.map(esc).join(','))].join('\n');

    let csv, filename;
    if (type === 'attendance') {
      const rows = db.prepare(`
        SELECT a.date, s.name, s.enrollment_no, s.hostel_name, s.room_no, a.status, a.marked_by, a.created_at
        FROM attendance a JOIN students s ON s.id = a.student_id ORDER BY a.date DESC, s.name LIMIT 5000
      `).all();
      csv = toCsv(['Date', 'Name', 'Enrollment', 'Hostel', 'Room', 'Status', 'Marked By', 'Marked At'],
        rows.map(r => [r.date, r.name, r.enrollment_no, r.hostel_name, r.room_no, r.status, r.marked_by, r.created_at]));
      filename = 'attendance';
    } else if (type === 'leaves') {
      const rows = db.prepare(`
        SELECT l.id, s.name, s.enrollment_no, l.leave_type, l.reason, l.from_date, l.to_date, l.status, l.warden_remark, l.created_at
        FROM leaves l JOIN students s ON s.id = l.student_id ORDER BY l.id DESC
      `).all();
      csv = toCsv(['ID', 'Name', 'Enrollment', 'Type', 'Reason', 'From', 'To', 'Status', 'Remark', 'Requested'],
        rows.map(r => [r.id, r.name, r.enrollment_no, r.leave_type, r.reason, r.from_date, r.to_date, r.status, r.warden_remark, r.created_at]));
      filename = 'leaves';
    } else if (type === 'complaints') {
      const rows = db.prepare(`
        SELECT c.id, s.name, s.enrollment_no, c.category, c.title, c.priority, c.status, c.warden_reply, c.created_at, c.resolved_at
        FROM complaints c JOIN students s ON s.id = c.student_id ORDER BY c.id DESC
      `).all();
      csv = toCsv(['ID', 'Name', 'Enrollment', 'Category', 'Title', 'Priority', 'Status', 'Reply', 'Filed', 'Resolved'],
        rows.map(r => [r.id, r.name, r.enrollment_no, r.category, r.title, r.priority, r.status, r.warden_reply, r.created_at, r.resolved_at]));
      filename = 'complaints';
    } else if (type === 'events') {
      const rows = db.prepare(`
        SELECT e.id, s.name, s.enrollment_no, s.hostel_name, s.room_no, e.event_type, e.event_date, e.event_time
        FROM campus_events e JOIN students s ON s.id = e.student_id ORDER BY e.id DESC LIMIT 5000
      `).all();
      csv = toCsv(['ID', 'Name', 'Enrollment', 'Hostel', 'Room', 'Event', 'When'],
        rows.map(r => [r.id, r.name, r.enrollment_no, r.hostel_name, r.room_no, r.event_type, `${r.event_date} ${r.event_time}`]));
      filename = 'gate_events';
    } else {
      const rows = db.prepare("SELECT * FROM students WHERE is_active = 1 ORDER BY name").all();
      csv = toCsv(['Name', 'Enrollment', 'Phone', 'Branch', 'Section', 'Blood Group', 'Parent', 'Parent Phone', 'Hostel', 'Room', 'Floor', 'Status', 'Joined'],
        rows.map(r => [r.name, r.enrollment_no, r.phone, r.branch, r.section, r.blood_group, r.parent_name, r.parent_phone, r.hostel_name, r.room_no, r.floor, r.current_status, r.created_at]));
      filename = 'students';
    }

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="hms-${filename}-${istNow().date}.csv"`);
    res.send('\uFEFF' + csv);
  } catch (err) {
    log.error(`CSV export error: ${err.message}`);
    res.status(500).json({ error: 'Could not export CSV.' });
  }
});

// Student's own dashboard summary (notices, leave status, complaints, alerts)
app.get('/api/student/summary', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    const sid = req.user.student_id;
    const student = db.prepare("SELECT * FROM students WHERE id = ?").get(sid);
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const pendingLeaves = db.prepare("SELECT COUNT(*) c FROM leaves WHERE student_id = ? AND status = 'PENDING'").get(sid);
    const approvedLeaves = db.prepare("SELECT COUNT(*) c FROM leaves WHERE student_id = ? AND status = 'APPROVED'").get(sid);
    const openComplaints = db.prepare("SELECT COUNT(*) c FROM complaints WHERE student_id = ? AND status IN ('OPEN','IN_PROGRESS')").get(sid);
    const activeSos = db.prepare("SELECT id FROM sos_alerts WHERE student_id = ? AND status = 'ACTIVE'").get(sid);

    const todayLeave = activeLeaveOf(sid);
    const upcomingLeave = todayLeave ? null : upcomingLeaveOf(sid);

    // Curfew countdown info
    const curfew = getSetting('curfew_time', '22:30');
    const { time } = istNow();

    res.json({
      student: {
        name: student.name, enrollment_no: student.enrollment_no, hostel_name: student.hostel_name,
        room_no: student.room_no, current_status: student.current_status, photo_url: student.photo_url,
        last_checkout: student.last_checkout, last_checkin: student.last_checkin,
        last_outside_duration: student.last_outside_duration
      },
      counts: {
        pending_leaves: pendingLeaves ? pendingLeaves.c : 0,
        approved_leaves: approvedLeaves ? approvedLeaves.c : 0,
        open_complaints: openComplaints ? openComplaints.c : 0
      },
      active_sos: !!activeSos,
      today_leave: todayLeave || null,
      upcoming_leave: upcomingLeave || null,
      on_leave: !!todayLeave,
      curfew_time: curfew,
      current_time: time,
      is_after_curfew: isPastCurfew(time, curfew, getSetting('late_grace_minutes', '30'))
    });
  } catch (err) {
    log.error(`Student summary error: ${err.message}`);
    res.status(500).json({ error: 'Could not load your summary.' });
  }
});

// Gate pass dashboard summary
app.get('/api/gate/summary', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  try {
    const { date } = istNow();
    const inside = db.prepare("SELECT COUNT(*) c FROM students WHERE is_active = 1 AND current_status = 'IN_CAMPUS'").get();
    const outside = db.prepare("SELECT COUNT(*) c FROM students WHERE is_active = 1 AND current_status = 'OUTSIDE_CAMPUS'").get();
    const todayOut = db.prepare("SELECT COUNT(*) c FROM campus_events WHERE event_type = 'CHECK_OUT' AND event_date = ?").get(date);
    const todayIn = db.prepare("SELECT COUNT(*) c FROM campus_events WHERE event_type = 'CHECK_IN' AND event_date = ?").get(date);
    const visitorsInside = db.prepare("SELECT COUNT(*) c FROM visitors WHERE out_time IS NULL").get();
    const approvedLeaves = db.prepare("SELECT COUNT(*) c FROM leaves WHERE status = 'APPROVED'").get();
    const curfew = getSetting('curfew_time', '22:30');
    const { time } = istNow();
    res.json({
      in_campus: inside ? inside.c : 0,
      outside: outside ? outside.c : 0,
      today_out: todayOut ? todayOut.c : 0,
      today_in: todayIn ? todayIn.c : 0,
      visitors_inside: visitorsInside ? visitorsInside.c : 0,
      approved_leaves: approvedLeaves ? approvedLeaves.c : 0,
      curfew_time: curfew,
      current_time: time,
      is_after_curfew: isPastCurfew(time, curfew, getSetting('late_grace_minutes', '30'))
    });
  } catch (err) {
    log.error(`Gate summary error: ${err.message}`);
    res.status(500).json({ error: 'Could not load summary.' });
  }
});

// Approved outpasses for today, so the gate knows who is expected
app.get('/api/gate/expected', authMiddleware, requireRole('GET_PASS'), (req, res) => {
  try {
    const { date } = istNow();
    const rows = db.prepare(`
      SELECT l.id, l.leave_type, l.from_date, l.to_date, l.destination, l.warden_remark,
             s.name, s.enrollment_no, s.hostel_name, s.room_no, s.current_status, s.photo_url
      FROM leaves l JOIN students s ON s.id = l.student_id
      WHERE l.status = 'APPROVED' AND l.from_date <= ? AND l.to_date >= ?
      ORDER BY l.from_date
    `).all(date, date);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not load expected list.' });
  }
});

// ─── Attendance Routes ──────────────────────────────────────────

// Get attendance time window settings
app.get('/api/attendance/settings', (req, res) => {
  const startSetting = db.prepare("SELECT value FROM settings WHERE key = 'attendance_start_time'").get();
  const endSetting = db.prepare("SELECT value FROM settings WHERE key = 'attendance_end_time'").get();
  res.json({ 
    start_time: startSetting ? startSetting.value : '21:00',
    end_time: endSetting ? endSetting.value : '22:00'
  });
});

// Update attendance time window (warden only)
app.put('/api/attendance/settings', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { start_time, end_time } = req.body;
    if (!start_time || !end_time) {
      return res.status(400).json({ error: 'Both start and end times are required' });
    }
    if (!/^\d{2}:\d{2}$/.test(start_time) || !/^\d{2}:\d{2}$/.test(end_time)) {
      return res.status(400).json({ error: 'Invalid time format. Use HH:MM' });
    }
    const [startH, startM] = start_time.split(':').map(Number);
    const [endH, endM] = end_time.split(':').map(Number);
    if (startH < 0 || startH > 23 || startM < 0 || startM > 59 || endH < 0 || endH > 23 || endM < 0 || endM > 59) {
      return res.status(400).json({ error: 'Invalid time values' });
    }
    db.prepare("UPDATE settings SET value = ?, updated_at = datetime('now','localtime') WHERE key = 'attendance_start_time'").run(start_time);
    db.prepare("UPDATE settings SET value = ?, updated_at = datetime('now','localtime') WHERE key = 'attendance_end_time'").run(end_time);
    auditLog(req.user.id, req.user.username, 'WARDEN', 'UPDATE_ATTENDANCE_TIME', null, '', `Changed attendance window to ${start_time} - ${end_time}`, 'SUCCESS', req.ip);
    io.emit('attendance-settings-update', { start_time, end_time });
    res.json({ success: true, message: 'Attendance time window updated successfully' });
  } catch (err) {
    log.error(`Update attendance time error: ${err.message}`);
    res.status(500).json({ error: 'Failed to update attendance time' });
  }
});

// Student mark attendance (self)
app.post('/api/attendance/mark', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    const studentId = req.user.student_id;
    const now = new Date();
    // Use IST, not the server's UTC clock, so times match what users see
    const { date: dateStr, time: timeStr } = istNow();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    // Get attendance time window
    const startSetting = db.prepare("SELECT value FROM settings WHERE key = 'attendance_start_time'").get();
    const endSetting = db.prepare("SELECT value FROM settings WHERE key = 'attendance_end_time'").get();
    const startTime = startSetting ? startSetting.value : '21:00';
    const endTime = endSetting ? endSetting.value : '22:00';
    const [startH, startM] = startTime.split(':').map(Number);
    const [endH, endM] = endTime.split(':').map(Number);
    const startMinutes = startH * 60 + startM;
    const endMinutes = endH * 60 + endM;

    // Check if current time is within the attendance window
    if (currentMinutes < startMinutes) {
      const remainingMinutes = startMinutes - currentMinutes;
      const remainingHours = Math.floor(remainingMinutes / 60);
      const remainingMins = remainingMinutes % 60;
      return res.status(400).json({ 
        error: `Attendance window opens at ${startTime}. Time remaining: ${remainingHours}h ${remainingMins}m`,
        start_time: startTime,
        end_time: endTime,
        current_time: timeStr
      });
    }
    if (currentMinutes > endMinutes) {
      return res.status(400).json({ 
        error: `Attendance window closed at ${endTime}`,
        start_time: startTime,
        end_time: endTime,
        current_time: timeStr
      });
    }

    // Check if already marked today
    const existing = db.prepare("SELECT * FROM attendance WHERE student_id = ? AND date = ?").get(studentId, dateStr);
    if (existing) {
      return res.status(400).json({ error: 'Attendance already marked for today', existing });
    }

    // Mark attendance as present (self)
    db.prepare("INSERT INTO attendance (student_id, date, time, status, marked_by) VALUES (?, ?, ?, 'present', 'self')")
      .run(studentId, dateStr, timeStr);
    
    auditLog(req.user.id, req.user.username, 'STUDENT', 'MARK_ATTENDANCE', studentId, '', `Self-attendance marked at ${timeStr}`, 'SUCCESS', req.ip);
    
    const student = db.prepare("SELECT name, enrollment_no FROM students WHERE id = ?").get(studentId);
    io.emit('attendance-update', { student_id: studentId, date: dateStr, time: timeStr, status: 'present', marked_by: 'self', student_name: student.name });
    
    res.json({ 
      success: true, 
      message: 'Attendance marked successfully',
      attendance: { date: dateStr, time: timeStr, status: 'present', marked_by: 'self' }
    });
  } catch (err) {
    log.error(`Mark attendance error: ${err.message}`);
    res.status(500).json({ error: 'Failed to mark attendance' });
  }
});

// Get student's attendance history
app.get('/api/attendance/student', authMiddleware, requireRole('STUDENT'), (req, res) => {
  try {
    const studentId = req.user.student_id;
    const today = istNow().date;
    
    // Get today's attendance
    const todayAttendance = db.prepare("SELECT * FROM attendance WHERE student_id = ? AND date = ?").get(studentId, today);
    
    // Get last 30 days attendance
    const history = db.prepare(`
      SELECT date, time, status, marked_by 
      FROM attendance 
      WHERE student_id = ? 
      ORDER BY date DESC 
      LIMIT 30
    `).all(studentId);
    
    // Get attendance time window
    const startSetting = db.prepare("SELECT value FROM settings WHERE key = 'attendance_start_time'").get();
    const endSetting = db.prepare("SELECT value FROM settings WHERE key = 'attendance_end_time'").get();
    
    res.json({ 
      today: todayAttendance || null,
      history,
      start_time: startSetting ? startSetting.value : '21:00',
      end_time: endSetting ? endSetting.value : '22:00'
    });
  } catch (err) {
    log.error(`Get attendance error: ${err.message}`);
    res.status(500).json({ error: 'Failed to get attendance' });
  }
});

// Warden: Get all attendance for a date
app.get('/api/attendance/warden', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const date = req.query.date || istNow().date;
    
    const attendance = db.prepare(`
      SELECT a.*, s.name, s.enrollment_no, s.hostel_name, s.room_no
      FROM attendance a
      JOIN students s ON s.id = a.student_id
      WHERE a.date = ?
      ORDER BY s.name
    `).all(date);
    
    const allStudents = db.prepare("SELECT id, name, enrollment_no, hostel_name, room_no FROM students WHERE is_active = 1 ORDER BY name").all();
    
    // Get attendance time window
    const startSetting = db.prepare("SELECT value FROM settings WHERE key = 'attendance_start_time'").get();
    const endSetting = db.prepare("SELECT value FROM settings WHERE key = 'attendance_end_time'").get();
    
    res.json({ 
      date,
      attendance,
      all_students: allStudents,
      start_time: startSetting ? startSetting.value : '21:00',
      end_time: endSetting ? endSetting.value : '22:00'
    });
  } catch (err) {
    log.error(`Get warden attendance error: ${err.message}`);
    res.status(500).json({ error: 'Failed to get attendance data' });
  }
});

// Warden: Mark attendance for a student
app.post('/api/attendance/warden/mark', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { student_id, date, status } = req.body;
    if (!student_id || !date) {
      return res.status(400).json({ error: 'Student ID and date are required' });
    }
    
    const now = new Date();
    const timeStr = istNow().time;
    const attendanceDate = date || istNow().date;
    const attendanceStatus = status || 'present';
    
    // Validate status
    if (!['present', 'absent'].includes(attendanceStatus)) {
      return res.status(400).json({ error: 'Status must be present or absent' });
    }
    
    const student = db.prepare("SELECT * FROM students WHERE id = ?").get(student_id);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }
    
    // Check if already marked
    const existing = db.prepare("SELECT * FROM attendance WHERE student_id = ? AND date = ?").get(student_id, attendanceDate);
    if (existing) {
      // Update existing
      db.prepare("UPDATE attendance SET time = ?, status = ?, marked_by = ? WHERE id = ?")
        .run(timeStr, attendanceStatus, 'warden', existing.id);
    } else {
      // Insert new
      db.prepare("INSERT INTO attendance (student_id, date, time, status, marked_by) VALUES (?, ?, ?, ?, 'warden')")
        .run(student_id, attendanceDate, timeStr, attendanceStatus);
    }
    
    auditLog(req.user.id, req.user.username, 'WARDEN', 'MARK_ATTENDANCE', student_id, student.enrollment_no, 
      `Manually marked ${attendanceStatus} for ${attendanceDate} at ${timeStr}`, 'SUCCESS', req.ip);
    
    io.emit('attendance-update', { student_id, date: attendanceDate, time: timeStr, status: attendanceStatus, marked_by: 'warden', student_name: student.name });
    
    res.json({ 
      success: true, 
      message: `Attendance marked as ${attendanceStatus}`,
      attendance: { date: attendanceDate, time: timeStr, status: attendanceStatus }
    });
  } catch (err) {
    log.error(`Warden mark attendance error: ${err.message}`);
    res.status(500).json({ error: 'Failed to mark attendance' });
  }
});

// Warden: Mark attendance for all students
app.post('/api/attendance/warden/mark-all', authMiddleware, requireRole('WARDEN'), (req, res) => {
  try {
    const { date, status } = req.body;
    const now = new Date();
    const timeStr = istNow().time;
    const attendanceDate = date || istNow().date;
    const attendanceStatus = status || 'present';
    
    // Validate status
    if (!['present', 'absent'].includes(attendanceStatus)) {
      return res.status(400).json({ error: 'Status must be present or absent' });
    }
    
    const allStudents = db.prepare("SELECT id, name, enrollment_no FROM students WHERE is_active = 1").all();
    
    const markTransaction = db.transaction(() => {
      allStudents.forEach(student => {
        const existing = db.prepare("SELECT * FROM attendance WHERE student_id = ? AND date = ?").get(student.id, attendanceDate);
        if (existing) {
          db.prepare("UPDATE attendance SET time = ?, status = ?, marked_by = ? WHERE id = ?")
            .run(timeStr, attendanceStatus, 'warden', existing.id);
        } else {
          db.prepare("INSERT INTO attendance (student_id, date, time, status, marked_by) VALUES (?, ?, ?, ?, 'warden')")
            .run(student.id, attendanceDate, timeStr, attendanceStatus);
        }
      });
    });
    markTransaction();
    
    auditLog(req.user.id, req.user.username, 'WARDEN', 'MARK_ALL_ATTENDANCE', null, '', 
      `Marked ${attendanceStatus} for all ${allStudents.length} students on ${attendanceDate}`, 'SUCCESS', req.ip);
    
    io.emit('attendance-update-all', { date: attendanceDate, time: timeStr, status: attendanceStatus, count: allStudents.length });
    
    res.json({ 
      success: true, 
      message: `Attendance marked as ${attendanceStatus} for all ${allStudents.length} students`,
      count: allStudents.length
    });
  } catch (err) {
    log.error(`Warden mark all attendance error: ${err.message}`);
    res.status(500).json({ error: 'Failed to mark attendance for all students' });
  }
});

// ── Password Change ─────────────────────────────────────────────
app.put('/api/auth/change-password', authMiddleware, (req, res) => {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password) return res.status(400).json({ error: 'Current password and new password are required.' });
  if (new_password.length < 6) return res.status(400).json({ error: 'New password must be at least 6 characters.' });
  
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  
  if (!bcrypt.compareSync(current_password, user.password_hash)) return res.status(401).json({ error: 'Current password is incorrect.' });
  
  const newHash = bcrypt.hashSync(new_password, 10);
  db.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now','localtime') WHERE id = ?").run(newHash, req.user.id);
  
  auditLog(req.user.id, user.username, user.role, 'CHANGE_PASSWORD', req.user.id, user.username, 'Password changed', 'SUCCESS', req.ip);
  res.json({ success: true, message: 'Password changed successfully!' });
});

// ─── Socket.IO ───────────────────────────────────────────────────
io.on('connection', (socket) => {
  log.info(`Client connected: ${socket.id}`);
  socket.on('disconnect', () => log.info(`Client disconnected: ${socket.id}`));
});

// ─── SPA Fallback ────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ─── Error Handler ───────────────────────────────────────────────
app.use((err, req, res, next) => {
  log.error(`Unhandled error: ${err.message}`);
  res.status(500).json({ error: 'Internal server error' });
});

// ─── Start Server ────────────────────────────────────────────────
async function start() {
  try {
    await initDatabase();
    server.listen(PORT, HOST, () => {
      log.info(`🏠 Hostel Management System running at http://${HOST}:${PORT}`);
      log.info(` Local access: http://localhost:${PORT}`);
      log.info(`🌐 Network access: Check your IP and use http://YOUR_IP:${PORT}`);
      log.info('');
      log.info('Default credentials:');
      log.info('  Warden:    warden / warden123');
      log.info('  Gate Pass: gatepass / gatepass123');
      log.info('  Student:   22cs101 / student123');
    });
  } catch (err) {
    log.error(`Failed to start server: ${err.message}`);
    process.exit(1);
  }
}

// Graceful shutdown — flush the database to durable storage before dying.
// (Render sends SIGTERM on restart, redeploy and idle spin-down.)
let shuttingDown = false;
async function gracefulShutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  log.info(`${signal} received, saving data before shutdown…`);

  try {
    if (typeof db !== 'undefined' && db && db._save) {
      // force a final file write
      try { fs.writeFileSync(DB_PATH, Buffer.from(db._db.export())); } catch (e) { log.warn(`Final save failed: ${e.message}`); }
      persistence.writeLocalBackup(DB_PATH);
      if (persistence.githubEnabled()) {
        const ok = await persistence.syncNow(DB_PATH);
        log.info(ok ? 'Final cloud sync complete' : 'Final cloud sync failed (data may be older than last change)');
      }
    }
  } catch (e) {
    log.warn(`Shutdown save error: ${e.message}`);
  }

  server.close(() => {
    log.info('Server closed');
    process.exit(0);
  });
  // Don't hang forever if sockets keep the server open
  setTimeout(() => process.exit(0), 8000).unref?.();
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Export for Vercel serverless
module.exports = app;

// Start server (only if not in Vercel)
if (!process.env.VERCEL) {
  start();
}
