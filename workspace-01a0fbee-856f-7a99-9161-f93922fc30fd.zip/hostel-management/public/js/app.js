/* ═══════════════════════════════════════════════════════════════
   HMS PREMIUM — Single Page Application
   ═══════════════════════════════════════════════════════════════ */

// ─── Safe storage ────────────────────────────────────────────
// Sandboxed preview iframes block localStorage (throws SecurityError), which
// would crash the whole app on load. Fall back to in-memory storage there.
const Store = (() => {
  const mem = {};
  let available = false;
  try {
    const probe = '__hms_probe__';
    window.localStorage.setItem(probe, '1');
    window.localStorage.removeItem(probe);
    available = true;
  } catch (e) {
    available = false;
    console.warn('localStorage unavailable — using in-memory storage for this session.');
  }
  return {
    get(key) {
      try { return available ? window.localStorage.getItem(key) : (mem[key] ?? null); }
      catch (e) { return mem[key] ?? null; }
    },
    set(key, value) {
      try { if (available) window.localStorage.setItem(key, value); else mem[key] = value; }
      catch (e) { mem[key] = value; }
    },
    remove(key) {
      try { if (available) window.localStorage.removeItem(key); else delete mem[key]; }
      catch (e) { delete mem[key]; }
    },
    persistent: available
  };
})();

function safeParse(json, fallback = null) {
  try { return JSON.parse(json); } catch (e) { return fallback; }
}

// ─── State ───────────────────────────────────────────────────
const S = {
  token: Store.get('hms_token'),
  user: safeParse(Store.get('hms_user'), null),
  socket: null,
  qrTimer: null,
  qrCountdown: null,
  html5QrCode: null,
  scanning: false,
  lastScan: 0,
  justScanned: false,
  activeTab: 'student',
  durationTimer: null,
};

// ─── API Helper ──────────────────────────────────────────────
async function api(url, opts = {}) {
  const h = { ...(opts.headers || {}) };
  if (S.token) h['Authorization'] = `Bearer ${S.token}`;
  if (!(opts.body instanceof FormData)) h['Content-Type'] = 'application/json';
  const r = await fetch(url, { ...opts, headers: h });
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}

// ─── Toast ───────────────────────────────────────────────────
function toast(msg, type = 'info') {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  const icons = { success: 'check-circle', error: 'times-circle', warning: 'exclamation-triangle', info: 'info-circle' };
  t.innerHTML = `<i class="fas fa-${icons[type]}"></i> ${msg}`;
  c.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity 0.3s'; setTimeout(() => t.remove(), 300); }, 3500);
}

// ─── View Switching ──────────────────────────────────────────
function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// ─── Login Screen ────────────────────────────────────────────
function showLogin(role) {
  const forms = document.getElementById('login-forms');
  forms.style.display = 'block';
  document.getElementById('form-register').style.display = 'none';
  document.getElementById('form-login').style.display = 'block';

  const title = document.getElementById('login-title');
  const label = document.getElementById('login-label-user');
  const btn = document.getElementById('login-btn');
  const roleInput = document.getElementById('login-role');
  const regLink = document.getElementById('register-link');
  const userInput = document.getElementById('login-user');

  if (role === 'student') {
    title.innerHTML = '<i class="fas fa-graduation-cap"></i> Student Login';
    label.textContent = 'Enrollment Number';
    userInput.placeholder = 'e.g. 22CS101';
    btn.className = 'btn-login btn-green';
    roleInput.value = 'STUDENT';
    regLink.style.display = 'block';
  } else if (role === 'gatepass') {
    title.innerHTML = '<i class="fas fa-id-badge"></i> Gate Pass Login';
    label.textContent = 'Username';
    userInput.placeholder = 'Gate pass ID';
    btn.className = 'btn-login btn-orange';
    roleInput.value = 'GET_PASS';
    regLink.style.display = 'none';
  } else {
    title.innerHTML = '<i class="fas fa-user-shield"></i> Warden Login';
    label.textContent = 'Username';
    userInput.placeholder = 'Warden ID';
    btn.className = 'btn-login btn-purple';
    roleInput.value = 'WARDEN';
    regLink.style.display = 'none';
  }
  userInput.value = '';
  document.getElementById('login-pass').value = '';
}
function hideLoginForms() { document.getElementById('login-forms').style.display = 'none'; }
function showRegisterForm() {
  document.getElementById('form-login').style.display = 'none';
  document.getElementById('form-register').style.display = 'block';
}

function stab(btn, id) {
  btn.parentElement.querySelectorAll('.ftab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
}

// ─── Authentication ──────────────────────────────────────────
async function doLogin(e) {
  e.preventDefault();
  const username = document.getElementById('login-user').value;
  const password = document.getElementById('login-pass').value;
  const role = document.getElementById('login-role').value;
  try {
    const data = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password, role })
    });
    S.token = data.token;
    S.user = data.user;
    Store.set('hms_token', data.token);
    Store.set('hms_user', JSON.stringify(data.user));
    connectSocket();
    toast('Login successful!', 'success');
    enterDashboard();
  } catch (err) { toast(err.message, 'error'); }
}

async function doRegister(e) {
  e.preventDefault();
  const pass = document.getElementById('r-pass').value;
  const cpass = document.getElementById('r-cpass').value;
  if (pass !== cpass) return toast('Passwords do not match', 'error');
  if (pass.length < 6) return toast('Password must be 6+ characters', 'error');

  const fd = new FormData();
  fd.append('name', document.getElementById('r-name').value);
  fd.append('enrollment_no', document.getElementById('r-enroll').value);
  fd.append('phone', document.getElementById('r-phone').value);
  fd.append('branch', document.getElementById('r-branch').value);
  fd.append('section', document.getElementById('r-section').value);
  fd.append('blood_group', document.getElementById('r-blood').value);
  fd.append('parent_name', document.getElementById('r-pname').value);
  fd.append('parent_phone', document.getElementById('r-pphone').value);
  fd.append('hostel_name', document.getElementById('r-hostel').value);
  fd.append('room_no', document.getElementById('r-room').value);
  fd.append('floor', document.getElementById('r-floor').value);
  fd.append('password', pass);
  fd.append('confirm_password', cpass);

  try {
    const data = await api('/api/auth/register', { method: 'POST', body: fd });
    toast(data.message, 'success');
    // Switch to login form
    document.getElementById('form-register').style.display = 'none';
    document.getElementById('form-login').style.display = 'block';
  } catch (err) { toast(err.message, 'error'); }
}

function doLogout() {
  S.token = null; S.user = null;
  Store.remove('hms_token');
  Store.remove('hms_user');
  if (S.socket) { S.socket.disconnect(); S.socket = null; }
  clearTimers();
  showView('view-login');
  hideLoginForms();
  toast('Logged out', 'info');
}

// ─── Change Password ───────────────────────────────────────────
function showChangePassword() {
  document.getElementById('modal-box').innerHTML = `
    <h2><i class="fas fa-key" style="color:var(--orange);"></i> Change Password</h2>
    <form onsubmit="changePassword(event)">
      <div class="fg"><label>Current Password</label><input type="password" id="cp-current" required placeholder="Enter current password"></div>
      <div class="fg"><label>New Password</label><input type="password" id="cp-new" required minlength="6" placeholder="Min 6 characters"></div>
      <div class="fg"><label>Confirm New Password</label><input type="password" id="cp-confirm" required minlength="6" placeholder="Re-enter new password"></div>
      <div class="modal-actions">
        <button type="button" class="btn-action" style="background:var(--glass);border:1px solid var(--glass-border);" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn-action btn-orange"><i class="fas fa-check"></i> Change Password</button>
      </div>
    </form>`;
  openModal();
}

async function changePassword(e) {
  e.preventDefault();
  const currentPw = document.getElementById('cp-current').value;
  const newPw = document.getElementById('cp-new').value;
  const confirmPw = document.getElementById('cp-confirm').value;
  
  if (newPw !== confirmPw) return toast('New passwords do not match', 'error');
  if (newPw.length < 6) return toast('Password must be at least 6 characters', 'error');
  if (newPw === currentPw) return toast('New password must be different from current', 'error');
  
  try {
    await api('/api/auth/change-password', {
      method: 'PUT',
      body: JSON.stringify({ current_password: currentPw, new_password: newPw })
    });
    closeModal();
    toast('Password changed successfully! ✓', 'success');
  } catch (err) {
    toast(err.message || 'Failed to change password', 'error');
  }
}

// ─── Enter Dashboard ─────────────────────────────────────────
function enterDashboard() {
  showView('view-dashboard');
  const role = S.user.role;
  // Show relevant tabs
  document.getElementById('tab-student').style.display = role === 'STUDENT' ? 'flex' : 'none';
  document.getElementById('tab-gate').style.display = role === 'GET_PASS' ? 'flex' : 'none';
  document.getElementById('tab-warden').style.display = role === 'WARDEN' ? 'flex' : 'none';

  // Show role in center blue box
  const roleInfo = {
    'STUDENT': { icon: 'fa-graduation-cap', label: 'Student' },
    'WARDEN': { icon: 'fa-user-shield', label: 'Warden' },
    'GET_PASS': { icon: 'fa-id-badge', label: 'Gate Pass' }
  };
  const ri = roleInfo[role] || { icon: 'fa-user', label: role };
  document.getElementById('nav-role-box').innerHTML = `<i class="fas ${ri.icon}"></i> ${ri.label}`;

  // User info hidden
  document.getElementById('nav-user-info').innerHTML = '';

  // Show change password button for Warden and Gate Pass
  const btnChangePw = document.getElementById('btn-change-pw');
  if (btnChangePw) btnChangePw.style.display = (role === 'WARDEN' || role === 'GET_PASS') ? 'flex' : 'none';

  // Set active tab
  if (role === 'STUDENT') switchTab('student');
  else if (role === 'GET_PASS') switchTab('gate');
  else switchTab('warden');
}

// ─── Tab Switching ───────────────────────────────────────────
function switchTab(tab) {
  S.activeTab = tab;
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  document.getElementById(`tab-${tab}`).classList.add('active');
  document.querySelectorAll('.panel').forEach(p => p.style.display = 'none');
  document.getElementById(`panel-${tab}`).style.display = 'block';

  clearTimers();
  S.activeSub = S.activeSub || {};
  const defaultSub = { student: 'overview', gate: 'check', warden: 'live' }[tab];
  switchSub(tab, S.activeSub[tab] || defaultSub, true);

  if (tab === 'student') loadStudentAll();
  if (tab === 'gate') loadGateAll();
  if (tab === 'warden') loadWardenAll();
}

/* ═══════════════════════════════════════════════════════════════
   SUB-NAVIGATION
   ═══════════════════════════════════════════════════════════════ */
function switchSub(role, sub, silent) {
  S.activeSub = S.activeSub || {};
  S.activeSub[role] = sub;

  const nav = document.getElementById('subnav-' + role);
  if (nav) {
    nav.querySelectorAll('.subnav-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.sub === sub);
    });
  }
  const panel = document.getElementById('panel-' + role);
  if (panel) {
    panel.querySelectorAll(':scope > .subpane').forEach(p => p.classList.remove('active'));
    const pane = document.getElementById('spane-' + role + '-' + sub);
    if (pane) pane.classList.add('active');
  }

  if (silent) return;
  // Load the data that this section needs
  if (role === 'student') {
    if (sub === 'leave') { loadMyLeaves(); loadStudentSummary(); }
    if (sub === 'complaints') loadMyComplaints();
    if (sub === 'notices') { loadNotices(); loadStudentSummary(); }
  }
  if (role === 'gate') {
    if (sub === 'visitors') { loadVisitors(); fillVisitorStudentSelect(); }
    if (sub === 'expected') { loadExpected(); loadOutsideNow(); }
  }
  if (role === 'warden') {
    if (sub === 'requests') loadWardenLeaves();
    if (sub === 'complaints') loadWardenComplaints();
    if (sub === 'analytics') { loadAnalytics(); loadRooms(); }
    if (sub === 'rollcall') { loadCurfew(); loadRollCall(); }
    if (sub === 'notices') loadWardenNotices();
    if (sub === 'settings') loadSettings();
  }
}

/* ─── Theme ─────────────────────────────────────────────────── */
function applyTheme(theme) {
  document.body.classList.toggle('light', theme === 'light');
  const btn = document.getElementById('btn-theme');
  if (btn) btn.innerHTML = theme === 'light' ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
  Store.set('hms_theme', theme);
}
function toggleTheme() {
  const next = document.body.classList.contains('light') ? 'dark' : 'light';
  applyTheme(next);
  toast(next === 'light' ? '☀️ Light theme' : '🌙 Dark theme', 'info');
}
applyTheme(Store.get('hms_theme') || 'dark');

/* ═══════════════════════════════════════════════════════════════
   SHARED RENDER HELPERS
   ═══════════════════════════════════════════════════════════════ */
function esc(str) {
  return String(str === null || str === undefined ? '' : str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function initials(name) {
  return String(name || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}
function emptyState(icon, msg) {
  return `<div class="empty-state"><i class="fas ${icon}"></i><p>${esc(msg)}</p></div>`;
}
function initialsAvatar(name, photo) {
  const style = photo ? `background-image:url('${esc(photo)}')` : '';
  return `<div class="item-avatar" style="${style}">${photo ? '' : esc(initials(name))}</div>`;
}
function statusChip(status) {
  const map = {
    PENDING: 'pending', APPROVED: 'approved', REJECTED: 'rejected', CANCELLED: 'completed', COMPLETED: 'completed',
    OPEN: 'open', IN_PROGRESS: 'progress', RESOLVED: 'resolved', CLOSED: 'completed'
  };
  const cls = map[status] || 'completed';
  const label = String(status || '').replace(/_/g, ' ');
  return `<span class="chip ${cls}">${esc(label)}</span>`;
}
function priorityChip(p) {
  const cls = { URGENT: 'urgent', HIGH: 'high', NORMAL: 'normal', LOW: 'low' }[p] || 'normal';
  return `<span class="chip ${cls}">${esc(p || 'NORMAL')}</span>`;
}
function fmtDate(d) {
  if (!d) return '—';
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return esc(d);
  return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}
function fmtDateTime(s) {
  if (!s) return '—';
  const str = String(s);
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(str)) return str.slice(0, 16);
  return str;
}
function badge(id, count) {
  const el = document.getElementById(id);
  if (!el) return;
  if (count && count > 0) { el.textContent = count; el.classList.add('show'); }
  else { el.textContent = ''; el.classList.remove('show'); }
}

function clearTimers() {
  if (S.qrTimer) { clearInterval(S.qrTimer); S.qrTimer = null; }
  if (S.qrCountdown) { clearInterval(S.qrCountdown); S.qrCountdown = null; }
  if (S.durationTimer) { clearInterval(S.durationTimer); S.durationTimer = null; }
  if (S.scanning) stopScan();
}

// ═══════════════════════════════════════════════════════════════
//  SOCKET.IO — Real-Time Sync
// ═══════════════════════════════════════════════════════════════
function connectSocket() {
  if (S.socket) S.socket.disconnect();
  if (typeof io === 'undefined') {
    console.warn('socket.io unavailable — live updates disabled, dashboards still work.');
    return;
  }
  S.socket = io();
  S.socket.on('connect', () => console.log('Socket connected'));
  S.socket.on('status-update', handleRealtimeUpdate);
  S.socket.on('attendance-update', handleAttendanceUpdate);
  S.socket.on('attendance-update-all', handleAttendanceUpdateAll);
  S.socket.on('attendance-settings-update', handleAttendanceSettingsUpdate);

  // Live updates for the newer modules
  S.socket.on('sos-alert', (d) => {
    toast(`🚨 EMERGENCY: ${d.student.name} (${d.student.room_no || ''}) — ${d.location || d.message || 'needs help'}`, 'error');
    if (S.user && S.user.role === 'WARDEN') loadSOSAlerts();
    if (S.activeTab === 'warden' && S.activeSub && S.activeSub.warden === 'live') loadWardenAll();
  });
  S.socket.on('sos-update', () => {
    if (S.user && S.user.role === 'WARDEN') loadSOSAlerts();
    if (S.activeTab === 'student') loadStudentSummary();
  });
  S.socket.on('leave-update', (d) => {
    if (S.user && S.user.role === 'STUDENT') {
      const msg = d.action === 'approved' ? '✅ Your leave was approved!'
                : d.action === 'rejected' ? '❌ Your leave request was rejected.'
                : d.action === 'created' ? '📩 New leave request received.'
                : 'Leave request updated.';
      if (d.action !== 'created' || S.activeTab !== 'warden') toast(msg, d.action === 'approved' ? 'success' : d.action === 'rejected' ? 'warning' : 'info');
      if (S.activeSub && S.activeSub.student === 'leave') loadMyLeaves();
      loadStudentSummary();
    }
    if (S.user && S.user.role === 'WARDEN') {
      if (S.activeSub && S.activeSub.warden === 'requests') loadWardenLeaves();
    }
    if (S.user && S.user.role === 'GET_PASS') loadGateSummary();
  });
  S.socket.on('complaint-update', () => {
    if (S.user && S.user.role === 'WARDEN' && S.activeSub && S.activeSub.warden === 'complaints') loadWardenComplaints();
    if (S.user && S.user.role === 'STUDENT') { loadMyComplaints(); loadStudentSummary(); }
  });
  S.socket.on('notice-update', () => {
    if (S.activeTab === 'student') loadNotices();
    if (S.user && S.user.role === 'WARDEN' && S.activeSub && S.activeSub.warden === 'notices') loadWardenNotices();
  });
  S.socket.on('visitor-update', () => {
    if (S.user && S.user.role === 'GET_PASS') { loadVisitors(); loadGateSummary(); }
  });
  S.socket.on('rollcall-update', () => {
    if (S.user && S.user.role === 'WARDEN' && S.activeSub && S.activeSub.warden === 'rollcall') loadRollCall();
  });
  S.socket.on('settings-update', () => {
    if (S.user && S.user.role === 'WARDEN' && S.activeSub && S.activeSub.warden === 'settings') loadSettings();
  });
  S.socket.on('data_restored', (data) => {
    toast('🔄 Database restored by warden — ' + (data && data.count ? data.count + ' students' : 'refreshing'), 'info');
    if (S.activeTab === 'student') loadStudentAll();
    if (S.activeTab === 'gate') { loadGateStudents(); loadGateRecent(); }
    if (S.activeTab === 'warden') loadWardenAll();
  });
}

function handleRealtimeUpdate(data) {
  const { student, event_type, event_time, outside_duration } = data;
  const name = student.name || 'Student';
  const isCheckIn = event_type === 'CHECK_IN';
  const emoji = isCheckIn ? '🟢' : '🔴';
  const action = isCheckIn ? 'Checked In' : 'Checked Out';
  const durMsg = isCheckIn && outside_duration ? ` | ⏱ ${outside_duration}` : '';

  // Skip toast and refresh if we just scanned (the scan handler already handles it)
  if (S.justScanned) {
    S.justScanned = false;
    return;
  }

  toast(`${emoji} ${name} — ${action}${durMsg}`, isCheckIn ? 'success' : 'warning');

  // Refresh panels (with small delay to let DB save)
  setTimeout(() => {
    if (S.activeTab === 'student') loadStudentAll();
    if (S.activeTab === 'gate') { loadGateStudents(); loadGateRecent(); }
    if (S.activeTab === 'warden') loadWardenAll();
  }, 300);
}

// ═══════════════════════════════════════════════════════════════
//  STUDENT PANEL
// ═══════════════════════════════════════════════════════════════
async function loadStudentAll() {
  try {
    const me = await api('/api/auth/me');
    loadStudentSummary();
    renderStudentStatus(me);
    renderStudentProfile(me);
    loadStudentHistory();
    loadStudentAttendance();
    startQRLoop();
  } catch (err) { console.error(err); }
}

function renderStudentStatus(me) {
  const el = document.getElementById('s-status-card');
  const isIn = me.current_status === 'IN_CAMPUS';

  // ── ON LEAVE takes priority: this is the state that matters most ──
  if (me.on_leave && me.active_leave) {
    const lv = me.active_leave;
    el.className = 'status-card on-leave';
    el.innerHTML = `
      <div class="sc-emoji">🟣</div>
      <div class="sc-label">ON LEAVE</div>
      <div class="sc-detail">
        <strong>${esc(lv.leave_type)} leave</strong><br>
        ${fmtDate(lv.from_date)} → ${fmtDate(lv.to_date)}
      </div>
      ${lv.destination ? `<div class="sc-detail" style="margin-top:10px;"><i class="fas fa-location-dot"></i> ${esc(lv.destination)}</div>` : ''}
      <div class="sc-leave-note">
        <i class="fas fa-circle-info"></i>
        You are ${me.current_status === 'IN_CAMPUS' ? 'still inside campus — the gate will mark you out when you leave' : 'outside on approved leave'}.
      </div>
      ${lv.warden_remark ? `<div class="sc-leave-remark"><i class="fas fa-comment-dots"></i> ${esc(lv.warden_remark)}</div>` : ''}`;
    if (S.durationTimer) { clearInterval(S.durationTimer); S.durationTimer = null; }
    return;
  }

  el.className = `status-card ${isIn ? 'in-campus' : 'outside-campus'}`;

  // Upcoming leave banner on the normal cards
  const upcoming = me.upcoming_leave
    ? `<div class="sc-upcoming"><i class="fas fa-calendar-check"></i> Approved leave: ${esc(me.upcoming_leave.type)} · ${fmtDate(me.upcoming_leave.from)} → ${fmtDate(me.upcoming_leave.to)}</div>`
    : '';

  if (isIn) {
    el.innerHTML = `
      <div class="sc-emoji">🟢</div>
      <div class="sc-label">IN CAMPUS</div>
      <div class="sc-detail">
        Last Check-In<br>
        <strong>${fmtDT(me.last_checkin)}</strong>
      </div>
      ${me.last_outside_duration ? `
      <div class="sc-duration" style="background:rgba(255,255,255,0.2);margin-top:16px;">
        <div style="font-size:0.8rem;opacity:0.8;">⏱ Last Outside Duration</div>
        <div class="dur-val">${me.last_outside_duration}</div>
      </div>` : ''}
      ${upcoming}`;
    if (S.durationTimer) { clearInterval(S.durationTimer); S.durationTimer = null; }
  } else {
    el.innerHTML = `
      <div class="sc-emoji">🔴</div>
      <div class="sc-label">OUTSIDE CAMPUS</div>
      <div class="sc-detail">
        Checked Out<br>
        <strong>${fmtDT(me.last_checkout)}</strong>
      </div>
      <div class="sc-duration">
        <div style="font-size:0.8rem;opacity:0.8;">Outside Duration</div>
        <div class="dur-val" id="dur-val">...</div>
      </div>
      ${upcoming}`;
    startDurationTimer(me.last_checkout);
  }
}

function startDurationTimer(checkout) {
  if (S.durationTimer) clearInterval(S.durationTimer);
  function update() {
    const el = document.getElementById('dur-val');
    if (!el) { clearInterval(S.durationTimer); return; }
    if (!checkout) { el.textContent = '0m'; return; }
    const coDate = new Date(checkout.replace(' ', 'T') + ':00+05:30');
    const diff = Math.floor((Date.now() - coDate.getTime()) / 60000);
    if (diff < 0) { el.textContent = '0m'; return; }
    const h = Math.floor(diff / 60), m = diff % 60;
    el.textContent = h > 0 ? `${h}h ${m}m` : `${m}m`;
  }
  update();
  S.durationTimer = setInterval(update, 10000);
}

function renderStudentProfile(me) {
  const photo = me.photo_url ? `<img src="${me.photo_url}">` : '<i class="fas fa-user"></i>';
  document.getElementById('s-profile-card').innerHTML = `
    <div class="profile-top">
      <div class="profile-avatar">${photo}</div>
      <div>
        <h2>${me.name}</h2>
        <p>${me.enrollment_no} • ${me.branch} - ${me.section}</p>
        <div class="profile-badges">
          <span class="p-badge"><i class="fas fa-building"></i> ${me.hostel_name}</span>
          <span class="p-badge"><i class="fas fa-door-open"></i> Room ${me.room_no}</span>
          <span class="p-badge"><i class="fas fa-tint"></i> ${me.blood_group || 'N/A'}</span>
        </div>
      </div>
    </div>
    <div class="profile-grid">
      <div class="profile-item"><label>Phone</label><span>${me.phone}</span></div>
      <div class="profile-item"><label>Branch</label><span>${me.branch}</span></div>
      <div class="profile-item"><label>Parent</label><span>${me.parent_name}</span></div>
      <div class="profile-item"><label>Parent Phone</label><span>${me.parent_phone}</span></div>
      <div class="profile-item"><label>Floor</label><span>${me.floor}</span></div>
      <div class="profile-item"><label>Status</label><span class="${me.current_status === 'IN_CAMPUS' ? 'badge in' : 'badge out'}">${me.current_status === 'IN_CAMPUS' ? 'In Campus' : 'Outside'}</span></div>
    </div>`;
}

async function loadStudentHistory() {
  try {
    const data = await api('/api/student/history');
    const el = document.getElementById('s-history-list');
    if (!data.events || !data.events.length) { el.innerHTML = '<div class="empty"><i class="fas fa-clock"></i><p>No activity yet</p></div>'; return; }
    el.innerHTML = data.events.slice(0, 15).map(e => {
      const isIn = e.event_type === 'CHECK_IN';
      return `<div class="h-item">
        <div class="h-icon ${isIn ? 'checkin' : 'checkout'}"><i class="fas fa-${isIn ? 'arrow-left' : 'arrow-right'}"></i></div>
        <div class="h-info">
          <strong>${isIn ? 'Checked In' : 'Checked Out'}</strong>
          <span>${isIn ? 'Returned to campus' : 'Left campus'}${isIn && e.outside_duration ? ` · <span style="color:var(--orange);font-weight:600;">⏱ ${e.outside_duration}</span>` : ''}</span>
        </div>
        <div class="h-time">${e.event_date}<br>${fmtTime(e.event_time)}</div>
      </div>`;
    }).join('');
  } catch {}
}

// ─── QR Code ─────────────────────────────────────────────────
async function startQRLoop() {
  if (S.qrTimer) clearInterval(S.qrTimer);
  if (S.qrCountdown) clearInterval(S.qrCountdown);
  await genQR();
  S.qrTimer = setInterval(genQR, 6000);
}

async function genQR() {
  try {
    const data = await api('/api/qr/generate', { method: 'POST' });
    const el = document.getElementById('qr-display');
    el.innerHTML = '';
    if (typeof QRCode === 'undefined') {
      el.innerHTML = `<div class="qr-fallback"><code>${data.token}</code><br><small>QR library did not load — read this code to the gate pass desk.</small></div>`;
    } else {
      new QRCode(el, { text: data.token, width: 180, height: 180, colorDark: '#1a1a2e', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
    }
    // Animate timer bar
    startQRTimerBar();
  } catch (err) { console.error('QR error:', err); }
}


function startQRTimerBar() {
  if (S.qrCountdown) clearInterval(S.qrCountdown);
  let remaining = 6;
  const fill = document.getElementById('qr-fill');
  const text = document.getElementById('qr-countdown-text');
  if (fill) fill.style.width = '100%';
  if (text) text.textContent = 'Refreshes in 6s';

  S.qrCountdown = setInterval(() => {
    remaining--;
    const pct = (remaining / 6) * 100;
    if (fill) fill.style.width = pct + '%';
    if (text) text.textContent = remaining > 0 ? `Refreshes in ${remaining}s` : 'Refreshing...';
    if (remaining <= 0) clearInterval(S.qrCountdown);
  }, 1000);
}

// ═══════════════════════════════════════════════════════════════
//  GATE PASS PANEL
// ═══════════════════════════════════════════════════════════════
async function loadGateAll() {
  loadGateSummary();
  loadGateStudents();
  loadGateRecent();
}

async function loadGateStudents() {
  try {
    const search = document.getElementById('gp-search')?.value || '';
    const filter = document.getElementById('gp-filter')?.value || '';
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (filter) params.set('status', filter);
    const students = await api(`/api/getpass/students?${params}`);
    const el = document.getElementById('gp-student-list');
    if (!students.length) { el.innerHTML = '<div class="empty"><p>No students found</p></div>'; return; }
    
    const html = students.map(s => {
      const isIn = s.current_status === 'IN_CAMPUS';
      const lastTime = isIn ? (s.last_checkin || '') : (s.last_checkout || '');
      const timeStr = fmtTime(lastTime);
      const dateStr = lastTime && lastTime.includes(' ') ? fmtDate(lastTime.split(' ')[0]) : '';
      const colors = ['#8b5cf6','#3b82f6','#06b6d4','#f59e0b','#ef4444','#ec4899'];
      const color = colors[s.id % colors.length];
      const initial = s.name.charAt(0).toUpperCase();
      const activityLabel = isIn ? 'Last Check-In' : 'Last Check-Out';
      const leaveBadge = s.on_leave
        ? `<span class="badge leave"><i class="fas fa-plane-departure"></i> On Leave${s.leave_until ? ' · till ' + fmtDate(s.leave_until) : ''}</span>`
        : '';
      const leaveLine = s.on_leave
        ? `<div style="font-size:0.78rem;color:#c084fc;font-weight:700;margin-top:3px;"><i class="fas fa-tag"></i> ${esc(s.leave_type)} leave approved${s.leave_destination ? ' · ' + esc(s.leave_destination) : ''}</div>`
        : '';
      return `<div class="s-item ${s.on_leave ? 'is-on-leave' : ''}" style="cursor:pointer;" onclick="viewStudentGate(${s.id})">
        <div class="si-avatar" style="background:${color};">${initial}</div>
        <div class="si-info">
          <div class="si-name">${esc(s.name)} ${s.on_leave ? '<span class="leave-dot" title="On approved leave"></span>' : ''}</div>
          <div class="si-meta">${esc(s.enrollment_no)} · ${esc(s.hostel_name)} · R${esc(s.room_no)}</div>
          <div style="font-size:0.78rem;color:${isIn ? '#22c55e' : '#ef4444'};font-weight:600;margin-top:3px;">${isIn ? '🟢' : '🔴'} ${activityLabel}: ${dateStr} ${timeStr || '—'}</div>
          ${leaveLine}
        </div>
        <div class="si-status">
          <span class="badge ${isIn ? 'in' : 'out'}">${isIn ? 'In Campus' : 'Outside'}</span>
          ${leaveBadge}
        </div>
      </div>`;
    }).join('');
    
    el.innerHTML = html;
  } catch (err) {
    console.error('Load gate students error:', err);
  }
}

async function loadGateRecent() {
  try {
    const events = await api('/api/getpass/recent');
    const el = document.getElementById('gp-recent-list');
    if (!events.length) { el.innerHTML = '<div class="empty"><p>No recent activity</p></div>'; return; }
    
    const html = events.slice(0, 20).map(e => {
      const isIn = e.event_type === 'CHECK_IN';
      const durationHtml = (isIn && e.outside_duration) ? ` · <span style="color:var(--orange);font-weight:600;">⏱ ${e.outside_duration}</span>` : '';
      return `<div class="h-item">
        <div class="h-icon ${isIn ? 'checkin' : 'checkout'}"><i class="fas fa-${isIn ? 'arrow-left' : 'arrow-right'}"></i></div>
        <div class="h-info">
          <strong>${e.name}</strong>
          <span>${e.enrollment_no} · ${e.hostel_name} · R${e.room_no}${durationHtml}</span>
        </div>
        <div class="h-time">${isIn ? '🟢 In' : '🔴 Out'}<br>${fmtDate(e.event_date)} ${fmtTime(e.event_time)}</div>
      </div>`;
    }).join('');
    
    el.innerHTML = html;
  } catch (err) {
    console.error('Load gate recent error:', err);
  }
}

// ─── Scanner ─────────────────────────────────────────────────
async function startScan() {
  try {
    if (typeof Html5Qrcode === 'undefined') {
      toast('Scanner could not load. Please reload the page.', 'error');
      const ph = document.getElementById('scanner-placeholder');
      if (ph) { ph.style.display = ''; ph.innerHTML = '<i class="fas fa-triangle-exclamation" style="color:#f59e0b;"></i><p>The scanner did not load.<br><small>Reload the page and try again.</small></p>'; }
      return;
    }
    document.getElementById('scanner-placeholder').style.display = 'none';
    if (!S.html5QrCode) S.html5QrCode = new Html5Qrcode("qr-reader");
    await S.html5QrCode.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } }, onScan, () => {});
    S.scanning = true;
    document.getElementById('btn-scan-start').style.display = 'none';
    document.getElementById('btn-scan-stop').style.display = 'flex';
  } catch (err) {
    document.getElementById('scanner-placeholder').style.display = 'flex';
    document.getElementById('scanner-placeholder').innerHTML = `<i class="fas fa-exclamation-triangle" style="color:#f59e0b;"></i><p>Camera not available<br><small>Allow camera access in your browser, or open this site on a phone. Note: the scanner cannot work inside an embedded preview window.</small></p>`;
    toast('Camera permission required — the QR scanner needs a real browser with camera access.', 'error');
  }
}

async function stopScan() {
  if (S.html5QrCode && S.scanning) {
    try { await S.html5QrCode.stop(); } catch {}
    S.scanning = false;
    document.getElementById('btn-scan-start').style.display = 'flex';
    document.getElementById('btn-scan-stop').style.display = 'none';
    document.getElementById('scanner-placeholder').style.display = 'flex';
    document.getElementById('scanner-placeholder').innerHTML = `<i class="fas fa-qrcode"></i><p>Tap <strong>Start Scanner</strong> to scan a student's QR</p>`;
  }
}

async function onScan(decoded) {
  const now = Date.now();
  if (now - S.lastScan < 2000) return;
  S.lastScan = now;

  const el = document.getElementById('scan-result');
  el.style.display = 'block';
  el.className = 'scan-result';
  el.innerHTML = '<div style="padding:20px;"><i class="fas fa-spinner fa-spin fa-2x" style="color:var(--blue);"></i><p style="margin-top:8px;">Verifying...</p></div>';

  try {
    const data = await api('/api/qr/verify', { method: 'POST', body: JSON.stringify({ token: decoded }) });
    const s = data.student;
    const isIn = s.event_type === 'CHECK_IN';
    el.className = 'scan-result ok';
    el.innerHTML = `
      <h4 style="color:var(--green);"><i class="fas fa-check-circle"></i> ${isIn ? 'CHECK-IN ✓' : 'CHECK-OUT ✓'}</h4>
      <p style="margin:6px 0;"><strong>${s.name}</strong> (${s.enrollment_no})</p>
      <p style="font-size:0.85rem;color:var(--text2);">${s.hostel_name} · Room ${s.room_no} · ${s.event_time}</p>
      <span class="badge ${isIn ? 'in' : 'out'}" style="margin-top:8px;font-size:0.85rem;">${isIn ? '🟢 IN CAMPUS' : '🔴 OUTSIDE CAMPUS'}</span>
      ${s.outside_duration ? `<div style="margin-top:12px;padding:10px 16px;background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.3);border-radius:8px;display:inline-block;"><p style="color:var(--orange);font-weight:700;font-size:0.9rem;margin:0;">⏱ Outside Duration</p><p style="color:var(--orange);font-weight:800;font-size:1.3rem;margin:4px 0 0 0;">${s.outside_duration}</p></div>` : ''}`;
    toast(`${s.name} ${isIn ? 'checked in' : 'checked out'}!${s.outside_duration ? ' Outside: ' + s.outside_duration : ''}`, 'success');
    // Set flag to prevent socket-triggered double refresh
    S.justScanned = true;
    // Wait briefly for DB to save, then refresh lists
    setTimeout(() => {
      loadGateStudents();
      loadGateRecent();
      // Reset flag after a few seconds
      setTimeout(() => { S.justScanned = false; }, 3000);
    }, 500);
  } catch (err) {
    el.className = 'scan-result fail';
    el.innerHTML = `<h4 style="color:var(--red);"><i class="fas fa-times-circle"></i> FAILED</h4><p style="margin-top:6px;">${err.message}</p>`;
    toast(err.message, 'error');
  }
}

// ═══════════════════════════════════════════════════════════════
//  WARDEN PANEL
// ═══════════════════════════════════════════════════════════════
async function loadWardenAll() {
  try {
    const data = await api('/api/warden/monitoring');
    renderWardenStats(data.stats);
    renderWardenMonitoring(data);
    loadWardenStudents();
    renderWardenRecent(data);
    loadHostelFilters();
    loadWardenAttendance();
    loadBackupStatus();
    loadSOSAlerts();
    if (data.stats) {
      badge('badge-w-complaints', data.stats.open_complaints);
      badge('badge-w-requests', data.stats.pending_leaves);
    }
  } catch (err) { console.error(err); }
}

/* ═══════════════════════════════════════════════════════════════
   DATA SAFETY & BACKUP
   Free hosts wipe the disk on restart — these tools protect the data.
   ═══════════════════════════════════════════════════════════════ */

function backupResult(msg, kind) {
  const el = document.getElementById('w-backup-result');
  if (!el) return;
  el.className = 'backup-result ' + (kind || '');
  el.innerHTML = msg;
}

function timeAgo(iso) {
  if (!iso) return 'Never';
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60) return 'Just now';
  if (diff < 3600) return Math.floor(diff / 60) + ' min ago';
  if (diff < 86400) return Math.floor(diff / 3600) + ' hr ago';
  return Math.floor(diff / 86400) + ' day(s) ago';
}

async function loadBackupStatus() {
  try {
    const st = await api('/api/warden/backup/status');
    const badge = document.getElementById('w-sync-badge');
    if (badge) {
      badge.textContent = st.cloud_sync ? 'Cloud sync ON' : 'Cloud sync OFF';
      badge.className = 'sync-badge ' + (st.cloud_sync ? 'on' : 'off');
    }
    const set = (id, val) => { const e = document.getElementById(id); if (e) e.textContent = val; };
    set('w-backup-students', st.students);
    set('w-backup-size', st.db_size_kb + ' KB');
    set('w-backup-lastsync', timeAgo(st.last_push));
    const btn = document.getElementById('btn-sync-now');
    if (btn) btn.style.display = st.cloud_sync ? '' : 'none';
    if (!st.cloud_sync) {
      backupResult(
        'Cloud sync is off, so data is only safe once you download a backup and keep the file. ' +
        'To turn sync on, add <b>GITHUB_TOKEN</b> and <b>GITHUB_REPO</b> in your host\'s environment settings.',
        'err'
      );
    } else if (st.error) {
      backupResult('Last sync problem: ' + st.error, 'err');
    } else {
      backupResult('Cloud sync is active — the database is saved to <b>' + st.repo + '</b>.', 'ok');
    }
  } catch (err) { console.error('backup status', err); }
}

async function downloadBackup() {
  try {
    backupResult('Preparing backup…', 'working');
    const r = await fetch('/api/warden/backup/download', {
      headers: { 'Authorization': 'Bearer ' + S.token }
    });
    if (!r.ok) throw new Error('Server refused the download');
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hostel-backup-' + new Date().toISOString().slice(0, 10) + '.db';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    backupResult('Backup downloaded (' + Math.round(blob.size / 1024) + ' KB). Keep this file safe — you can restore it any time.', 'ok');
    toast('Backup downloaded', 'success');
  } catch (err) {
    backupResult('Download failed: ' + err.message, 'err');
    toast('Backup failed', 'error');
  }
}

async function restoreBackup(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  if (!confirm('Restore "' + file.name + '"?\n\nThis replaces ALL current data with the contents of this backup file.')) {
    input.value = '';
    return;
  }
  try {
    backupResult('Restoring backup… please wait.', 'working');
    const fd = new FormData();
    fd.append('backup', file);
    const r = await fetch('/api/warden/backup/restore', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + S.token },
      body: fd
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Restore failed');
    backupResult('✅ Restored — ' + d.students + ' students recovered. Refreshing dashboards…', 'ok');
    toast('Backup restored: ' + d.students + ' students', 'success');
    setTimeout(() => { loadWardenAll(); loadStudentAll && loadStudentAll(); }, 700);
  } catch (err) {
    backupResult('Restore failed: ' + err.message, 'err');
    toast('Restore failed', 'error');
  } finally {
    input.value = '';
  }
}

async function syncBackupNow() {
  try {
    backupResult('Syncing to the cloud…', 'working');
    const d = await api('/api/warden/backup/sync', { method: 'POST' });
    backupResult(d.success ? '✅ Cloud sync complete.' : ('Sync failed: ' + (d.error || 'unknown error')), d.success ? 'ok' : 'err');
    toast(d.success ? 'Synced to cloud' : 'Sync failed', d.success ? 'success' : 'error');
    loadBackupStatus();
  } catch (err) {
    backupResult('Sync failed: ' + err.message, 'err');
    toast('Sync failed', 'error');
  }
}

async function exportJson() {
  try {
    backupResult('Building JSON export…', 'working');
    const r = await fetch('/api/warden/export/json', {
      headers: { 'Authorization': 'Bearer ' + S.token }
    });
    if (!r.ok) throw new Error('Export failed');
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hostel-export-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    backupResult('JSON export downloaded — readable copy of all students, events and attendance.', 'ok');
    toast('Export downloaded', 'success');
  } catch (err) {
    backupResult('Export failed: ' + err.message, 'err');
  }
}

// Refresh the sync badge every minute while the warden tab is open
setInterval(() => {
  if (S.user && S.user.role === 'WARDEN' && S.token) loadBackupStatus();
}, 60000);

function renderWardenStats(stats) {
  document.getElementById('w-stats-row').innerHTML = `
    <div class="stat-box s-total"><div class="sb-icon" style="color:var(--blue);"><i class="fas fa-users"></i></div><div class="sb-val">${stats.total}</div><div class="sb-label">Total Students</div></div>
    <div class="stat-box s-in"><div class="sb-icon" style="color:var(--green);"><i class="fas fa-building"></i></div><div class="sb-val">${stats.in_campus}</div><div class="sb-label">In Campus</div></div>
    <div class="stat-box s-out"><div class="sb-icon" style="color:var(--red);"><i class="fas fa-sign-out-alt"></i></div><div class="sb-val">${stats.outside}</div><div class="sb-label">Outside</div></div>
    <div class="stat-box s-hostel"><div class="sb-icon" style="color:var(--purple);"><i class="fas fa-hotel"></i></div><div class="sb-val">${stats.hostels}</div><div class="sb-label">Hostels</div></div>`;
}

function renderWardenMonitoring(data) {
  document.getElementById('w-in-count').textContent = data.in_campus.length;
  document.getElementById('w-out-count').textContent = data.outside.length;

  const colors = ['#8b5cf6','#3b82f6','#06b6d4','#f59e0b','#ef4444','#ec4899','#22c55e'];

  // Warden also needs to see at a glance who has permission to be away
  const leaveLine = (s) => s.on_leave
    ? `<div class="si-leave" style="color:#c084fc;"><i class="fas fa-tag"></i> ${esc(s.leave_type)} leave approved</div>`
    : '';

  document.getElementById('w-in-list').innerHTML = data.in_campus.length
    ? data.in_campus.map(s => `<div class="s-item ${s.on_leave ? 'is-on-leave' : ''}" style="cursor:pointer;" onclick="viewStudent(${s.id})">
        <div class="si-avatar" style="background:${colors[s.id % colors.length]};">${esc(s.name[0])}</div>
        <div class="si-info">
          <div class="si-name">${esc(s.name)} ${s.on_leave ? '<span class="leave-dot"></span>' : ''}</div>
          <div class="si-meta">${esc(s.enrollment_no)} · ${esc(s.hostel_name)} · R${esc(s.room_no)}</div>
          ${s.last_outside_duration ? `<div class="si-duration" style="color:var(--orange);">⏱ Last outside: ${esc(s.last_outside_duration)}</div>` : ''}
          ${leaveLine(s)}
        </div>
        <div class="si-time" style="color:var(--green);">🟢<br>${fmtTime(s.last_checkin)}</div>
      </div>`).join('')
    : '<div class="empty"><p>No students in campus</p></div>';

  document.getElementById('w-out-list').innerHTML = data.outside.length
    ? data.outside.map(s => `<div class="s-item ${s.on_leave ? 'is-on-leave' : ''}" style="cursor:pointer;" onclick="viewStudent(${s.id})">
        <div class="si-avatar" style="background:${colors[s.id % colors.length]};">${esc(s.name[0])}</div>
        <div class="si-info">
          <div class="si-name">${esc(s.name)} ${s.on_leave ? '<span class="leave-dot"></span>' : ''}</div>
          <div class="si-meta">${esc(s.enrollment_no)} · ${esc(s.hostel_name)} · R${esc(s.room_no)}</div>
          <div class="si-duration" data-co="${s.last_checkout}">⏱ ${calcDur(s.last_checkout)}</div>
          ${leaveLine(s)}
        </div>
        <div class="si-time" style="color:var(--red);">🔴<br>${fmtTime(s.last_checkout)}</div>
      </div>`).join('')
    : '<div class="empty"><p>No students outside</p></div>';

  // Timer for outside durations
  if (S.durationTimer) clearInterval(S.durationTimer);
  S.durationTimer = setInterval(() => {
    document.querySelectorAll('[data-co]').forEach(el => {
      el.innerHTML = `⏱ ${calcDur(el.dataset.co)}`;
    });
  }, 10000);
}

async function loadWardenStudents() {
  try {
    const search = document.getElementById('w-search')?.value || '';
    const status = document.getElementById('w-status-filter')?.value || '';
    const hostel = document.getElementById('w-hostel-filter')?.value || '';
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (status) params.set('status', status);
    if (hostel) params.set('hostel', hostel);
    const students = await api(`/api/warden/students?${params}`);
    const tbody = document.getElementById('w-students-tbody');
    if (!students.length) { tbody.innerHTML = '<tr><td colspan="6"><div class="empty"><p>No students found</p></div></td></tr>'; return; }
    tbody.innerHTML = students.map(s => {
      const isIn = s.current_status === 'IN_CAMPUS';
      return `<tr style="cursor:pointer;" onclick="viewStudent(${s.id})">
        <td><strong>${s.name}</strong></td>
        <td>${s.enrollment_no}</td>
        <td>${s.hostel_name}</td>
        <td>${s.room_no}</td>
        <td><span class="badge ${isIn ? 'in' : 'out'}">${isIn ? 'In Campus' : 'Outside'}</span></td>
        <td onclick="event.stopPropagation()">
          <button class="table-btn view" onclick="viewStudent(${s.id})" title="View Details"><i class="fas fa-eye"></i></button>
          <button class="table-btn edit" onclick="editStudent(${s.id})" title="Edit Student"><i class="fas fa-edit"></i></button>
          <button class="table-btn del" onclick="confirmDelete(${s.id},'${s.name}')" title="Delete Student"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`;
    }).join('');
  } catch {}
}

function renderWardenRecent(data) {
  const events = [...(data.recent_checkouts || []), ...(data.recent_checkins || [])].sort((a, b) => b.id - a.id).slice(0, 15);
  const el = document.getElementById('w-recent-events');
  if (!events.length) { el.innerHTML = '<div class="empty"><p>No recent events</p></div>'; return; }
  el.innerHTML = events.map(e => {
    const isIn = e.event_type === 'CHECK_IN';
    return `<div class="h-item">
      <div class="h-icon ${isIn ? 'checkin' : 'checkout'}"><i class="fas fa-${isIn ? 'arrow-left' : 'arrow-right'}"></i></div>
      <div class="h-info">
        <strong>${e.name}</strong>
        <span>${e.enrollment_no} — ${isIn ? 'Checked In' : 'Checked Out'}${isIn && e.outside_duration ? ` · <span style="color:var(--orange);font-weight:600;">⏱ ${e.outside_duration}</span>` : ''}</span>
      </div>
      <div class="h-time">${e.event_date}<br>${fmtTime(e.event_time)}</div>
    </div>`;
  }).join('');
}

// ─── Warden CRUD ─────────────────────────────────────────────
function showAddStudent() {
  document.getElementById('modal-box').innerHTML = `
    <h2><i class="fas fa-user-plus" style="color:var(--purple);"></i> Add Student</h2>
    <form onsubmit="addStudent(event)">
      <div class="fg-row"><div class="fg"><label>Name *</label><input id="a-name" required></div><div class="fg"><label>Enrollment *</label><input id="a-enroll" required></div></div>
      <div class="fg-row"><div class="fg"><label>Phone *</label><input id="a-phone" required pattern="[0-9]{10}"></div><div class="fg"><label>Blood Group</label><select id="a-blood"><option value="">-</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>O+</option><option>O-</option><option>AB+</option><option>AB-</option></select></div></div>
      <div class="fg-row"><div class="fg"><label>Branch *</label><select id="a-branch" required><option value="">-</option><option>CSE</option><option>ECE</option><option>ME</option><option>CE</option><option>EE</option><option>IT</option><option>CY</option></select></div><div class="fg"><label>Section *</label><select id="a-section" required><option value="">-</option><option>A</option><option>B</option><option>C</option></select></div></div>
      <div class="fg-row"><div class="fg"><label>Parent Name *</label><input id="a-pname" required></div><div class="fg"><label>Parent Phone *</label><input id="a-pphone" required pattern="[0-9]{10}"></div></div>
      <div class="fg-row"><div class="fg"><label>Hostel *</label><select id="a-hostel" required><option value="">-</option><option>Boys Hostel</option><option>Girls Hostel</option></select></div><div class="fg"><label>Room *</label><input id="a-room" required></div></div>
      <div class="fg-row"><div class="fg"><label>Floor *</label><select id="a-floor" required><option value="">-</option><option>Ground</option><option>1</option><option>2</option><option>3</option></select></div><div class="fg"><label>Password *</label><input type="password" id="a-pass" required minlength="6"></div></div>
      <div class="modal-actions"><button type="button" class="btn-action" style="background:var(--glass);border:1px solid var(--glass-border);" onclick="closeModal()">Cancel</button><button type="submit" class="btn-action btn-purple">Add Student</button></div>
    </form>`;
  openModal();
}

async function addStudent(e) {
  e.preventDefault();
  try {
    await api('/api/warden/students', {
      method: 'POST',
      body: JSON.stringify({
        name: gv('a-name'), enrollment_no: gv('a-enroll'), phone: gv('a-phone'),
        branch: gv('a-branch'), section: gv('a-section'), blood_group: gv('a-blood'),
        parent_name: gv('a-pname'), parent_phone: gv('a-pphone'),
        hostel_name: gv('a-hostel'), room_no: gv('a-room'),
        floor: gv('a-floor'), password: gv('a-pass')
      })
    });
    closeModal(); toast('Student added!', 'success');
    loadWardenStudents();
  } catch (err) { toast(err.message, 'error'); }
}

async function viewStudent(id) {
  try {
    const data = await api(`/api/warden/students/${id}`);
    const s = data.student;
    const isIn = s.current_status === 'IN_CAMPUS';
    const photo = s.photo_url ? `<img src="${s.photo_url}">` : '<i class="fas fa-user"></i>';
    const durHtml = (!isIn && s.last_checkout) ? `<div style="margin-top:8px;padding:10px 14px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:8px;display:inline-block;"><span style="color:var(--orange);font-weight:700;">⏱ Outside: ${calcDur(s.last_checkout)}</span></div>` : '';
    const lastDurHtml = (isIn && s.last_outside_duration) ? `<div style="margin-top:8px;padding:10px 14px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:8px;display:inline-block;"><span style="color:var(--orange);font-weight:700;">⏱ Last Outside: ${s.last_outside_duration}</span></div>` : '';

    // Leave banner + the action the gate actually needs
    const leaveHtml = s.on_leave ? `
      <div style="margin-top:14px;padding:14px 16px;border-radius:12px;background:linear-gradient(135deg,rgba(168,85,247,0.18),rgba(59,130,246,0.12));border:1px solid rgba(168,85,247,0.45);">
        <div style="font-weight:800;color:#c084fc;font-size:0.9rem;margin-bottom:6px;"><i class="fas fa-plane-departure"></i> ON ${esc(s.leave_type)} LEAVE — APPROVED</div>
        <div style="font-size:0.82rem;color:var(--text2);">
          <i class="fas fa-calendar"></i> ${fmtDate(s.leave_from)} → ${fmtDate(s.leave_until)}
          ${s.leave_destination ? ` · <i class="fas fa-location-dot"></i> ${esc(s.leave_destination)}` : ''}
        </div>
        ${s.leave_note ? `<div style="font-size:0.8rem;color:var(--text3);margin-top:6px;"><i class="fas fa-comment-dots"></i> ${esc(s.leave_note)}</div>` : ''}
        <button class="btn-action ${isIn ? 'btn-orange' : 'btn-green'} btn-sm" style="margin-top:12px;" onclick="closeModal();leaveEntry(${id}, '${esc(s.name)}')">
          <i class="fas fa-${isIn ? 'right-from-bracket' : 'right-to-bracket'}"></i> ${isIn ? 'Mark Out (leaving)' : 'Mark In (returned)'}
        </button>
      </div>` : (s.upcoming_leave ? `
      <div style="margin-top:14px;padding:12px 16px;border-radius:12px;background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.3);font-size:0.82rem;color:var(--text2);">
        <i class="fas fa-calendar-check" style="color:var(--blue);"></i> Upcoming approved leave: <strong>${esc(s.upcoming_leave.type)}</strong> ${fmtDate(s.upcoming_leave.from)} → ${fmtDate(s.upcoming_leave.to)}
      </div>` : '');
    document.getElementById('modal-box').innerHTML = `
      <h2><i class="fas fa-user" style="color:var(--blue);"></i> ${s.name}</h2>
      <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px;">
        <div class="profile-avatar" style="width:56px;height:56px;">${photo}</div>
        <div><p style="color:var(--text2);">${esc(s.enrollment_no)} · ${esc(s.branch)}-${esc(s.section)}</p>
          <span class="badge ${isIn ? 'in' : 'out'}">${isIn ? '🟢 In Campus' : '🔴 Outside'}</span>
          ${s.on_leave ? `<span class="badge leave" style="margin-left:6px;"><i class="fas fa-plane-departure"></i> On Leave</span>` : ''}
        </div>
      </div>
      ${durHtml}${lastDurHtml}
      ${leaveHtml}
      <div class="profile-grid" style="margin-top:16px;">
        <div class="profile-item"><label>Phone</label><span>${s.phone}</span></div>
        <div class="profile-item"><label>Blood Group</label><span>${s.blood_group || 'N/A'}</span></div>
        <div class="profile-item"><label>Parent</label><span>${s.parent_name}</span></div>
        <div class="profile-item"><label>Parent Phone</label><span>${s.parent_phone}</span></div>
        <div class="profile-item"><label>Hostel</label><span>${s.hostel_name}</span></div>
        <div class="profile-item"><label>Room / Floor</label><span>Room ${s.room_no}, Floor ${s.floor}</span></div>
        ${isIn ? `<div class="profile-item"><label>Last Check-In</label><span>${fmtDT(s.last_checkin)}</span></div>` : `<div class="profile-item"><label>Last Check-Out</label><span>${fmtDT(s.last_checkout)}</span></div>`}
      </div>
      <h3 style="margin-top:16px;font-size:0.9rem;"><i class="fas fa-clock-rotate-left"></i> Recent Events</h3>
      <div style="max-height:150px;overflow-y:auto;">
        ${data.events.length ? data.events.slice(0, 8).map(e => `<div class="h-item"><div class="h-icon ${e.event_type === 'CHECK_IN' ? 'checkin' : 'checkout'}"><i class="fas fa-${e.event_type === 'CHECK_IN' ? 'arrow-left' : 'arrow-right'}"></i></div><div class="h-info"><strong>${e.event_type === 'CHECK_IN' ? 'Checked In' : 'Checked Out'}</strong>${e.outside_duration ? `<span> · ⏱ ${e.outside_duration}</span>` : ''}</div><div class="h-time">${e.event_date} ${fmtTime(e.event_time)}</div></div>`).join('') : '<div class="empty"><p>No events</p></div>'}
      </div>
      <div class="modal-actions"><button class="btn-action" style="background:var(--glass);border:1px solid var(--glass-border);" onclick="closeModal()">Close</button></div>`;
    openModal();
  } catch (err) { toast(err.message, 'error'); }
}

// Gate Pass: View student details
async function viewStudentGate(id) {
  try {
    const data = await api(`/api/getpass/students/${id}`);
    const s = data.student;
    const isIn = s.current_status === 'IN_CAMPUS';
    const photo = s.photo_url ? `<img src="${s.photo_url}">` : '<i class="fas fa-user"></i>';
    const durHtml = (!isIn && s.last_checkout) ? `<div style="margin-top:8px;padding:10px 14px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:8px;display:inline-block;"><span style="color:var(--orange);font-weight:700;">⏱ Outside: ${calcDur(s.last_checkout)}</span></div>` : '';
    const lastDurHtml = (isIn && s.last_outside_duration) ? `<div style="margin-top:8px;padding:10px 14px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:8px;display:inline-block;"><span style="color:var(--orange);font-weight:700;">⏱ Last Outside: ${s.last_outside_duration}</span></div>` : '';
    document.getElementById('modal-box').innerHTML = `
      <h2><i class="fas fa-user" style="color:var(--orange);"></i> ${s.name}</h2>
      <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px;">
        <div class="profile-avatar" style="width:56px;height:56px;">${photo}</div>
        <div><p style="color:var(--text2);">${s.enrollment_no} · ${s.branch}-${s.section}</p><span class="badge ${isIn ? 'in' : 'out'}">${isIn ? '🟢 In Campus' : '🔴 Outside'}</span></div>
      </div>
      ${durHtml}${lastDurHtml}
      <div class="profile-grid" style="margin-top:16px;">
        <div class="profile-item"><label>Phone</label><span>${s.phone}</span></div>
        <div class="profile-item"><label>Blood Group</label><span>${s.blood_group || 'N/A'}</span></div>
        <div class="profile-item"><label>Parent</label><span>${s.parent_name}</span></div>
        <div class="profile-item"><label>Parent Phone</label><span>${s.parent_phone}</span></div>
        <div class="profile-item"><label>Hostel</label><span>${s.hostel_name}</span></div>
        <div class="profile-item"><label>Room / Floor</label><span>Room ${s.room_no}, Floor ${s.floor}</span></div>
        ${isIn ? `<div class="profile-item"><label>Last Check-In</label><span>${fmtDT(s.last_checkin)}</span></div>` : `<div class="profile-item"><label>Last Check-Out</label><span>${fmtDT(s.last_checkout)}</span></div>`}
      </div>
      <h3 style="margin-top:16px;font-size:0.9rem;"><i class="fas fa-clock-rotate-left"></i> Recent Gate Activity</h3>
      <div style="max-height:150px;overflow-y:auto;">
        ${data.events.length ? data.events.slice(0, 8).map(e => `<div class="h-item"><div class="h-icon ${e.event_type === 'CHECK_IN' ? 'checkin' : 'checkout'}"><i class="fas fa-${e.event_type === 'CHECK_IN' ? 'arrow-left' : 'arrow-right'}"></i></div><div class="h-info"><strong>${e.event_type === 'CHECK_IN' ? 'Checked In' : 'Checked Out'}</strong>${e.outside_duration ? `<span> · ⏱ ${e.outside_duration}</span>` : ''}</div><div class="h-time">${e.event_date} ${fmtTime(e.event_time)}</div></div>`).join('') : '<div class="empty"><p>No events</p></div>'}
      </div>
      <div class="modal-actions"><button class="btn-action" style="background:var(--glass);border:1px solid var(--glass-border);" onclick="closeModal()">Close</button></div>`;
    openModal();
  } catch (err) { toast(err.message, 'error'); }
}

async function editStudent(id) {
  try {
    const data = await api(`/api/warden/students/${id}`);
    const s = data.student;
    document.getElementById('modal-box').innerHTML = `
      <h2><i class="fas fa-edit" style="color:var(--orange);"></i> Edit ${s.name}</h2>
      <form onsubmit="saveStudent(event,${id})">
        <div class="fg-row"><div class="fg"><label>Name</label><input id="e-name" value="${s.name}" required></div><div class="fg"><label>Phone</label><input id="e-phone" value="${s.phone}" required></div></div>
        <div class="fg-row"><div class="fg"><label>Branch</label><select id="e-branch">${['CSE','ECE','ME','CE','EE','IT','CY'].map(b=>`<option ${s.branch===b?'selected':''}>${b}</option>`).join('')}</select></div><div class="fg"><label>Section</label><select id="e-section">${['A','B','C','D'].map(x=>`<option ${s.section===x?'selected':''}>${x}</option>`).join('')}</select></div></div>
        <div class="fg-row"><div class="fg"><label>Parent</label><input id="e-pname" value="${s.parent_name}" required></div><div class="fg"><label>Parent Ph.</label><input id="e-pphone" value="${s.parent_phone}" required></div></div>
        <div class="fg-row"><div class="fg"><label>Hostel</label><select id="e-hostel">${['Boys Hostel','Girls Hostel'].map(h=>`<option ${s.hostel_name===h?'selected':''}>${h}</option>`).join('')}</select></div><div class="fg"><label>Room</label><input id="e-room" value="${s.room_no}" required></div></div>
        <div class="fg-row"><div class="fg"><label>Floor</label><select id="e-floor">${['Ground','1','2','3','4'].map(f=>`<option ${s.floor===f?'selected':''}>${f}</option>`).join('')}</select></div><div class="fg"><label>New Password</label><input type="password" id="e-pass" placeholder="Leave blank"></div></div>
        <div class="modal-actions"><button type="button" class="btn-action" style="background:var(--glass);border:1px solid var(--glass-border);" onclick="closeModal()">Cancel</button><button type="submit" class="btn-action btn-orange">Save</button></div>
      </form>`;
    openModal();
  } catch (err) { toast(err.message, 'error'); }
}

async function saveStudent(e, id) {
  e.preventDefault();
  try {
    const body = { name: gv('e-name'), phone: gv('e-phone'), branch: gv('e-branch'), section: gv('e-section'), parent_name: gv('e-pname'), parent_phone: gv('e-pphone'), hostel_name: gv('e-hostel'), room_no: gv('e-room'), floor: gv('e-floor') };
    const pw = gv('e-pass'); if (pw) body.password = pw;
    await api(`/api/warden/students/${id}`, { method: 'PUT', body: JSON.stringify(body) });
    closeModal(); toast('Student updated!', 'success');
    loadWardenStudents();
  } catch (err) { toast(err.message, 'error'); }
}

function confirmDelete(id, name) {
  document.getElementById('modal-box').innerHTML = `
    <h2><i class="fas fa-exclamation-triangle" style="color:var(--red);"></i> Delete Student</h2>
    <p style="margin:16px 0;font-size:1rem;">Are you sure you want to permanently delete <strong>${name}</strong>?</p>
    <p style="color:var(--red);font-size:0.85rem;"><i class="fas fa-warning"></i> This will remove their account, attendance records, and all gate pass history. This cannot be undone.</p>
    <div class="modal-actions"><button class="btn-action" style="background:var(--glass);border:1px solid var(--glass-border);" onclick="closeModal()">Cancel</button><button class="btn-action btn-red" onclick="deleteStudent(${id})"><i class="fas fa-trash"></i> Delete Permanently</button></div>`;
  openModal();
}

async function deleteStudent(id) {
  try {
    await api(`/api/warden/students/${id}`, { method: 'DELETE' });
    closeModal(); toast('Student deleted permanently', 'success');
    loadWardenAll();
  } catch (err) { toast(err.message, 'error'); }
}

// ─── Hostel Filters ──────────────────────────────────────────
let hostelFiltersLoaded = false;
async function loadHostelFilters() {
  if (hostelFiltersLoaded) return;
  try {
    const hostels = await api('/api/hostels');
    const sel = document.getElementById('w-hostel-filter');
    hostels.forEach(h => { const o = document.createElement('option'); o.value = h; o.textContent = h; sel.appendChild(o); });
    hostelFiltersLoaded = true;
  } catch {}
}

// ─── Modal ───────────────────────────────────────────────────
function closeModal(e) { if (e && e.target !== e.currentTarget) return; document.getElementById('modal-overlay').style.display = 'none'; }

// ─── Helpers ─────────────────────────────────────────────────
function gv(id) { return document.getElementById(id)?.value || ''; }

// Password reveal
function togglePasswords() {
  const btn = document.getElementById('password-reveal-btn');
  const details = document.getElementById('password-details');
  if (details.style.display === 'none') {
    details.style.display = 'block';
    btn.innerHTML = '<i class="fas fa-lock"></i> Hide Passwords';
    btn.classList.add('active');
  } else {
    details.style.display = 'none';
    btn.innerHTML = '<i class="fas fa-key"></i> Show Passwords';
    btn.classList.remove('active');
  }
}
function fmtDT(dt) {
  if (!dt) return 'N/A';
  try { const [d, t] = dt.split(' '); return fmtDate(d) + ' — ' + fmtTime(t); } catch { return dt; }
}
function fmtDate(d) { try { const [y,m,dd] = d.split('-'); const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']; return `${dd} ${months[parseInt(m)-1]} ${y}`; } catch { return d; } }
function extractTime(t) {
  if (!t) return '';
  // Handle "YYYY-MM-DD HH:MM" format - extract just the time part
  if (typeof t === 'string' && t.includes(' ')) return t.split(' ').pop();
  return t;
}
function fmtTime(t) {
  if (!t) return '';
  t = extractTime(t);
  try {
    const parts = String(t).split(':');
    const hr = parseInt(parts[0]);
    const mn = parts[1] || '00';
    if (isNaN(hr)) return t;
    return `${hr % 12 || 12}:${mn} ${hr >= 12 ? 'PM' : 'AM'}`;
  } catch { return t; }
}
function calcDur(co) {
  if (!co) return '0m';
  try {
    // Parse as IST time by appending timezone offset
    const coDate = new Date(co.replace(' ', 'T') + ':00+05:30');
    const diff = Math.floor((Date.now() - coDate.getTime()) / 60000);
    if (diff < 0) return '0m';
    const h = Math.floor(diff/60), m = diff%60;
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  } catch { return '0m'; }
}

function handleAttendanceUpdate(data) {
  if (S.activeTab === 'student') loadStudentAttendance();
  if (S.activeTab === 'warden') loadWardenAttendance();
}

function handleAttendanceUpdateAll(data) {
  toast(`Attendance marked for ${data.count} students by Warden`, 'info');
  if (S.activeTab === 'student') loadStudentAttendance();
  if (S.activeTab === 'warden') loadWardenAttendance();
}

function handleAttendanceSettingsUpdate(data) {
  toast(`Attendance time changed to ${data.attendance_time}`, 'info');
  if (S.activeTab === 'student') loadStudentAttendance();
  if (S.activeTab === 'warden') loadWardenAttendance();
}

// ═══════════════════════════════════════════════════════════════
//  ATTENDANCE SYSTEM
// ═══════════════════════════════════════════════════════════════

// Student: Load attendance
async function loadStudentAttendance() {
  try {
    const data = await api('/api/attendance/student');
    const statusEl = document.getElementById('s-attendance-status');
    const btnEl = document.getElementById('s-attendance-btn');
    const infoEl = document.getElementById('s-attendance-info');
    const historyEl = document.getElementById('s-attendance-history');
    
    if (data.today) {
      if (data.today.status === 'present') {
        const byLabel = data.today.marked_by === 'self' ? 'Self' : 'Warden';
        statusEl.className = 'attendance-status present';
        statusEl.innerHTML = `<i class="fas fa-check-circle"></i> ✅ Present — Marked by ${byLabel} at ${fmtTime(data.today.time)}`;
      } else {
        statusEl.className = 'attendance-status absent';
        statusEl.innerHTML = `<i class="fas fa-times-circle"></i> ❌ Absent — Marked by Warden at ${fmtTime(data.today.time)}`;
      }
      btnEl.disabled = true;
      btnEl.innerHTML = '<i class="fas fa-check"></i> Already Marked';
      infoEl.textContent = '';
    } else {
      // Check current time vs attendance window
      const now = new Date();
      const [startH, startM] = (data.start_time || '21:00').split(':').map(Number);
      const [endH, endM] = (data.end_time || '22:00').split(':').map(Number);
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      const startMinutes = startH * 60 + startM;
      const endMinutes = endH * 60 + endM;
      
      if (currentMinutes >= startMinutes && currentMinutes <= endMinutes) {
        // Within window — can mark
        statusEl.className = 'attendance-status not-marked';
        statusEl.innerHTML = `<i class="fas fa-clock"></i> Attendance window is OPEN — Mark now!`;
        btnEl.disabled = false;
        btnEl.innerHTML = '<i class="fas fa-check-circle"></i> Mark My Attendance';
        btnEl.className = 'btn-attendance';
        infoEl.textContent = `Window: ${data.start_time} to ${data.end_time}`;
      } else if (currentMinutes < startMinutes) {
        // Before window
        const remaining = startMinutes - currentMinutes;
        const rH = Math.floor(remaining / 60);
        const rM = remaining % 60;
        statusEl.className = 'attendance-status locked';
        statusEl.innerHTML = `<i class="fas fa-lock"></i> Attendance opens at ${data.start_time}`;
        btnEl.disabled = true;
        btnEl.innerHTML = `<i class="fas fa-lock"></i> Opens at ${data.start_time}`;
        infoEl.textContent = `Window: ${data.start_time} to ${data.end_time} — Wait ${rH}h ${rM}m`;
      } else {
        // After window closed
        statusEl.className = 'attendance-status locked';
        statusEl.innerHTML = `<i class="fas fa-times-circle"></i> Attendance window closed at ${data.end_time}`;
        btnEl.disabled = true;
        btnEl.innerHTML = '<i class="fas fa-times-circle"></i> Window Closed';
        infoEl.textContent = `Window was: ${data.start_time} to ${data.end_time}`;
      }
    }
    
    // History
    if (data.history && data.history.length > 0) {
      let html = '<h4>Last 30 Days</h4>';
      data.history.forEach(h => {
        const byLabel = h.marked_by === 'self' ? '🧑 Self' : '👨‍💼 Warden';
        html += `<div class="attendance-day">
          <span class="day-date">${fmtDate(h.date)}</span>
          <span class="day-status ${h.status}">${h.status === 'present' ? '✓ Present' : '✗ Absent'} (${byLabel})</span>
        </div>`;
      });
      historyEl.innerHTML = html;
    } else {
      historyEl.innerHTML = '<h4>No attendance records yet</h4>';
    }
  } catch (err) {
    console.error('Load attendance error:', err);
  }
}

// Student: Mark attendance
async function markAttendance() {
  try {
    const data = await api('/api/attendance/mark', { method: 'POST' });
    toast('Attendance marked successfully! ✓', 'success');
    loadStudentAttendance();
  } catch (err) {
    toast(err.message || 'Failed to mark attendance', 'error');
  }
}

// Warden: Load attendance
async function loadWardenAttendance() {
  try {
    const dateInput = document.getElementById('w-attendance-date');
    const date = dateInput.value || new Date().toISOString().split('T')[0];
    if (!dateInput.value) dateInput.value = date;
    
    const data = await api(`/api/attendance/warden?date=${date}`);
    
    // Set attendance time inputs
    document.getElementById('w-attendance-start').value = data.start_time || '21:00';
    document.getElementById('w-attendance-end').value = data.end_time || '22:00';
    
    // Stats
    const marked = data.attendance.length;
    const present = data.attendance.filter(a => a.status === 'present').length;
    const absent = data.attendance.filter(a => a.status === 'absent').length;
    const notMarked = data.all_students.length - marked;
    const total = data.all_students.length;
    
    document.getElementById('w-attendance-stats').innerHTML = `
      <div class="att-stat total"><div class="att-val">${total}</div><div class="att-label">Total Students</div></div>
      <div class="att-stat present"><div class="att-val">${present}</div><div class="att-label">✓ Present</div></div>
      <div class="att-stat absent"><div class="att-val">${absent + notMarked}</div><div class="att-label">✗ Absent / Not Marked</div></div>
    `;
    
    // Build attendance map
    const attMap = {};
    data.attendance.forEach(a => { attMap[a.student_id] = a; });
    
    // Table
    const tbody = document.getElementById('w-attendance-tbody');
    tbody.innerHTML = data.all_students.map(s => {
      const att = attMap[s.id];
      const isMarked = !!att;
      const status = isMarked ? att.status : 'not-marked';
      let statusLabel, statusClass;
      if (!isMarked) {
        statusLabel = '— Not Marked';
        statusClass = 'not-marked';
      } else if (att.status === 'present') {
        statusLabel = '✓ Present';
        statusClass = 'present';
      } else {
        statusLabel = '✗ Absent';
        statusClass = 'absent';
      }
      const markedBy = isMarked ? (att.marked_by === 'self' ? '🧑 Self' : '👨‍💼 Warden') : '—';
      return `<tr>
        <td><strong>${s.name}</strong></td>
        <td>${s.enrollment_no}</td>
        <td>${s.hostel_name}</td>
        <td>${s.room_no}</td>
        <td><span class="day-status ${statusClass}" style="padding:4px 12px;border-radius:12px;font-size:0.8rem;">${statusLabel}</span></td>
        <td>${isMarked ? fmtTime(att.time) : '—'}</td>
        <td style="font-size:0.8rem;">${markedBy}</td>
        <td>
          <button class="table-btn view" onclick="wardenMarkAttendance(${s.id},'present')" title="Mark Present"><i class="fas fa-check"></i></button>
          <button class="table-btn del" onclick="wardenMarkAttendance(${s.id},'absent')" title="Mark Absent"><i class="fas fa-times"></i></button>
        </td>
      </tr>`;
    }).join('');
  } catch (err) {
    console.error('Load warden attendance error:', err);
  }
}

// Warden: Mark single student attendance
async function wardenMarkAttendance(studentId, status) {
  try {
    const date = document.getElementById('w-attendance-date').value || new Date().toISOString().split('T')[0];
    await api('/api/attendance/warden/mark', {
      method: 'POST',
      body: JSON.stringify({ student_id: studentId, date, status })
    });
    toast(`Attendance marked: ${status}`, 'success');
    loadWardenAttendance();
  } catch (err) {
    toast(err.message || 'Failed to mark attendance', 'error');
  }
}

// Warden: Mark all students present
async function markAllAttendance() {
  if (!confirm('Mark all students as present for the selected date?')) return;
  try {
    const date = document.getElementById('w-attendance-date').value || new Date().toISOString().split('T')[0];
    const data = await api('/api/attendance/warden/mark-all', {
      method: 'POST',
      body: JSON.stringify({ date, status: 'present' })
    });
    toast(`Attendance marked for ${data.count} students! ✓`, 'success');
    loadWardenAttendance();
  } catch (err) {
    toast(err.message || 'Failed to mark all attendance', 'error');
  }
}

// Warden: Update attendance time window
async function updateAttendanceTime() {
  const startTime = document.getElementById('w-attendance-start').value;
  const endTime = document.getElementById('w-attendance-end').value;
  if (!startTime || !endTime) return;
  try {
    await api('/api/attendance/settings', {
      method: 'PUT',
      body: JSON.stringify({ start_time: startTime, end_time: endTime })
    });
    toast(`Attendance window set to ${startTime} - ${endTime}`, 'success');
    // Reload student attendance if active
    if (S.activeTab === 'student') loadStudentAttendance();
  } catch (err) {
    toast(err.message || 'Failed to update time', 'error');
  }
}

// ═══════════════════════════════════════════════════════════════
//  INIT
// ═══════════════════════════════════════════════════════════════

/* ═══════════════════════════════════════════════════════════════
   STUDENT — LEAVE / OUTPASS
   ═══════════════════════════════════════════════════════════════ */
async function loadStudentSummary() {
  try {
    const d = await api('/api/student/summary');
    S.summary = d;

    // Badge counts on the sub-nav
    badge('badge-s-leave', (d.counts.pending_leaves || 0) + (d.counts.approved_leaves || 0));
    badge('badge-s-complaints', d.counts.open_complaints || 0);

    // Active outpass card
    const card = document.getElementById('s-active-pass-card');
    if (card) {
      if (d.today_leave) {
        const lv = d.today_leave;
        card.style.display = 'block';
        card.innerHTML = `
          <h3><i class="fas fa-plane-departure"></i> You Are On Leave</h3>
          <div class="item-card ok" style="margin-top:10px;">
            <div class="item-title">${esc(lv.leave_type)} leave</div>
            <div class="item-sub"><i class="fas fa-calendar"></i> ${fmtDate(lv.from_date)} → ${fmtDate(lv.to_date)}${lv.destination ? ' · ' + esc(lv.destination) : ''}</div>
            <p class="muted-note" style="margin:12px 0 0;">
              <i class="fas fa-circle-check" style="color:var(--green);"></i>
              Your leave is approved. The gate can see your name on the leave list — just tell them your name, nothing else needed.
            </p>
            ${lv.warden_remark ? `<p class="item-body" style="margin-top:12px;"><i class="fas fa-comment-dots" style="color:var(--cyan);"></i> ${esc(lv.warden_remark)}</p>` : ''}
          </div>`;
      } else if (d.upcoming_leave) {
        const lv = d.upcoming_leave;
        card.style.display = 'block';
        card.innerHTML = `
          <h3><i class="fas fa-calendar-check"></i> Upcoming Leave</h3>
          <div class="item-card info" style="margin-top:10px;">
            <div class="item-title">${esc(lv.leave_type)} leave ${statusChip('APPROVED')}</div>
            <div class="item-sub"><i class="fas fa-calendar"></i> ${fmtDate(lv.from_date)} → ${fmtDate(lv.to_date)}${lv.destination ? ' · ' + esc(lv.destination) : ''}</div>
            <p class="muted-note" style="margin:12px 0 0;"><i class="fas fa-clock" style="color:var(--cyan);"></i> Starts in ${Math.max(0, Math.ceil((new Date(lv.from_date) - new Date()) / 86400000))} day(s).</p>
          </div>`;
      } else {
        card.style.display = 'none';
      }
    }

    // SOS button state
    const sosBtn = document.getElementById('btn-sos');
    if (sosBtn) {
      sosBtn.disabled = !!d.active_sos;
      const small = sosBtn.querySelector('small');
      if (small) small.textContent = d.active_sos ? 'Alert already active — warden notified' : 'Send alert to warden';
    }
  } catch (err) { console.error('summary', err); }
}

async function loadMyLeaves() {
  const el = document.getElementById('s-leave-list');
  if (!el) return;
  try {
    const rows = await api('/api/leaves/mine');
    if (!rows.length) {
      el.innerHTML = emptyState('fa-plane-departure', 'No leave requests yet. Apply using the form.');
      return;
    }
    el.innerHTML = rows.map(l => {
      const cls = l.status === 'APPROVED' ? 'ok' : l.status === 'PENDING' ? 'warn' : l.status === 'REJECTED' ? 'bad' : '';
      return `
      <div class="item-card ${cls}">
        <div class="item-head">
          <div>
            <div class="item-title">${esc(l.leave_type)} leave ${statusChip(l.status)}</div>
            <div class="item-sub"><i class="fas fa-calendar"></i> ${fmtDate(l.from_date)} → ${fmtDate(l.to_date)}${l.destination ? ' · ' + esc(l.destination) : ''}</div>
          </div>
        </div>
        <p class="item-body">${esc(l.reason)}</p>
        ${l.warden_remark ? `<p class="item-body" style="border-left:2px solid var(--cyan);padding-left:10px;"><strong>Warden:</strong> ${esc(l.warden_remark)}</p>` : ''}
        <div class="item-meta"><span><i class="fas fa-clock"></i> Requested ${fmtDateTime(l.created_at)}</span></div>
        ${l.status === 'PENDING' ? `<div class="item-actions"><button class="btn-action btn-ghost btn-sm" onclick="cancelLeave(${l.id})"><i class="fas fa-xmark"></i> Cancel</button></div>` : ''}
      </div>`;
    }).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

async function submitLeave(e) {
  e.preventDefault();
  const payload = {
    leave_type: document.getElementById('lv-type').value,
    destination: document.getElementById('lv-destination').value.trim(),
    from_date: document.getElementById('lv-from').value,
    to_date: document.getElementById('lv-to').value,
    parent_contact: document.getElementById('lv-parent').value.trim(),
    reason: document.getElementById('lv-reason').value.trim()
  };
  if (new Date(payload.to_date) < new Date(payload.from_date)) {
    return toast('The "to" date cannot be before the "from" date.', 'error');
  }
  try {
    const d = await api('/api/leaves', { method: 'POST', body: JSON.stringify(payload) });
    toast(d.message || 'Request sent.', 'success');
    e.target.reset();
    loadMyLeaves();
    loadStudentSummary();
  } catch (err) { toast(err.message, 'error'); }
}

async function cancelLeave(id) {
  if (!confirm('Cancel this leave request?')) return;
  try {
    const d = await api(`/api/leaves/${id}/cancel`, { method: 'PUT' });
    toast(d.message, 'success');
    loadMyLeaves();
    loadStudentSummary();
  } catch (err) { toast(err.message, 'error'); }
}

/* ═══════════════════════════════════════════════════════════════
   STUDENT — COMPLAINTS
   ═══════════════════════════════════════════════════════════════ */
async function loadMyComplaints() {
  const el = document.getElementById('s-complaint-list');
  if (!el) return;
  try {
    const rows = await api('/api/complaints/mine');
    if (!rows.length) {
      el.innerHTML = emptyState('fa-screwdriver-wrench', 'No complaints filed. Everything working fine!');
      return;
    }
    el.innerHTML = rows.map(c => `
      <div class="item-card ${c.status === 'RESOLVED' || c.status === 'CLOSED' ? 'ok' : c.priority === 'URGENT' ? 'bad' : 'warn'}">
        <div class="item-head">
          <div>
            <div class="item-title">${esc(c.title)} ${statusChip(c.status)}</div>
            <div class="item-sub">${esc(c.category)}${c.priority ? ' · ' + esc(c.priority) : ''} priority</div>
          </div>
        </div>
        <p class="item-body">${esc(c.description)}</p>
        ${c.warden_reply ? `<p class="item-body" style="border-left:2px solid var(--cyan);padding-left:10px;"><strong>Warden:</strong> ${esc(c.warden_reply)}</p>` : ''}
        <div class="item-meta">
          <span><i class="fas fa-clock"></i> ${fmtDateTime(c.created_at)}</span>
          ${c.resolved_at ? `<span><i class="fas fa-check"></i> Resolved ${fmtDateTime(c.resolved_at)}</span>` : ''}
        </div>
      </div>`).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

async function submitComplaint(e) {
  e.preventDefault();
  const payload = {
    category: document.getElementById('cp-category').value,
    priority: document.getElementById('cp-priority').value,
    title: document.getElementById('cp-title').value.trim(),
    description: document.getElementById('cp-desc').value.trim()
  };
  try {
    const d = await api('/api/complaints', { method: 'POST', body: JSON.stringify(payload) });
    toast(d.message || 'Complaint registered.', 'success');
    e.target.reset();
    loadMyComplaints();
    loadStudentSummary();
  } catch (err) { toast(err.message, 'error'); }
}

/* ═══════════════════════════════════════════════════════════════
   STUDENT — NOTICES + SOS
   ═══════════════════════════════════════════════════════════════ */
async function loadNotices() {
  const el = document.getElementById('s-notice-list');
  if (!el) return;
  try {
    const rows = await api('/api/notices');
    if (!rows.length) {
      el.innerHTML = emptyState('fa-bullhorn', 'No notices right now.');
      return;
    }
    el.innerHTML = rows.map(n => `
      <div class="notice-card ${n.pinned ? 'pinned' : ''}">
        <h4>${n.pinned ? '<i class="fas fa-thumbtack" style="color:var(--orange);"></i>' : ''} ${esc(n.title)}
          <span class="notice-cat ${esc(n.category)}">${esc(n.category)}</span></h4>
        <p>${esc(n.body)}</p>
        <div class="n-meta">
          <span><i class="fas fa-user-shield"></i> ${esc(n.created_by_name || 'Warden')}</span>
          <span><i class="fas fa-clock"></i> ${fmtDateTime(n.created_at)}</span>
          ${n.hostel && n.hostel !== 'ALL' ? `<span><i class="fas fa-building"></i> ${esc(n.hostel)}</span>` : ''}
        </div>
      </div>`).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

async function triggerSOS() {
  const btn = document.getElementById('btn-sos');
  if (!confirm('Send an emergency alert to the warden?\n\nUse this only in a real emergency.')) return;
  if (btn) btn.disabled = true;
  try {
    const d = await api('/api/sos', {
      method: 'POST',
      body: JSON.stringify({
        location: (document.getElementById('sos-location') || {}).value || '',
        message: (document.getElementById('sos-message') || {}).value || ''
      })
    });
    toast('🚨 ' + (d.message || 'Alert sent'), 'success');
    document.getElementById('sos-location').value = '';
    document.getElementById('sos-message').value = '';
    loadStudentSummary();
  } catch (err) {
    toast(err.message, 'error');
    if (btn) btn.disabled = false;
  }
}

/* ═══════════════════════════════════════════════════════════════
   GATE PASS — OUTPASS, VISITORS, EXPECTED
   ═══════════════════════════════════════════════════════════════ */
async function loadGateSummary() {
  try {
    const d = await api('/api/gate/summary');
    const row = document.getElementById('gp-stats-row');
    if (!row) return;
    row.innerHTML = `
      <div class="stat-box"><div class="sb-icon" style="color:var(--green);"><i class="fas fa-building-shield"></i></div><div class="sb-val">${d.in_campus}</div><div class="sb-label">In Campus</div></div>
      <div class="stat-box"><div class="sb-icon" style="color:var(--orange);"><i class="fas fa-person-walking-arrow-right"></i></div><div class="sb-val">${d.outside}</div><div class="sb-label">Outside</div></div>
      <div class="stat-box"><div class="sb-icon" style="color:var(--blue);"><i class="fas fa-right-from-bracket"></i></div><div class="sb-val">${d.today_out}</div><div class="sb-label">Out Today</div></div>
      <div class="stat-box"><div class="sb-icon" style="color:var(--purple);"><i class="fas fa-right-to-bracket"></i></div><div class="sb-val">${d.today_in}</div><div class="sb-label">In Today</div></div>
      <div class="stat-box"><div class="sb-icon" style="color:var(--cyan);"><i class="fas fa-people-arrows"></i></div><div class="sb-val">${d.visitors_inside}</div><div class="sb-label">Visitors Inside</div></div>
      <div class="stat-box"><div class="sb-icon" style="color:var(--orange);"><i class="fas fa-clock"></i></div><div class="sb-val" style="font-size:1.1rem;">${esc(d.curfew_time)}</div><div class="sb-label">Curfew${d.is_after_curfew ? ' — ACTIVE' : ''}</div></div>`;
    badge('badge-g-expected', d.approved_leaves);
  } catch (err) { console.error('gate summary', err); }
}

// Gate pass marks a student on approved leave out or back in.
// The approved leave is the permission, so there is no code to type.
async function leaveEntry(studentId, name) {
  const el = document.getElementById('scan-result');
  el.style.display = 'block';
  el.className = 'scan-result';
  el.innerHTML = '<div style="padding:20px;"><i class="fas fa-spinner fa-spin fa-2x" style="color:var(--purple);"></i><p style="margin-top:8px;">Recording...</p></div>';
  try {
    const d = await api('/api/gate/leave-entry', { method: 'POST', body: JSON.stringify({ student_id: studentId }) });
    const st = d.student;
    const isIn = st.event_type === 'CHECK_IN';
    el.className = 'scan-result ok';
    el.innerHTML = `
      <h4 style="color:var(--green);"><i class="fas fa-plane-departure"></i> ${isIn ? 'RETURNED ✓' : 'LEFT ON LEAVE ✓'}</h4>
      <p style="margin:6px 0;"><strong>${esc(st.name)}</strong> (${esc(st.enrollment_no)})</p>
      <p style="font-size:0.85rem;color:var(--text2);">${esc(st.hostel_name)} · Room ${esc(st.room_no)} · ${esc(st.event_time)}</p>
      <p style="font-size:0.8rem;color:var(--orange);margin-top:6px;"><i class="fas fa-tag"></i> ${esc(st.leave_type)} leave${st.leave_until ? ' until ' + fmtDate(st.leave_until) : ''}</p>
      <span class="badge ${isIn ? 'in' : 'out'}" style="margin-top:8px;font-size:0.85rem;">${isIn ? '🟢 IN CAMPUS' : '🔴 OUTSIDE CAMPUS'}</span>
      ${st.outside_duration ? `<div style="margin-top:12px;padding:10px 16px;background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.3);border-radius:8px;display:inline-block;"><p style="color:var(--orange);font-weight:700;font-size:0.9rem;margin:0;">⏱ Outside Duration</p><p style="color:var(--orange);font-weight:800;font-size:1.3rem;margin:4px 0 0 0;">${esc(st.outside_duration)}</p></div>` : ''}`;
    toast(d.message || (name + ' updated'), 'success');
    S.justScanned = true;
    setTimeout(() => {
      loadGateStudents(); loadGateRecent(); loadGateSummary(); loadExpected(); loadOutsideNow();
      setTimeout(() => { S.justScanned = false; }, 3000);
    }, 500);
  } catch (err) {
    el.className = 'scan-result fail';
    el.innerHTML = `<h4 style="color:var(--red);"><i class="fas fa-times-circle"></i> NOT ALLOWED</h4><p style="margin-top:6px;">${esc(err.message)}</p>`;
    toast(err.message, 'error');
  }
}

async function submitVisitor(e) {
  e.preventDefault();
  const payload = {
    visitor_name: document.getElementById('v-name').value.trim(),
    visitor_phone: document.getElementById('v-phone').value.trim(),
    relation: document.getElementById('v-relation').value.trim(),
    purpose: document.getElementById('v-purpose').value.trim(),
    id_proof: document.getElementById('v-idproof').value.trim(),
    student_id: document.getElementById('v-student').value || null
  };
  try {
    const d = await api('/api/gate/visitors', { method: 'POST', body: JSON.stringify(payload) });
    toast(d.message || 'Visitor recorded.', 'success');
    e.target.reset();
    loadVisitors();
    loadGateSummary();
  } catch (err) { toast(err.message, 'error'); }
}

async function fillVisitorStudentSelect() {
  const sel = document.getElementById('v-student');
  if (!sel || sel.dataset.filled === '1') return;
  try {
    const rows = await api('/api/getpass/students');
    sel.innerHTML = '<option value="">Not specific</option>' +
      rows.map(s => `<option value="${s.id}">${esc(s.name)} — ${esc(s.enrollment_no)} (${esc(s.hostel_name)} ${esc(s.room_no)})</option>`).join('');
    sel.dataset.filled = '1';
  } catch (err) { console.error(err); }
}

async function loadVisitors() {
  const inside = document.getElementById('v-inside-list');
  const history = document.getElementById('v-history-list');
  if (!inside || !history) return;
  try {
    const rows = await api('/api/gate/visitors');
    const active = rows.filter(v => !v.out_time);
    const cnt = document.getElementById('v-inside-count');
    if (cnt) cnt.textContent = active.length;

    inside.innerHTML = active.length ? active.map(v => `
      <div class="item-card warn">
        <div class="item-head">
          <div>
            <div class="item-title">${esc(v.visitor_name)}</div>
            <div class="item-sub">${esc(v.relation || 'Visitor')}${v.student_name ? ' · visiting ' + esc(v.student_name) : ''}${v.room_no ? ' (Room ' + esc(v.room_no) + ')' : ''}</div>
          </div>
        </div>
        <div class="item-meta">
          <span><i class="fas fa-sign-in-alt"></i> In at ${esc(v.in_time)}</span>
          ${v.visitor_phone ? `<span><i class="fas fa-phone"></i> ${esc(v.visitor_phone)}</span>` : ''}
          ${v.purpose ? `<span><i class="fas fa-comment"></i> ${esc(v.purpose)}</span>` : ''}
        </div>
        <div class="item-actions">
          <button class="btn-action btn-orange btn-sm" onclick="visitorOut(${v.id})"><i class="fas fa-sign-out-alt"></i> Check Out</button>
        </div>
      </div>`).join('') : emptyState('fa-user-clock', 'No visitors inside right now.');

    const past = rows.filter(v => v.out_time).slice(0, 12);
    history.innerHTML = past.length ? past.map(v => `
      <div class="item-card">
        <div class="item-head">
          <div>
            <div class="item-title" style="font-size:0.88rem;">${esc(v.visitor_name)}</div>
            <div class="item-sub">${esc(v.in_time)} → ${esc(v.out_time)}</div>
          </div>
        </div>
      </div>`).join('') : emptyState('fa-clock-rotate-left', 'No past visitor entries.');
  } catch (err) {
    inside.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

async function visitorOut(id) {
  try {
    const d = await api(`/api/gate/visitors/${id}/out`, { method: 'PUT' });
    toast(d.message, 'success');
    loadVisitors();
    loadGateSummary();
  } catch (err) { toast(err.message, 'error'); }
}

async function loadExpected() {
  const el = document.getElementById('g-expected-list');
  if (!el) return;
  try {
    const rows = await api('/api/gate/expected');
    badge('badge-g-expected', rows.length);
    if (!rows.length) {
      el.innerHTML = emptyState('fa-plane-departure', 'No students are on approved leave today.');
      return;
    }
    el.innerHTML = rows.map(l => {
      const isOut = l.current_status === 'OUTSIDE_CAMPUS';
      return `
      <div class="item-card ${isOut ? 'warn' : 'ok'}">
        <div class="item-head">
          <div style="display:flex;gap:12px;align-items:center;">
            ${initialsAvatar(l.name, l.photo_url)}
            <div>
              <div class="item-title">${esc(l.name)} <span class="chip approved"><i class="fas fa-plane-departure"></i> ON LEAVE</span></div>
              <div class="item-sub">${esc(l.enrollment_no)} · ${esc(l.hostel_name)} Room ${esc(l.room_no)}</div>
            </div>
          </div>
          <span class="badge ${isOut ? 'out' : 'in'}">${isOut ? '🔴 Outside' : '🟢 In Campus'}</span>
        </div>
        <div class="item-meta">
          <span><i class="fas fa-tag"></i> ${esc(l.leave_type)} leave</span>
          <span><i class="fas fa-calendar"></i> ${fmtDate(l.from_date)} → ${fmtDate(l.to_date)}</span>
          ${l.destination ? `<span><i class="fas fa-location-dot"></i> ${esc(l.destination)}</span>` : ''}
        </div>
        ${l.warden_remark ? `<p class="item-body" style="border-left:2px solid var(--cyan);padding-left:10px;margin-top:10px;"><strong>Warden:</strong> ${esc(l.warden_remark)}</p>` : ''}
        <div class="item-actions">
          ${isOut
            ? `<button class="btn-action btn-green btn-sm" onclick="leaveEntry(${l.id}, '${esc(l.name)}')"><i class="fas fa-right-to-bracket"></i> Mark In (returned)</button>`
            : `<button class="btn-action btn-orange btn-sm" onclick="leaveEntry(${l.id}, '${esc(l.name)}')"><i class="fas fa-right-from-bracket"></i> Mark Out (leaving)</button>`}
        </div>
      </div>`;
    }).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

async function loadOutsideNow() {
  const el = document.getElementById('g-outside-list');
  if (!el) return;
  try {
    const rows = await api('/api/getpass/students?status=OUTSIDE_CAMPUS');
    const cnt = document.getElementById('g-outside-count');
    if (cnt) cnt.textContent = rows.length;
    el.innerHTML = rows.length ? rows.map(s => `
      <div class="item-card warn">
        <div class="item-head">
          <div style="display:flex;gap:12px;align-items:center;">
            ${initialsAvatar(s.name, s.photo_url)}
            <div>
              <div class="item-title">${esc(s.name)}</div>
              <div class="item-sub">${esc(s.enrollment_no)} · Room ${esc(s.room_no)}</div>
            </div>
          </div>
        </div>
        <div class="item-meta"><span><i class="fas fa-clock"></i> Out since ${fmtDateTime(s.last_checkout)}</span></div>
      </div>`).join('') : emptyState('fa-building-shield', 'Everyone is in campus.');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}


/* ═══════════════════════════════════════════════════════════════
   WARDEN — LEAVE REQUESTS
   ═══════════════════════════════════════════════════════════════ */
S.leaveFilter = 'PENDING';
S.complaintFilter = 'OPEN';

async function loadWardenLeaves() {
  const el = document.getElementById('w-leave-list');
  if (!el) return;
  try {
    const rows = await api('/api/warden/leaves' + (S.leaveFilter ? '?status=' + S.leaveFilter : ''));
    const pendingCount = S.leaveFilter === 'PENDING' ? rows.length : null;
    if (pendingCount !== null) badge('badge-w-requests', pendingCount);

    if (!rows.length) {
      el.innerHTML = emptyState('fa-inbox', 'Nothing here. You are all caught up.');
      return;
    }
    el.innerHTML = rows.map(l => `
      <div class="item-card ${l.status === 'PENDING' ? 'warn' : l.status === 'APPROVED' ? 'ok' : l.status === 'REJECTED' ? 'bad' : ''}">
        <div class="item-head">
          <div style="display:flex;gap:12px;align-items:center;">
            ${initialsAvatar(l.name, l.photo_url)}
            <div>
              <div class="item-title">${esc(l.name)} ${statusChip(l.status)}</div>
              <div class="item-sub">${esc(l.enrollment_no)} · ${esc(l.hostel_name)} Room ${esc(l.room_no)}</div>
            </div>
          </div>
          <div style="text-align:right;font-size:0.78rem;color:var(--text3);">
            <div><strong style="color:var(--purple);">${esc(l.leave_type)}</strong></div>
            <div>${fmtDate(l.from_date)} → ${fmtDate(l.to_date)}</div>
          </div>
        </div>
        <p class="item-body">${esc(l.reason)}</p>
        <div class="item-meta">
          ${l.destination ? `<span><i class="fas fa-location-dot"></i> ${esc(l.destination)}</span>` : ''}
          ${l.parent_contact ? `<span><i class="fas fa-phone"></i> Parent: ${esc(l.parent_contact)}</span>` : `<span><i class="fas fa-phone"></i> On file: ${esc(l.parent_phone || '—')}</span>`}
          <span><i class="fas fa-clock"></i> ${fmtDateTime(l.created_at)}</span>
        </div>
        ${l.warden_remark ? `<p class="item-body" style="border-left:2px solid var(--cyan);padding-left:10px;"><strong>Your remark:</strong> ${esc(l.warden_remark)}</p>` : ''}
        ${l.status === 'PENDING' ? `
        <div class="item-actions">
          <button class="btn-action btn-green btn-sm" onclick="reviewLeave(${l.id},'approve')"><i class="fas fa-check"></i> Approve</button>
          <button class="btn-action btn-red btn-sm" onclick="reviewLeave(${l.id},'reject')"><i class="fas fa-xmark"></i> Reject</button>
        </div>` : ''}
      </div>`).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

function filterLeaves(status, btn) {
  S.leaveFilter = status;
  document.querySelectorAll('#w-leave-filter .seg').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  loadWardenLeaves();
}

async function reviewLeave(id, action) {
  const remark = prompt(action === 'approve'
    ? 'Approve this leave?\n\nOptional remark for the student:'
    : 'Reject this request?\n\nReason (the student will see this):');
  if (remark === null) return;
  try {
    const d = await api(`/api/warden/leaves/${id}`, { method: 'PUT', body: JSON.stringify({ action, remark }) });
    toast(d.message || 'Done', 'success');
    loadWardenLeaves();
    loadWardenAll();
  } catch (err) { toast(err.message, 'error'); }
}

/* ═══════════════════════════════════════════════════════════════
   WARDEN — COMPLAINTS
   ═══════════════════════════════════════════════════════════════ */
async function loadWardenComplaints() {
  const el = document.getElementById('w-complaint-list');
  if (!el) return;
  try {
    const rows = await api('/api/warden/complaints' + (S.complaintFilter ? '?status=' + S.complaintFilter : ''));
    if (S.complaintFilter === 'OPEN') badge('badge-w-complaints', rows.length);

    const open = rows.filter(c => c.status === 'OPEN').length;
    const prog = rows.filter(c => c.status === 'IN_PROGRESS').length;
    const urgent = rows.filter(c => c.priority === 'URGENT').length;
    const stats = document.getElementById('w-complaint-stats');
    if (stats) {
      stats.innerHTML = `
        <div class="mini-stat"><div class="ms-val">${rows.length}</div><div class="ms-lbl">Shown</div></div>
        <div class="mini-stat"><div class="ms-val" style="color:var(--blue);">${open}</div><div class="ms-lbl">Open</div></div>
        <div class="mini-stat"><div class="ms-val" style="color:var(--purple);">${prog}</div><div class="ms-lbl">In Progress</div></div>
        <div class="mini-stat"><div class="ms-val" style="color:var(--red);">${urgent}</div><div class="ms-lbl">Urgent</div></div>`;
    }

    if (!rows.length) {
      el.innerHTML = emptyState('fa-screwdriver-wrench', 'No complaints in this view.');
      return;
    }
    el.innerHTML = rows.map(c => `
      <div class="item-card ${c.priority === 'URGENT' ? 'bad' : c.status === 'RESOLVED' || c.status === 'CLOSED' ? 'ok' : 'warn'}">
        <div class="item-head">
          <div style="display:flex;gap:12px;align-items:center;">
            ${initialsAvatar(c.name, c.photo_url)}
            <div>
              <div class="item-title">${esc(c.title)}</div>
              <div class="item-sub">${esc(c.name)} · ${esc(c.enrollment_no)} · ${esc(c.hostel_name)} Room ${esc(c.room_no)}</div>
            </div>
          </div>
          <div style="text-align:right;display:flex;flex-direction:column;gap:5px;align-items:flex-end;">
            ${statusChip(c.status)} ${priorityChip(c.priority)}
          </div>
        </div>
        <p class="item-body">${esc(c.description)}</p>
        <div class="item-meta">
          <span><i class="fas fa-tag"></i> ${esc(c.category)}</span>
          <span><i class="fas fa-clock"></i> ${fmtDateTime(c.created_at)}</span>
          ${c.resolved_at ? `<span><i class="fas fa-check"></i> ${fmtDateTime(c.resolved_at)}</span>` : ''}
        </div>
        ${c.warden_reply ? `<p class="item-body" style="border-left:2px solid var(--cyan);padding-left:10px;"><strong>Your reply:</strong> ${esc(c.warden_reply)}</p>` : ''}
        <div class="item-actions">
          ${c.status === 'OPEN' ? `<button class="btn-action btn-blue btn-sm" onclick="updateComplaint(${c.id},'IN_PROGRESS')"><i class="fas fa-play"></i> Start</button>` : ''}
          ${c.status !== 'RESOLVED' ? `<button class="btn-action btn-green btn-sm" onclick="updateComplaint(${c.id},'RESOLVED')"><i class="fas fa-check"></i> Resolve</button>` : ''}
          <button class="btn-action btn-ghost btn-sm" onclick="updateComplaint(${c.id},null)"><i class="fas fa-reply"></i> Reply</button>
        </div>
      </div>`).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

function filterComplaints(status, btn) {
  S.complaintFilter = status;
  document.querySelectorAll('#w-complaint-filter .seg').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  loadWardenComplaints();
}

async function updateComplaint(id, status) {
  const reply = prompt('Message to the student' + (status === 'RESOLVED' ? ' (what did you do?)' : ' (optional):'), '');
  if (reply === null) return;
  try {
    const d = await api(`/api/warden/complaints/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ status: status || undefined, reply })
    });
    toast(d.message || 'Updated', 'success');
    loadWardenComplaints();
  } catch (err) { toast(err.message, 'error'); }
}

/* ═══════════════════════════════════════════════════════════════
   WARDEN — ANALYTICS (pure CSS charts, nothing external)
   ═══════════════════════════════════════════════════════════════ */
async function loadAnalytics() {
  try {
    const d = await api('/api/warden/analytics');
    const t = d.totals;

    const row = document.getElementById('an-stats-row');
    if (row) {
      row.innerHTML = `
        <div class="stat-box s-total"><div class="sb-icon" style="color:var(--blue);"><i class="fas fa-users"></i></div><div class="sb-val">${t.students}</div><div class="sb-label">Total Students</div></div>
        <div class="stat-box s-in"><div class="sb-icon" style="color:var(--green);"><i class="fas fa-building-shield"></i></div><div class="sb-val">${t.in_campus}</div><div class="sb-label">In Campus</div></div>
        <div class="stat-box s-out"><div class="sb-icon" style="color:var(--orange);"><i class="fas fa-person-walking-arrow-right"></i></div><div class="sb-val">${t.outside}</div><div class="sb-label">Outside</div></div>
        <div class="stat-box"><div class="sb-icon" style="color:var(--purple);"><i class="fas fa-plane-departure"></i></div><div class="sb-val">${t.pending_leaves}</div><div class="sb-label">Pending Leaves</div></div>
        <div class="stat-box"><div class="sb-icon" style="color:var(--red);"><i class="fas fa-screwdriver-wrench"></i></div><div class="sb-val">${t.open_complaints}</div><div class="sb-label">Open Complaints</div></div>
        <div class="stat-box"><div class="sb-icon" style="color:var(--cyan);"><i class="fas fa-people-arrows"></i></div><div class="sb-val">${t.visitors_inside}</div><div class="sb-label">Visitors Inside</div></div>`;
    }

    // Gate traffic — grouped bars
    const traffic = document.getElementById('an-traffic');
    if (traffic) {
      const max = Math.max(1, ...d.traffic.map(x => Math.max(x.in, x.out)));
      traffic.innerHTML = `
        <div class="bar-chart">
          ${d.traffic.map(x => `
            <div class="bar-col">
              <div class="bar-val">${x.out}/${x.in}</div>
              <div class="bar-stack">
                <div class="bar-seg out" style="height:${Math.round((x.out / max) * 100)}%"></div>
                <div class="bar-seg in" style="height:${Math.round((x.in / max) * 100)}%"></div>
              </div>
              <div class="bar-lbl">${esc(x.label)}</div>
            </div>`).join('')}
        </div>
        <div class="chart-legend">
          <span><i class="fas fa-circle" style="color:var(--orange);"></i> Checked out</span>
          <span><i class="fas fa-circle" style="color:var(--green);"></i> Checked in</span>
        </div>`;
    }

    // Attendance trend
    const att = document.getElementById('an-attendance');
    if (att) {
      const withData = d.attendance.filter(a => a.present + a.absent > 0);
      if (!withData.length) {
        att.innerHTML = emptyState('fa-clipboard-check', 'No attendance recorded in the last 7 days.');
      } else {
        const max = Math.max(1, ...withData.map(x => x.present + x.absent));
        att.innerHTML = `
          <div class="bar-chart">
            ${d.attendance.map(x => {
              const total = x.present + x.absent;
              return `
              <div class="bar-col">
                <div class="bar-val">${x.pct === null ? '—' : x.pct + '%'}</div>
                <div class="bar-stack">
                  <div class="bar-seg absent" style="height:${total ? Math.round((x.absent / max) * 100) : 0}%"></div>
                  <div class="bar-seg present" style="height:${total ? Math.round((x.present / max) * 100) : 0}%"></div>
                </div>
                <div class="bar-lbl">${esc(x.label)}</div>
              </div>`;
            }).join('')}
          </div>
          <div class="chart-legend">
            <span><i class="fas fa-circle" style="color:var(--green);"></i> Present</span>
            <span><i class="fas fa-circle" style="color:var(--red);"></i> Absent</span>
          </div>`;
      }
    }

    // Complaints by category — horizontal bars
    const comp = document.getElementById('an-complaints');
    if (comp) {
      if (!d.complaints_by_category.length) {
        comp.innerHTML = emptyState('fa-face-smile', 'No complaints filed yet.');
      } else {
        const max = Math.max(1, ...d.complaints_by_category.map(c => c.total));
        comp.innerHTML = d.complaints_by_category.map(c => `
          <div class="hbar-row">
            <div class="hbar-lbl">${esc(c.category.toLowerCase())}</div>
            <div class="hbar-track">
              <div class="hbar-fill" style="width:${Math.round((c.total / max) * 100)}%;${c.open > 0 ? '' : 'background:var(--green-g);'}">${c.total}</div>
            </div>
            <div class="hbar-val">${c.open} open</div>
          </div>`).join('');
      }
    }

    const kpis = document.getElementById('an-kpis');
    if (kpis) {
      kpis.innerHTML = `
        <div class="kpi green"><div class="k-val">${t.boys}</div><div class="k-lbl">Boys Hostel</div></div>
        <div class="kpi orange"><div class="k-val">${t.girls}</div><div class="k-lbl">Girls Hostel</div></div>
        <div class="kpi blue"><div class="k-val">${d.avg_outside_hours}h</div><div class="k-lbl">Avg Time Outside</div></div>
        <div class="kpi"><div class="k-val">${esc(d.busiest_hour)}</div><div class="k-lbl">Busiest Gate Hour</div></div>
        <div class="kpi red"><div class="k-val">${t.active_sos}</div><div class="k-lbl">Active Emergencies</div></div>
        <div class="kpi"><div class="k-val">${t.approved_leaves}</div><div class="k-lbl">On Approved Leave</div></div>`;
    }
  } catch (err) {
    console.error('analytics', err);
    toast('Could not load analytics: ' + err.message, 'error');
  }
}

async function loadRooms() {
  const el = document.getElementById('an-rooms');
  if (!el) return;
  try {
    const d = await api('/api/warden/rooms');
    if (!d.hostels.length) {
      el.innerHTML = emptyState('fa-door-open', 'No rooms assigned yet.');
      return;
    }
    el.innerHTML = d.hostels.map(h => `
      <div class="hostel-block">
        <div class="hostel-head">
          <h4><i class="fas fa-building" style="color:var(--purple);"></i> ${esc(h.name)}</h4>
          <div class="occ-bar"><div class="occ-fill" style="width:${Math.min(100, h.occupancy_pct)}%"></div></div>
          <span class="count-pill">${h.total_students} / ${h.capacity} beds · ${h.occupancy_pct}%</span>
        </div>
        <div class="room-grid">
          ${h.rooms.map(r => `
            <div class="room-cell" onclick='showRoomStudents(${JSON.stringify(JSON.stringify(r.students))}, ${JSON.stringify(String(r.room_no))}, ${JSON.stringify(String(h.name))})' title="Click to see who is in this room">
              <div class="rc-no">${esc(r.room_no)}</div>
              <div class="rc-count">${r.count} student${r.count === 1 ? '' : 's'}</div>
              <div class="rc-dots">
                ${r.students.map(s => `<span class="rc-dot ${s.current_status === 'IN_CAMPUS' ? '' : 'out'}"></span>`).join('')}
              </div>
            </div>`).join('')}
        </div>
      </div>`).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

function showRoomStudents(studentsJson, roomNo, hostel) {
  let students = [];
  try { students = JSON.parse(studentsJson); } catch (e) { students = []; }
  openModal(`
    <h3 style="margin-bottom:6px;"><i class="fas fa-door-open" style="color:var(--purple);"></i> Room ${esc(roomNo)}</h3>
    <p class="item-sub" style="margin-bottom:16px;">${esc(hostel)} · ${students.length} student(s)</p>
    <div class="item-list">
      ${students.map(s => `
        <div class="item-card ${s.current_status === 'IN_CAMPUS' ? 'ok' : 'warn'}" style="cursor:pointer;" onclick="closeModal();viewStudent(${s.id})">
          <div class="item-head" style="margin-bottom:0;">
            <div style="display:flex;gap:12px;align-items:center;">
              ${initialsAvatar(s.name, s.photo_url)}
              <div>
                <div class="item-title">${esc(s.name)}</div>
                <div class="item-sub">${esc(s.enrollment_no)} · Floor ${esc(s.floor || '—')}</div>
              </div>
            </div>
            <span class="badge ${s.current_status === 'IN_CAMPUS' ? 'in' : 'out'}">${s.current_status === 'IN_CAMPUS' ? '🟢 IN' : '🔴 OUT'}</span>
          </div>
        </div>`).join('')}
    </div>`);
}

/* ═══════════════════════════════════════════════════════════════
   WARDEN — CURFEW + NIGHT ROLL CALL
   ═══════════════════════════════════════════════════════════════ */
async function loadCurfew() {
  const body = document.getElementById('w-curfew-body');
  const bdg = document.getElementById('w-curfew-badge');
  if (!body) return;
  try {
    const d = await api('/api/warden/curfew');
    if (bdg) {
      bdg.textContent = d.is_after_curfew ? 'CURFEW ACTIVE' : 'BEFORE CURFEW';
      bdg.className = 'sync-badge ' + (d.is_after_curfew ? 'off' : 'on');
    }
    const late = d.outside.filter(s => s.is_late && !s.on_leave);
    body.innerHTML = `
      <div class="mini-stats">
        <div class="mini-stat"><div class="ms-val">${esc(d.curfew_time)}</div><div class="ms-lbl">Curfew Time</div></div>
        <div class="mini-stat"><div class="ms-val">${esc(d.current_time)}</div><div class="ms-lbl">Current Time</div></div>
        <div class="mini-stat"><div class="ms-val" style="color:var(--orange);">${d.outside.length}</div><div class="ms-lbl">Outside Now</div></div>
        <div class="mini-stat"><div class="ms-val" style="color:var(--red);">${late.length}</div><div class="ms-lbl">Late / No Leave</div></div>
        <div class="mini-stat"><div class="ms-val" style="color:var(--green);">${d.outside.filter(s => s.on_leave).length}</div><div class="ms-lbl">On Approved Leave</div></div>
      </div>
      ${late.length ? `
        <h4 style="margin:18px 0 10px;font-size:0.9rem;color:var(--red);"><i class="fas fa-triangle-exclamation"></i> Students out after curfew without approval</h4>
        <div class="item-list">
          ${late.map(s => `
            <div class="item-card bad">
              <div class="item-head">
                <div style="display:flex;gap:12px;align-items:center;">
                  ${initialsAvatar(s.name, s.photo_url)}
                  <div>
                    <div class="item-title">${esc(s.name)}</div>
                    <div class="item-sub">${esc(s.enrollment_no)} · ${esc(s.hostel_name)} Room ${esc(s.room_no)}</div>
                  </div>
                </div>
              </div>
              <div class="item-meta">
                <span><i class="fas fa-clock"></i> Out ${Math.floor(s.minutes_out / 60)}h ${s.minutes_out % 60}m</span>
                <span><i class="fas fa-phone"></i> ${esc(s.phone || '—')}</span>
                <span><i class="fas fa-users"></i> Parent: ${esc(s.parent_phone || '—')}</span>
              </div>
            </div>`).join('')}
        </div>` : `<p class="muted-note" style="margin-top:14px;"><i class="fas fa-circle-check" style="color:var(--green);"></i> No unauthorized late entries right now.</p>`}
      ${d.outside.length ? `
        <h4 style="margin:20px 0 10px;font-size:0.9rem;color:var(--text2);"><i class="fas fa-list"></i> All students currently outside</h4>
        <div class="item-list">
          ${d.outside.map(s => `
            <div class="item-card ${s.on_leave ? 'ok' : s.is_late ? 'bad' : ''}">
              <div class="item-head" style="margin-bottom:4px;">
                <div>
                  <div class="item-title" style="font-size:0.9rem;">${esc(s.name)} <span class="chip ${s.on_leave ? 'approved' : s.is_late ? 'rejected' : 'pending'}">${s.on_leave ? 'ON LEAVE' : s.is_late ? 'LATE' : 'OK'}</span></div>
                  <div class="item-sub">${esc(s.enrollment_no)} · Room ${esc(s.room_no)}</div>
                </div>
                <div class="item-sub">${Math.floor(s.minutes_out / 60)}h ${s.minutes_out % 60}m out</div>
              </div>
            </div>`).join('')}
        </div>` : ''}`;
  } catch (err) {
    body.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

async function loadRollCall() {
  const el = document.getElementById('w-rollcall-list');
  const sum = document.getElementById('w-rollcall-summary');
  if (!el) return;
  try {
    const dateInput = document.getElementById('w-rollcall-date');
    if (dateInput && !dateInput.value) {
      dateInput.value = new Date().toLocaleString('en-CA', { timeZone: 'Asia/Kolkata' }).split(', ')[0];
    }
    const d = await api('/api/warden/rollcall' + (dateInput && dateInput.value ? '?date=' + dateInput.value : ''));
    if (sum) {
      sum.innerHTML = `
        <div class="mini-stat"><div class="ms-val">${d.total}</div><div class="ms-lbl">Students</div></div>
        <div class="mini-stat"><div class="ms-val" style="color:var(--green);">${d.marked}</div><div class="ms-lbl">Marked</div></div>
        <div class="mini-stat"><div class="ms-val" style="color:var(--orange);">${d.total - d.marked}</div><div class="ms-lbl">Not Marked</div></div>
        <div class="mini-stat"><div class="ms-val">${d.date}</div><div class="ms-lbl">Date</div></div>`;
    }
    if (!d.students.length) {
      el.innerHTML = emptyState('fa-moon', 'No students to check.');
      return;
    }
    el.innerHTML = d.students.map(s => {
      const state = s.roll_status === 1 ? 'present' : s.roll_status === 0 ? 'absent' : '';
      return `
      <div class="rc-row ${state}">
        <div class="rc-info">
          <strong>${esc(s.name)}</strong>
          <span>${esc(s.enrollment_no)} · ${esc(s.hostel_name)} Room ${esc(s.room_no)} · ${s.current_status === 'IN_CAMPUS' ? '<span style="color:var(--green);">in campus</span>' : '<span style="color:var(--orange);">outside</span>'}</span>
        </div>
        <div class="rc-toggle">
          <button class="rc-btn ${state === 'present' ? 'on-present' : ''}" onclick="saveRollCall(${s.id},1)"><i class="fas fa-check"></i> Present</button>
          <button class="rc-btn ${state === 'absent' ? 'on-absent' : ''}" onclick="saveRollCall(${s.id},0)"><i class="fas fa-xmark"></i> Absent</button>
        </div>
      </div>`;
    }).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

async function saveRollCall(studentId, present) {
  try {
    const dateInput = document.getElementById('w-rollcall-date');
    const d = await api('/api/warden/rollcall', {
      method: 'POST',
      body: JSON.stringify({ student_id: studentId, present: !!present, date: dateInput && dateInput.value ? dateInput.value : undefined })
    });
    toast(d.message, present ? 'success' : 'warning');
    loadRollCall();
  } catch (err) { toast(err.message, 'error'); }
}

async function bulkRollCall(present) {
  if (!confirm(present
    ? 'Mark every student currently in campus as present?\n\nStudents who are outside will be marked absent.'
    : 'Mark everyone absent for this date?')) return;
  try {
    const dateInput = document.getElementById('w-rollcall-date');
    const d = await api('/api/warden/rollcall/all', {
      method: 'POST',
      body: JSON.stringify({ present: !!present, date: dateInput && dateInput.value ? dateInput.value : undefined })
    });
    toast(d.message, 'success');
    loadRollCall();
  } catch (err) { toast(err.message, 'error'); }
}

/* ═══════════════════════════════════════════════════════════════
   WARDEN — NOTICES
   ═══════════════════════════════════════════════════════════════ */
async function loadWardenNotices() {
  const el = document.getElementById('w-notice-list');
  if (!el) return;
  try {
    const rows = await api('/api/notices');
    if (!rows.length) {
      el.innerHTML = emptyState('fa-bullhorn', 'No notices published yet.');
      return;
    }
    el.innerHTML = rows.map(n => `
      <div class="notice-card ${n.pinned ? 'pinned' : ''}">
        <h4>${n.pinned ? '<i class="fas fa-thumbtack" style="color:var(--orange);"></i>' : ''} ${esc(n.title)}
          <span class="notice-cat ${esc(n.category)}">${esc(n.category)}</span></h4>
        <p>${esc(n.body)}</p>
        <div class="n-meta">
          <span><i class="fas fa-clock"></i> ${fmtDateTime(n.created_at)}</span>
          <span><i class="fas fa-building"></i> ${n.hostel === 'ALL' ? 'Both hostels' : esc(n.hostel)}</span>
          <button class="btn-action btn-red btn-sm" style="margin-left:auto;" onclick="deleteNotice(${n.id})"><i class="fas fa-trash"></i> Remove</button>
        </div>
      </div>`).join('');
  } catch (err) {
    el.innerHTML = emptyState('fa-triangle-exclamation', err.message);
  }
}

async function publishNotice(e) {
  e.preventDefault();
  const payload = {
    title: document.getElementById('nt-title').value.trim(),
    body: document.getElementById('nt-body').value.trim(),
    category: document.getElementById('nt-category').value,
    hostel: document.getElementById('nt-hostel').value,
    pinned: document.getElementById('nt-pinned').checked
  };
  try {
    const d = await api('/api/warden/notices', { method: 'POST', body: JSON.stringify(payload) });
    toast(d.message || 'Published', 'success');
    e.target.reset();
    loadWardenNotices();
  } catch (err) { toast(err.message, 'error'); }
}

async function deleteNotice(id) {
  if (!confirm('Remove this notice? Students will no longer see it.')) return;
  try {
    const d = await api(`/api/warden/notices/${id}`, { method: 'DELETE' });
    toast(d.message, 'success');
    loadWardenNotices();
  } catch (err) { toast(err.message, 'error'); }
}

/* ═══════════════════════════════════════════════════════════════
   WARDEN — SETTINGS + SOS + EXPORT
   ═══════════════════════════════════════════════════════════════ */
async function loadSettings() {
  try {
    const d = await api('/api/warden/settings');
    const set = (id, v) => { const e = document.getElementById(id); if (e) e.value = v; };
    set('st-curfew', d.curfew_time || '22:30');
    set('st-grace', d.late_grace_minutes || '30');
    set('st-capb', d.hostel_capacity_boys || '120');
    set('st-capg', d.hostel_capacity_girls || '100');
    const rc = document.getElementById('st-rollcall'); if (rc) rc.checked = d.night_rollcall_enabled === '1';
    const sos = document.getElementById('st-sos'); if (sos) sos.checked = d.sos_enabled === '1';
    renderSettingsPreview(d);
  } catch (err) { console.error('settings', err); }
}

function renderSettingsPreview(d) {
  const el = document.getElementById('st-preview');
  if (!el) return;
  el.innerHTML = `
    <div class="kpi blue"><div class="k-val">${esc(d.curfew_time || '22:30')}</div><div class="k-lbl">Curfew</div></div>
    <div class="kpi"><div class="k-val">${esc(d.late_grace_minutes || '30')}m</div><div class="k-lbl">Grace Period</div></div>
    <div class="kpi green"><div class="k-val">${esc(d.attendance_start_time || '21:00')}</div><div class="k-lbl">Attendance Opens</div></div>
    <div class="kpi orange"><div class="k-val">${esc(d.attendance_end_time || '22:00')}</div><div class="k-lbl">Attendance Closes</div></div>
    <div class="kpi"><div class="k-val">${d.night_rollcall_enabled === '1' ? 'ON' : 'OFF'}</div><div class="k-lbl">Night Roll Call</div></div>
    <div class="kpi red"><div class="k-val">${d.sos_enabled === '1' ? 'ON' : 'OFF'}</div><div class="k-lbl">Student SOS</div></div>`;
}

async function saveSettings(e) {
  e.preventDefault();
  const payload = {
    curfew_time: document.getElementById('st-curfew').value,
    late_grace_minutes: document.getElementById('st-grace').value,
    hostel_capacity_boys: document.getElementById('st-capb').value,
    hostel_capacity_girls: document.getElementById('st-capg').value,
    night_rollcall_enabled: document.getElementById('st-rollcall').checked ? '1' : '0',
    sos_enabled: document.getElementById('st-sos').checked ? '1' : '0'
  };
  try {
    const d = await api('/api/warden/settings', { method: 'PUT', body: JSON.stringify(payload) });
    toast(d.message || 'Settings saved', 'success');
    loadSettings();
    loadCurfew();
  } catch (err) { toast(err.message, 'error'); }
}

async function loadSOSAlerts() {
  const banner = document.getElementById('w-sos-banner');
  if (!banner) return;
  try {
    const rows = await api('/api/warden/sos');
    const active = rows.filter(a => a.status === 'ACTIVE');
    badge('badge-w-requests', active.length || undefined);
    if (!active.length) { banner.innerHTML = ''; return; }
    banner.innerHTML = active.map(a => `
      <div class="sos-alert">
        <i class="fas fa-tower-broadcast sa-icon"></i>
        <div class="sa-text">
          <strong>🚨 EMERGENCY — ${esc(a.name)} (${esc(a.enrollment_no)})</strong>
          <span>${esc(a.hostel_name)} Room ${esc(a.room_no)} · ${esc(a.created_at)}${a.location ? ' · ' + esc(a.location) : ''}${a.message ? ' · "' + esc(a.message) + '"' : ''}</span>
          <span style="display:block;margin-top:4px;color:var(--orange);"><i class="fas fa-phone"></i> ${esc(a.phone || '—')} · Parent: ${esc(a.parent_phone || '—')}</span>
        </div>
        <div style="display:flex;gap:8px;flex-direction:column;">
          <button class="btn-action btn-orange btn-sm" onclick="ackSOS(${a.id},'ACKNOWLEDGED')"><i class="fas fa-eye"></i> Acknowledge</button>
          <button class="btn-action btn-green btn-sm" onclick="ackSOS(${a.id},'RESOLVED')"><i class="fas fa-check"></i> Resolve</button>
        </div>
      </div>`).join('');
  } catch (err) { console.error('sos', err); }
}

async function ackSOS(id, status) {
  try {
    const d = await api(`/api/warden/sos/${id}`, { method: 'PUT', body: JSON.stringify({ status }) });
    toast(d.message, 'success');
    loadSOSAlerts();
  } catch (err) { toast(err.message, 'error'); }
}

async function exportCsv(type) {
  try {
    toast('Preparing ' + type + ' export...', 'info');
    const r = await fetch('/api/warden/export/csv?type=' + encodeURIComponent(type), {
      headers: { 'Authorization': 'Bearer ' + S.token }
    });
    if (!r.ok) throw new Error('Export failed');
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hms-' + type + '-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast('✅ ' + type + ' CSV downloaded', 'success');
  } catch (err) { toast('Export failed: ' + err.message, 'error'); }
}

/* ═══════════════════════════════════════════════════════════════
   MODAL HELPER (used by room view etc.)
   ═══════════════════════════════════════════════════════════════ */
function openModal(html) {
  const box = document.getElementById('modal-box');
  const overlay = document.getElementById('modal-overlay');
  if (!overlay) return;
  // Older code sets modal-box content itself and then calls openModal() with no
  // arguments — only replace the content when HTML is actually passed in.
  if (box && typeof html === 'string' && html.length) box.innerHTML = html;
  overlay.style.display = 'flex';
}

(function init() {
  if (S.token && S.user) {
    connectSocket();
    enterDashboard();
  } else {
    showView('view-login');
  }
})();
