/**
 * ─── Durable Persistence Layer ───────────────────────────────────
 *
 * WHY THIS FILE EXISTS
 * ---------------------
 * Render's free web services have an EPHEMERAL filesystem. Every time the
 * service spins down (15 min idle), restarts, or redeploys, everything the
 * app wrote to disk is DELETED. Since this app stores its SQLite database
 * (hostel.db) and student photos on disk, all registered students vanish.
 *
 * This module makes the data survive that by keeping a copy OUTSIDE the
 * container. Two mechanisms, both optional and independent:
 *
 *   1. GitHub sync (best, works on Render free tier)
 *        env: GITHUB_TOKEN, GITHUB_REPO, GITHUB_BRANCH (default main)
 *      - On boot: pulls the newest hostel.db from the repo
 *      - On change: commits hostel.db back to the repo (debounced)
 *
 *   2. Local rolling backup (works anywhere with a real disk)
 *        Always on: keeps hostel.db.backup next to the live DB.
 *
 * Nothing here crashes the app: every operation is wrapped and failures are
 * logged as warnings only.
 */

const fs = require('fs');
const path = require('path');

const GITHUB_TOKEN = (process.env.GITHUB_TOKEN || '').trim();
const GITHUB_REPO = (process.env.GITHUB_REPO || '').trim(); // "owner/repo"
const GITHUB_BRANCH = (process.env.GITHUB_BRANCH || 'main').trim();
const GITHUB_DB_PATH = (process.env.GITHUB_DB_PATH || 'hostel.db').trim();

const SYNC_DEBOUNCE_MS = 30000;              // push 30s after the last change
const MIN_PUSH_INTERVAL_MS = 3 * 60 * 1000;  // never commit more than once / 3 min
const API = 'https://api.github.com';

const state = {
  enabled: !!(GITHUB_TOKEN && GITHUB_REPO),
  lastPullAt: null,
  lastPushAt: null,
  lastError: null,
  pending: false
};

let log = console;
function setLogger(l) { log = l; }

function githubEnabled() {
  return !!(GITHUB_TOKEN && GITHUB_REPO);
}

function headers() {
  return {
    Authorization: `Bearer ${GITHUB_TOKEN}`,
    Accept: 'application/vnd.github+json',
    'User-Agent': 'hostel-management-system',
    'X-GitHub-Api-Version': '2022-11-28'
  };
}

function contentsUrl() {
  return `${API}/repos/${GITHUB_REPO}/contents/${encodeURIComponent(GITHUB_DB_PATH)}`;
}

/**
 * Download hostel.db from the GitHub repo.
 * @returns {Promise<{buffer: Buffer, updatedAt: Date}|null>}
 */
async function pullDb() {
  if (!githubEnabled()) return null;
  try {
    const metaRes = await fetch(`${contentsUrl()}?ref=${encodeURIComponent(GITHUB_BRANCH)}`, {
      headers: headers()
    });

    if (metaRes.status === 404) {
      state.lastError = null;
      log.info('[sync] No hostel.db in repo yet — will create one on first save.');
      return null;
    }
    if (!metaRes.ok) {
      state.lastError = `GitHub read failed (${metaRes.status})`;
      log.warn(`[sync] ${state.lastError}`);
      return null;
    }

    const meta = await metaRes.json();
    const sha = meta.sha;

    const binRes = await fetch(`${contentsUrl()}?ref=${encodeURIComponent(GITHUB_BRANCH)}`, {
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.raw',
        'User-Agent': 'hostel-management-system',
        'X-GitHub-Api-Version': '2022-11-28'
      }
    });
    if (!binRes.ok) {
      state.lastError = `GitHub download failed (${binRes.status})`;
      log.warn(`[sync] ${state.lastError}`);
      return null;
    }

    const buffer = Buffer.from(await binRes.arrayBuffer());
    state.lastPullAt = new Date();
    state.lastError = null;
    log.info(`[sync] Pulled hostel.db from ${GITHUB_REPO}@${GITHUB_BRANCH} (${(buffer.length / 1024).toFixed(1)} KB, sha ${String(sha).slice(0, 7)})`);
    return { buffer, updatedAt: new Date(), sha };
  } catch (err) {
    state.lastError = err.message;
    log.warn(`[sync] Pull error: ${err.message}`);
    return null;
  }
}

/**
 * Upload hostel.db to the GitHub repo (create or update).
 * @returns {Promise<boolean>}
 */
async function pushDb(filePath) {
  if (!githubEnabled()) return false;
  try {
    if (!fs.existsSync(filePath)) return false;
    const buffer = fs.readFileSync(filePath);

    // Need the current sha to update an existing file.
    let sha = null;
    try {
      const metaRes = await fetch(`${contentsUrl()}?ref=${encodeURIComponent(GITHUB_BRANCH)}`, {
        headers: headers()
      });
      if (metaRes.ok) {
        const meta = await metaRes.json();
        sha = meta.sha;
      }
    } catch (_) { /* file probably does not exist yet */ }

    const body = {
      // [skip render]/[skip ci] stops the host from redeploying on every sync
      message: `chore: sync hostel.db [skip render] [skip ci] (${new Date().toISOString()})`,
      content: buffer.toString('base64'),
      branch: GITHUB_BRANCH
    };
    if (sha) body.sha = sha;

    const putRes = await fetch(contentsUrl(), {
      method: 'PUT',
      headers: { ...headers(), 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!putRes.ok) {
      const text = await putRes.text().catch(() => '');
      state.lastError = `GitHub push failed (${putRes.status}) ${text.slice(0, 140)}`;
      log.warn(`[sync] ${state.lastError}`);
      return false;
    }

    state.lastPushAt = new Date();
    state.lastError = null;
    state.pending = false;
    log.info(`[sync] Pushed hostel.db to ${GITHUB_REPO}@${GITHUB_BRANCH} (${(buffer.length / 1024).toFixed(1)} KB)`);
    return true;
  } catch (err) {
    state.lastError = err.message;
    log.warn(`[sync] Push error: ${err.message}`);
    return false;
  }
}

// ─── Debounced change hook ───────────────────────────────────────
// Rule: never more than one commit per MIN_PUSH_INTERVAL_MS, but always push
// once writing has stopped for SYNC_DEBOUNCE_MS.
let timer = null;
let onDirty = null;
let lastPushTime = 0;

function schedule(filePath, delay) {
  if (timer) clearTimeout(timer);
  timer = setTimeout(async () => {
    timer = null;
    const sinceLast = Date.now() - lastPushTime;
    if (lastPushTime && sinceLast < MIN_PUSH_INTERVAL_MS) {
      // Too soon — wait out the remainder, then try again.
      schedule(filePath, MIN_PUSH_INTERVAL_MS - sinceLast + 1000);
      return;
    }
    if (!state.pending) return;
    if (onDirty) {
      const ok = await onDirty(filePath);
      if (ok !== false) lastPushTime = Date.now();
    }
  }, delay);
  timer.unref?.();
}

function attach(filePath, callback) {
  onDirty = callback;
  // Safety net: if a push somehow keeps getting deferred, force one every 10 min.
  setInterval(() => {
    if (state.pending && !timer && onDirty) schedule(filePath, 1000);
  }, 10 * 60 * 1000).unref?.();
}

function markDirty(filePath) {
  // Always schedule: the callback writes the local rolling backup, and only
  // additionally talks to GitHub when cloud sync is configured.
  state.pending = true;
  if (timer) return; // already scheduled — keep the existing deadline
  schedule(filePath, SYNC_DEBOUNCE_MS);
}

/** Force an immediate push (used by the "Sync now" button and on shutdown). */
async function syncNow(filePath) {
  if (timer) { clearTimeout(timer); timer = null; }
  state.pending = false;
  const ok = await pushDb(filePath);
  if (ok) lastPushTime = Date.now();
  return ok;
}

// ─── Local rolling backup (no config needed) ─────────────────────
function writeLocalBackup(filePath) {
  try {
    if (!fs.existsSync(filePath)) return false;
    const bak = `${filePath}.backup`;
    fs.copyFileSync(filePath, bak);
    return true;
  } catch (err) {
    log.warn(`[backup] Local backup failed: ${err.message}`);
    return false;
  }
}

function status() {
  return {
    cloud_sync: githubEnabled(),
    repo: GITHUB_REPO || null,
    branch: GITHUB_BRANCH,
    last_pull: state.lastPullAt,
    last_push: state.lastPushAt,
    pending: state.pending,
    error: state.lastError
  };
}

module.exports = {
  setLogger,
  githubEnabled,
  pullDb,
  pushDb,
  markDirty,
  syncNow,
  attach,
  writeLocalBackup,
  status
};
