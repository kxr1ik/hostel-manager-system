# Fresh Deploy — from zero to live

You are building a brand-new deployment: **new GitHub repo → new Render service → clean database.**

Everything you need is in **`hostel-render-fix.zip`**. Total time: ~15 minutes.

> Already have a working deploy and just want to update it? Use `DEPLOY-STEPS.md` instead.

---

## What you end up with

| | |
|---|---|
| **Code** | New private repo on your GitHub |
| **Live site** | New Render free web service |
| **Database** | Brand new — 5 demo students, warden + gatepass logins |
| **Data safety** | Database auto-syncs to GitHub, so restarts don't wipe it |

---

## Step 1 — Download and unzip

Click **`hostel-render-fix.zip`** in this chat → save it → right-click → **Extract All**.

You should see `server.js`, `persistence.js`, `package.json`, `render.yaml`, and a `public` folder.

⚠️ **Never upload the zip itself.** GitHub treats it as one opaque file; Render never finds your code inside it.

---

## Step 2 — Create the new GitHub repo

1. Go to **github.com/new**
2. **Repository name:** `hostel-management-system-v2`
3. **Visibility: Private** ← must be private
4. Do **not** tick "Add a README file"
5. Click **Create repository**

**Why private matters:** to survive restarts, your server commits the database file
`hostel.db` into this repo — and that file contains every student account. A public
repo would expose it to anyone. Render's free plan works fine with private repos.

---

## Step 3 — Upload the files

On the empty repo page, click **uploading an existing file** (or **Add file → Upload files**).

1. Open your extracted folder
2. Select **everything inside it** — all files **and the `public` folder**
3. Drag the whole selection into the browser upload box
4. Wait for all files to list (the `public` folder should show `public/index.html`, `public/js/...`, `public/css/...`, `public/vendor/...`)
5. Commit message: `initial deploy`
6. Click **Commit changes**

✅ **Check:** the repo now shows `server.js`, `persistence.js`, `render.yaml`, and a `public` folder. If `public` is flat — files missing or sitting loose at the root — delete them and redo this step by dragging the **folder itself**.

---

## Step 4 — Create your access token

This is what lets the server save your data to GitHub. Without it, every restart wipes the database.

1. Go to **github.com/settings/tokens**
2. Click **Generate new token** → **Generate new token (classic)**
3. **Note:** `hostel-render`
4. **Expiration:** choose **No expiration**
   *(if the token expires, data silently stops saving — no error on the site)*
5. **Scopes:** tick the top-level **`repo`** checkbox
6. Click **Generate token**
7. **Copy the token now** — GitHub shows it once and never again

Paste it somewhere safe for the next step. It looks like `ghp_xxxxxxxxxxxx`.

---

## Step 5 — Create the Render service

1. Go to **dashboard.render.com** → **New +** → **Web Service**
2. Connect your GitHub account if asked, then pick **`hostel-management-system-v2`**
3. Fill in exactly:

| Field | Value |
|---|---|
| **Name** | `hostel-management-v2` |
| **Region** | Singapore (closest to India) |
| **Branch** | `main` |
| **Root Directory** | *(leave empty)* |
| **Runtime / Language** | `Node` |
| **Build Command** | `npm install` |
| **Start Command** | `npm start` |
| **Instance Type** | **Free** |

4. **Don't click Create yet** — add the environment variables first (Step 6).

---

## Step 6 — Environment variables

Still on the creation page, scroll to **Environment Variables** and add these four:

| Key | Value |
|---|---|
| `GITHUB_TOKEN` | the `ghp_...` token you copied in Step 4 |
| `GITHUB_REPO` | `your-username/hostel-management-system-v2` |
| `GITHUB_BRANCH` | `main` |
| `JWT_SECRET` | any long random string — mash the keyboard, 40+ characters |

> `GITHUB_REPO` must be **owner/repo**, exactly as it appears in your repo URL.
> If your GitHub username is `kxrlilik`, the value is
> `kxrlilik/hostel-management-system-v2`.

Now click **Deploy Web Service**.

---

## Step 7 — Watch it come up

Render opens the service page and starts building. Watch the **Logs** tab.

First build takes 2–4 minutes (it installs the packages). Success looks like:

```
Database tables ready
[seed] demo content ready
🏠 Hostel Management System running at http://0.0.0.0:3000
=== GitHub sync: ENABLED (repo: your-user/hostel-management-system-v2) ===
```

That last line is the one that matters — **if it says DISABLED**, your `GITHUB_TOKEN` or `GITHUB_REPO` is wrong and your data will not survive restarts. Fix it in the **Environment** tab; Render redeploys automatically.

Your site URL is at the top of the page, like `https://hostel-management-v2-xxxx.onrender.com`.

---

## Step 8 — Test it

First load may take ~30 seconds (the free plan sleeps after 15 idle minutes).

| # | Test | Expected |
|---|---|---|
| 1 | Open the site | Colorful landing page, **no** "Show Demo Credentials" button |
| 2 | Login `warden` / `warden123` | Warden dashboard loads |
| 3 | Leaves tab → approve the pending request | Status becomes APPROVED |
| 4 | Login `22cs101` / `student123` | **ON LEAVE** badge on the dashboard |
| 5 | Look at the QR code | **No 6-digit number** under it |
| 6 | Login `gatepass` / `gatepass123` | Gate panel shows **Start Scanner**, **no code input box** |
| 7 | On Leave Today tab | 22CS101 listed → click **Mark Out** then **Mark In** |
| 8 | Back on the student dashboard | Shows how long they were outside |

**Scanner test:** do this on your phone or a laptop with a webcam, on the live URL.
Camera access is blocked inside the chat preview, so scanning only works on the real
deployed site.

---

## Step 9 — Prove your data is safe now

This is the test your previous deploy failed. Do it once:

1. Register a **new student account** on the live site (note the roll number)
2. Close the site and **wait 20 minutes** (long enough for Render to sleep)
3. Open the site again and log in as that student

**Still there?** Your data now survives restarts. ✅

Not there? Open your GitHub repo — you should see **`hostel.db`** with a recent commit.
If it's missing, the token is wrong → Step 4 and Step 6.

---

## Housekeeping

**Old deploy:** your previous Render service still runs the old code. Once the new one
works, you can delete it (Service → Settings → Delete Service) or just stop using it.
Keeping it running costs nothing.

**After this, to update the site later:** upload changed files to GitHub → Render
redeploys automatically.

**Never run `reset-demo.js` on the live service.** It deletes leaves and resets all
students — it's a local demo tool only.

---

## Troubleshooting

| Symptom | Cause / Fix |
|---|---|
| Build fails: `Cannot find module 'express'` | `package.json` didn't upload. Re-do Step 3. |
| `Cannot find module './persistence'` | `persistence.js` missing from the repo. Upload it. |
| Logs say **sync DISABLED** | Wrong `GITHUB_TOKEN` or `GITHUB_REPO` format. Fix in Environment tab. |
| Site unstyled, buttons dead | `public/` uploaded flat. Delete the loose files and re-upload the whole folder. |
| "Scanner could not load" | `public/vendor/` missing. Same fix as above. |
| New accounts vanish after a while | Token expired or missing → Step 4. |
| Page hangs on first visit | Normal — free plan waking from sleep, wait ~30s. |
| 502 error | Service crashed at boot. Check the Logs tab for the first red line. |
