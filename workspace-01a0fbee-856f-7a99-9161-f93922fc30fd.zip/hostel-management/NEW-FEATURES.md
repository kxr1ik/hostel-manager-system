# 🆕 What's new — and how to put it online

> **Latest change:** all code entry has been removed. The gate works by
> **QR scanning only**. Leave movement is handled by name, not by code: when a
> student has an approved leave, their dashboard shows **ON LEAVE**, the gate pass
> dashboard lists them on the "On Leave Today" tab, and the gate marks them out or
> back in with one button.


Your hostel system now does far more than check students in and out. Everything
below is tested and running.

---

## Step 1 — Upload the updated files to GitHub

Download **`hostel-render-fix.zip`** from the chat, unzip it, then on
**github.com/kxrlilik/hostel-manager-system** click **Add file → Upload files**
and drag everything in. The `public` folder must come along (it contains `js`,
`css` and `vendor`).

Files in the zip:

```
server.js                    ← rewrite
package.json
.gitignore
RENDER-DATA-LOSS-FIX.md
NEW-FEATURES.md              ← this file
public/index.html            ← rewrite
public/js/app.js             ← rewrite
public/css/styles.css        ← rewrite
public/vendor/               ← libraries served by your own server
```

Render redeploys automatically. Wait 2–3 minutes.

**If you have not done Step 2 of the other guide yet** (the `GITHUB_TOKEN` +
`GITHUB_REPO` environment variables), do that now too — otherwise student data
still disappears every time Render restarts.

---

## The new features

### For students

| Feature | What it does |
|---|---|
| **Leave / Outpass** | Apply with type, dates, destination and reason. The warden approves or rejects. While the leave is running, your dashboard shows a purple **ON LEAVE** card with the dates and destination — and the gate can see it too, so nothing needs to be typed or shown. When you return, the leave closes itself. |
| **Complaints** | Report electrical, plumbing, WiFi, cleanliness, furniture, food or security problems. Pick a priority. Track the status and read the warden's reply. |
| **Notice board** | Everything the warden publishes, with pinned notices on top and colour-coded categories. |
| **Emergency SOS** | A red button that alerts the warden instantly with your room number and message. Cannot be spammed — one active alert at a time. |
| **Live dashboard cards** | Pending requests, open complaints and curfew time are shown as badges on the tabs. |

### For the gate pass desk

| Feature | What it does |
|---|---|
| **Students On Leave Today** | The list of everyone with permission to be away right now, with their dates and destination. Press **Mark Out** when they leave and **Mark In** when they return — the leave closes itself. |
| **Leave badges everywhere** | Anyone on leave is flagged in the live student list with a purple dot and a "On Leave" badge, so you know before they even reach the counter. |
| **Visitor log** | Record visitor name, phone, relation, purpose and ID proof, link them to a student, and check them out when they leave. See who is inside right now. |
| **Six live counters** | In campus, outside, out today, in today, visitors inside, and curfew status. |

### For the warden

| Feature | What it does |
|---|---|
| **Requests inbox** | Approve or reject leave requests with a remark. Filter by pending / approved / rejected. |
| **Complaints board** | Prioritised queue, with Start → Resolve workflow and a reply to the student. |
| **Analytics** | Gate traffic and attendance charts for the last 7 days, complaints by category, average time spent outside, busiest gate hour, and live KPI tiles. All charts are built with CSS — nothing loads from the internet. |
| **Room occupancy** | Every room as a tile showing how many students are in it and who is in or out. Click a room to see the students and open their full profile. |
| **Curfew monitor** | Students still outside after the curfew time, highlighted in red if they have no approved leave, with their phone numbers. |
| **Night roll call** | Mark each student present or absent for the night, or fill in everyone at once. Students who are outside are marked absent automatically. |
| **Notice board** | Publish notices to both hostels or one, pin important ones, and remove old ones. |
| **Settings** | Curfew time, grace period, hostel bed capacity, night roll call on/off, student SOS on/off. |
| **CSV exports** | Students, attendance, leaves, complaints and the gate log — they open straight in Excel. |

### For everyone

- **Dark / light theme** — the moon button in the top bar.
- **Emergency banner** — an active SOS appears in red at the top of the warden
  dashboard and blinks until acknowledged.
- **Live updates** — approvals, complaints, notices, visitors, roll call and SOS
  all push to every open dashboard instantly, no refresh.

---

## How gate entry works now

There are exactly two movements at the gate, and **neither uses a typed code**:

| Situation | How the gate records it |
|---|---|
| Normal in/out | Scan the student's QR with **Start Scanner**. The QR refreshes every 6 seconds and is single-use. |
| Student on approved leave | No scan needed — open **On Leave Today**, find their name, and press **Mark Out** or **Mark In**. |

The server decides check-in vs check-out from the student's current campus status,
and always has.

> ⚠️ **Camera note:** the QR scanner needs a real browser with camera permission.
> It will not start inside an embedded preview window — open the site on a phone or
> the deployed (Render) URL for scanning. The leave buttons work everywhere.


---

## Why this is not just another hostel app

1. **An approved leave is the gate permission.** Most systems keep leave requests
   and gate movement separate. Here the warden's approval *is* the authorization —
   no codes to type, lose or share. The gate sees who is on leave, taps once to
   send them out, and taps again when they walk back in.
2. **Curfew awareness is built into the same data.** The system knows which
   students outside the gate are on approved leave and which are not, so the
   warden sees only the ones that actually matter.
3. **SOS is wired into the same live channel** as everything else — the alert
   reaches the warden dashboard in under a second.
4. **Works with no camera and no internet libraries.** The 6-digit code path
   means a desktop with no webcam can still run the gate, and every library is
   served from your own server.

Nothing sensitive is added to the QR or the 6-digit codes: they are random,
single-use and expire. The leave-based gate entry is even stricter — it only works
for a student whose leave the warden has actually approved for today.

---

## Testing that was done

A 27-check automated pass covers the full journey plus validation and access
control. Highlights:

- Student applies → warden approves → student dashboard shows **ON LEAVE** →
  gate sees the name on the leave list → marks out → student returns → gate marks
  in → **leave closes itself**
- QR scan works for check-out and check-in, duration is computed on return, and a
  reused QR is rejected
- With all code entry removed, typed-code attempts are rejected (30 checks on this)
- A student with no approved leave is **refused** at the gate counter — the
  leave check is enforced on the server, not just hidden in the UI
- QR scan and 6-digit code still work; a used code is rejected on reuse
- Students cannot reach warden endpoints; gate staff cannot approve leaves;
  wardens cannot mark attendance for themselves
- Curfew `99:99`, negative grace periods, oversized capacity, reversed leave
  dates and short phone numbers are all rejected
- Every `onclick` in the HTML has a matching JavaScript function

**One real bug found and fixed during this work:** attendance and gate times were
being recorded in UTC instead of IST, so every timestamp was 5 hours 30 minutes
behind. All time handling is now IST.

---

## Still to do on your side

1. Upload the files (Step 1 above).
2. Add the `GITHUB_TOKEN` / `GITHUB_REPO` / `JWT_SECRET` environment variables if
   you have not yet.
3. **Make the repo private** — the synced database holds student phone numbers.
4. Open the warden dashboard and try: **Requests → approve** the sample request.
   Then log in as the student (`22cs101` / `student123`) — the dashboard shows
   **ON LEAVE** in purple. Then log in as gate pass → **On Leave Today** → press
   **Mark Out**. The student's dashboard flips to outside, still ON LEAVE. Press
   **Mark In** and the leave closes itself.

The app seeds a few sample notices, two complaints and one leave request the
first time it runs, so the dashboards are not empty. Delete them whenever you
like — they are ordinary records.
