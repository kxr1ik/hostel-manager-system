const initSqlJs = require('sql.js');
const fs = require('fs');
(async () => {
  const SQL = await initSqlJs();
  const db = new SQL.Database(fs.readFileSync('hostel.db'));
  const pad = n => String(n).padStart(2, '0');
  const iso = dt => dt.getUTCFullYear() + '-' + pad(dt.getUTCMonth() + 1) + '-' + pad(dt.getUTCDate());
  const now = new Date(Date.now() + 5.5 * 3600 * 1000); // IST
  const today = iso(now);
  const end = iso(new Date(now.getTime() + 2 * 86400000));

  db.run('DELETE FROM leaves');
  db.run('DELETE FROM campus_events');
  db.run("UPDATE students SET current_status = 'IN_CAMPUS', last_checkout = NULL, last_checkin = NULL, last_outside_duration = ''");
  db.run(
    "INSERT INTO leaves (student_id, leave_type, reason, destination, from_date, to_date, parent_contact, status) VALUES (1, 'HOME', 'Going home for a family function over the weekend.', 'Indore', ?, ?, '9876543211', 'PENDING')",
    [today, end]
  );
  fs.writeFileSync('hostel.db', Buffer.from(db.export()));
  console.log(`demo reset: 1 pending leave ready (${today} to ${end}), all students IN_CAMPUS`);
})();
